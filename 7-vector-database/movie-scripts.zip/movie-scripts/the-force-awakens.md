STAR WARS: THE FORCE AWAKENS

                        

                        

                                    Written by

                        
                    Lawrence Kasdan, J.J. Abrams & Michael Arndt

                    

                        
                    Based on characters created by George Lucas
                        

            
        

                        
        A long time ago in a galaxy far, far away...

                        

                        

                                    STAR WARS

                                    EPISODE VII

                                THE FORCE AWAKENS



        Luke Skywalker has vanished. In his absence,
        the sinister FIRST ORDER has risen from the
        ashes of the Empire and will not rest until
        Skywalker, the last Jedi, has been destroyed.
        With the support of the REPUBLIC, General
        Leia Organa leads a brave RESISTANCE. She is
        desperate to find her brother Luke and gain
        his help in restoring peace and justice to
        the galaxy.

        Leia has sent her most daring pilot on a secret
        mission to Jakku, where an old ally has
        discovered a clue to Luke's whereabouts....


        PAN across the star field to a bright moon. A RUMBLING is
        FELT. A VAST STAR DESTROYER -- unlike any we have seen --
        HURTLES PAST US, of seemingly endless length, eclipsing the
        moon. After a long beat, FOUR TRANSPORT SHIPS fly from a
        hangar. We HOLD ON THEM NOW, as they fly off toward a distant
        planet. Jakku. MUSIC BUILDS AND WE...

        CUT TO BLACK.

        A GROWING ROAR of MEAN ENGINES -- gnarled RADIO CALLS, the
        SHUDDERING of a ship's hull. Then FLASHES OF LIGHT: for an
        instant we see a STORMTROOPER -- then BLACKNESS. Then ANOTHER
        STORMTROOPER, then it's gone.

        The FLICKERING CONTINUES until the LIGHTS ARE CONSTANT. We

                        ARE IN:

        INT. TROOP TRANSPORT VEHICLE - NIGHT

        TWENTY STORMTROOPERS. Holding on at attention, moving to
        the ship's rhythm, in the tense moments before a raid. A
        FILTERED COMMAND and they LOCK AND LOAD their heavy blaster
        rifles. The BRUTAL NOISE is replaced by SUDDEN, SHOCKING

                        QUIET:

        EXT. JAKKU VILLAGE - NIGHT

        WIDE SHOT of a small, peaceful village. Distant sounds of
        native animals. A single wind chime.
        Suddenly a DROID RISES INTO FRAME, CLOSE: ROUND and SKITTERY,
        orange and white, this is BB-8.
        Focuses on something past camera. He BEEPS -- FAST, MORSE
        CODE-LIKE SOUNDS, clearly worried. Moves EVEN CLOSER TO
        CAMERA -- is MORE worried -- BEEPS more -- then TURNS AND

        ROLLS OFF FAST --

        INT. LARGE HUT - NIGHT

        CLOSE ON A HAND: a small LEATHER SACK is placed in the palm.
        The hand closes. Another OLDER HAND covers it.
        In a primitive HUT, an old explorer, LOR SAN TEKKA, (rugged,
        kind) has handed the mysterious sack to POE DAMERON (32, in
        a pilot's jacket). Poe has charisma, a natural spark:

        LOR SAN TEKKA
        This will begin to make things right.
        I've traveled too far, and seen too
        much, to ignore the despair in the
        galaxy. Without the Jedi, there can
        be no balance in the Force.

                        POE
        Well, because of you now we have a
        chance. The General's been after
        this for a long time.

        LOR SAN TEKKA
        "The General." To me, she's royalty.
        Well, she certainly is that.

                        POE
        BB-8 ENTERS FRANTIC, BEEPS. Concerned, Poe turns to Lor San
        Tekka.

                        POE (CONT'D)
        We've got company.

        EXT. LARGE HUT - NIGHT

        The men exit fast. Poe moves TO CAMERA, raises QUADNOCULARS.
        POE'S POV: LIGHTS on the horizon -- approaching ENEMY SHIPS.
        POE lowers the quadnocs -- PUSH IN ON HIS UNNERVED EYES. A

        GROWING, FRIGHTENING THUNDER.

                        POE
        You have to hide.

        LOR SAN TEKKA
        You have to leave. Go!
        Poe turns to him. Conflicted. Finally nods, hurries off.
        BB-8 follows.

        EXT. JAKKU VILLAGE - NIGHT

        TRACK FAST with Poe as he and BB-8 hurry through the village,
        various ARMED VILLAGERS taking position, prepared to defend.

        EXT. JAKKU VILLAGE - NIGHT

        A ROAR of WIND and DUST: the TRANSPORTS LAND. Stormtroopers
        come out FIRING BLASTERS -- the VILLAGERS FIRE BACK -- many
        are HIT!

        EXT. RISE ADJACENT TO VILLAGE - NIGHT

        Poe runs to an X-WING fighter, parked at a distance from the
        village, hidden behind a ROCK OUTCROPPING.

                        POE
        Come on, BB-8! Hurry!
        Poe sends BB-8 into the droid socket / co-pilot seat -- he
        moves to the cockpit -- the CONTROLS COME TO LIFE. As the
        CANOPY CLOSES, Poe shoots a quick look back: the ENEMY ARRIVES

        IN THE DISTANCE.
        Poe urgently works the controls -- BB-8 BEEPS.
        The X-WING LANDING LIGHTS COME ON, ENGINES WHINE TO LIFE!
        But just then:
        Poe's ship is suddenly HIT BY BLASTERFIRE! Poe turns to
        look: two STORMTROOPERS CHARGE HIS WAY, FIRING!

                        POE (CONT'D)
        I see 'em!
        BB-8 BEEPS nervously as Poe GRABS HIS CONTROLS and FIRES AT
        THEM, using the X-wing's drop-down antipersonnel blaster!
        The two Troopers are BLOWN AWAY in the large BLAST HITS!
        Poe tries to start the ship now, but the ENGINES SPUTTER.
        Concerned, he opens his canopy, jumps down, moves to the
        back of his ship: BAD DAMAGE ON THE REAR ENGINE PANEL.
        They're in trouble.

        EXT. JAKKU VILLAGE - NIGHT

        Lor San Tekka moves sadly through the village as STORMTROOPERS
        wielding FLAME THROWERS destroy structures. Surrendering
        Villagers are ROUNDED UP. Penned ANIMALS panic.

        EXT. RISE ADJACENT TO THE VILLAGE - NIGHT

        Back at the X-wing, Poe kneels beneath his ship, pulls from
        the leather sack a SMALL, OLD ARTIFACT which he inserts into
        BB-8 -- the droid's MULTI-READER ENVELOPS it.

                        POE
        You take this. It's safer with you
        than it is with me. You get as far
        away from here as you can. Do you
        hear me?
        (BB-8 BEEPS, hesitates)
        I'll come back for you! It will be
        alright.

                        

                        
        BB-8 watches Poe run off. BEEP-WHINES nervously, then turns
        and heads off. Turns back once to look at Poe, then ROLLS
        AWAY. Poe uses his blaster rifle to fire at incoming troopers
        from cover.

        EXT. JAKKU VILLAGE - NIGHT

        The Troopers and villagers in battle -- as one Trooper is
        HIT and goes down. Another -- OUR TROOPER -- KNEELS to help.
        The hit trooper raises a torn, bloody glove -- his HUMAN
        HAND visible -- and MARKS OUR STORMTROOPER'S MASK WITH BLOOD
        just before he dies. Our Trooper, stands -- overwhelmed by
        the battle.

        AN IMPOSING SHUTTLE CRAFT -- VERTICAL WINGSPAN 90 FEET TALL --

        LANDS NEAR THE TRANSPORT VEHICLES.
        The shuttle craft door OPENS -- through the wind and smoke,
        KYLO REN exits the ship: a TALL, DARK FIGURE, he strides
        through the chaos toward San Tekka.
        A senior Trooper moves to our blood-marked Trooper, and orders

                        HIM:

                        SENIOR TROOPER
        Stay here.
        Our Trooper nods.
        Kylo Ren stops before the outraged Lor San Tekka, dwarfing
        him. Only now does it become apparent that Kylo Ren wears a
        DARK MASK, marked by battle. Inset metal lines reflect FIRE.

                        KYLO REN
        Look how old you've become.

        LOR SAN TEKKA
        Something far worse has happened to
        you.
        Our blood-marked TROOPER is placed in line with other
        stormtroopers.

                        KYLO REN
        You know what I've come for.

                        

                        

                        (CONTINUED)

        CONTINUED: LOR SAN TEKKA
        I know where you come from. Before
        you called yourself Kylo Ren.

                        KYLO REN
        The map to Skywalker. We know you've
        found it, and now you're going to
        give it to the First Order.
        Adjacent to the village, Poe enters frame -- sees the Ren/San
        Tekka exchange continue.

        LOR SAN TEKKA
        The First Order rose from the dark
        side... you did not.

                        KYLO REN
        I'll show you the dark side.

        LOR SAN TEKKA
        You may try, but you cannot deny the
        truth that is your family.
        Suddenly Kylo Ren raises his LIGHTSABER -- IGNITES IT --

        PERPENDICULAR SMALLER BLADES AT THE HILT, A UNIQUE BUZZ --

        YELLOW/RED ENERGY, SPITTING SPARKS AND SMOKE --

                        KYLO REN
        You're so right.
        And as he RIPS IT DOWN ACROSS SAN TEKKA!
        Poe, RUNNING, SEES THIS AND YELLS, AIMS HIS BLASTER AND FIRES
        AT KYLO REN! Instantly:
        Kylo Ren RAISES HIS HAND -- POE'S BLAST FREEZES -- THE BOLT

        OF ENERGY STRAINING AND VIBRATING IN MID AIR!
        Kylo Ren sees Poe, who suddenly CANNOT MOVE, but strains to.
        He is grabbed by Stormtroopers who drag him past the
        VIBRATING, FROZEN BLAST, to Kylo Ren.
        A Stormtrooper begins a brutal PAT DOWN. Kylo Ren moves
        closer. Poe just glares. The Stormtrooper KICKS OUT Poe's
        legs -- he lands hard on his knees.
        Kylo Ren kneels to look at Poe.

                        POE
        So who talks first? You talk first?

                        KYLO REN
        The old man gave it to you.

                        POE

                        (INDICATES KYLO'S

                        MASK)
        It's just very hard to understand
        you with all the...

                        

                        

                        

                        (CONTINUED)

                        CONTINUED:

                        KYLO REN

                        (TO TROOPERS)
        Search him.

                        POE
        ... Apparatus.
        The Troopers roughly pull Poe away. A Stormtrooper begins a
        brutal PAT DOWN. Kylo Ren moves closer.
        Poe just glares as the pat down ends.

                        STORMTROOPER #1
        Nothing, sir.

                        KYLO REN
        Put him on board.
        Kylo Ren regards the Stormtroopers with the rounded up
        Villagers, then turns to the CHROME-SKINNED, FEMALE BLACK-

        CAPED HEAD STORMTROOPER, CAPTAIN PHASMA.

                        CAPTAIN PHASMA
        Sir, the villagers.

                        KYLO REN
        Kill them all.
        Phasma nods, steps forward:

                        CAPTAIN PHASMA
        On my command!
        The Troopers, including OURS, aim at the Villagers.

        CAPTAIN PHASMA (CONT'D)
        Fire!
        Poe is roughly PULLED into a transport ship, the ramp LIFTS.
        All around our Trooper BLASTERFIRE ERUPTS -- but we're WIDE
        ENOUGH to see he ISN'T FIRING. PUSH IN until the FIRING
        STOPS. All the Stormtroopers SPREAD OUT TO SEARCH -- except
        ours.
        Kylo Ren heads back toward his ship. But then he STOPS.
        Feels something. TURNS AND LOOKS AT OUR STORMTROOPER for a
        LONG MOMENT. Our Trooper can barely meet his gaze; knows
        he's doomed.
        Kylo Ren then heads off -- passes the FROZEN BLAST, which,
        after a beat, GOES FREE AND SLAMS INTO A NEARBY STRUCTURE,
        scaring the hell out of our Stormtrooper.

        EXT. EDGE OF JAKKU VILLAGE - NIGHT

        A Stormtrooper climbs down from the cockpit of Poe's X-wing,

                        BACKS AWAY:

                        

                        

                        (CONTINUED)

                        CONTINUED:

                        STORMTROOPER #2
        Nothing here. Go ahead!
        Three other Stormtroopers FIRE LASER CANNONS at the X-wing --
        destroying the ship in a LARGE EXPLOSION.

        EXT. OUTSKIRTS OF JAKKU VILLAGE - NIGHT

        BB-8 rolls across the sand, looks back: the X-wing FIREBALL.
        BB-8, afraid, continues on his own in a mysterious, dark
        desert. We see a FORM -- an animal, its RED EYES LIFTING
        from the sand, watching the rolling droid, who just keeps
        going.
        In a WIDE SHOT, we HEAR HIM BEEPING to himself, lonely and
        frightened.

        EXT. SPACE - NIGHT

        With the SANDY PLANET OF JAKKU as backdrop, Troop Transports
        and Kylo Ren's Shuttle approach a massive STAR DESTROYER.

        INT. STAR DESTROYER HANGAR - NIGHT

        Poe, shackled, is ushered from the transport through the
        hangar. He is awed by the imposing space.

                        POE
        All right. All right!
        Our Stormtrooper passes, moves fast:

        INT. TROOP TRANSPORT VEHICLE - NIGHT

        Our Stormtrooper enters the dark, vehicle. He removes his
        helmet. His head comes up and we PUSH IN ON HIS FACE FOR
        THE FIRST TIME. This is FN-2187. He is 23, likable. But
        in this moment, terrified, desperate.
        After a beat, behind him, CAPTAIN PHASMA enters. FN-2187
        knows he's in trouble.

                        CAPTAIN PHASMA
        FN-2187. Submit your blaster for
        inspection.

                        FN-2187
        Yes, Captain.

                        CAPTAIN PHASMA
        And who gave you permission to remove
        that helmet?

                        FN-2187
        I'm sorry, Captain.

                        CAPTAIN PHASMA
        Report to my division at once.

                        

                        

                        (CONTINUED)

                        CONTINUED:
        Phasma heads off. Shattered, FN-2187 replaces his helmet.

                        CUT TO:

        INT. JUNKED VESSEL CORRIDOR - DAY

        A metal sheet is pulled open to reveal the wrapped up face
        of A SCAVENGER, perhaps alien, in GOGGLES, FACE MASK and
        GLOVES. Backpack with a STAFF strapped to it. Uses TOOLS
        to remove various MECHANISMS from inside the wall. We are
        in an upside-down, canted CORRIDOR. The Scavenger finds a
        valuable piece, drops it in a SATCHEL.
        Swings the bag back and begins CLIMBING DOWN on a cable,
        between treacherous WALLS OF MACHINERY, headed to:

        INT. JUNKED VESSEL - LARGER SPACE - LATER

        Alone and tiny in this massive, sideways wreck, the Scavenger
        descends, climbing down a two-hundred foot-long cable. LANDS
        HARD onto rusty metal.

        INT. JUNKED VESSEL - ENGINES - DAY

        The Scavenger carries the satchel and another large, found
        piece, over enormous pipes in the vast space, heads through
        the dust toward a distant SLIT OF SUNLIGHT.

        EXT. JUNKED VESSEL ENGINE - DAY

        The Scavenger arrives from the darkness and pulls off goggles
        and gear, revealing the grimy face of a beautiful, young
        WOMAN. This is REY, 19.
        She opens her canteen, shakes out the two final drops into
        her mouth. HITS THE SIDE of the canteen again and again for
        whatever she can get. CUT WIDE:
        Rey is rendered minuscule, standing at the bottom of an EPIC

        ENGINE OF A DECAYING, CRASHED STAR DESTROYER -- DISTANT SOUND
        of her canteen-hitting. She sets her things on a piece of
        sheet metal and sits next to it, sliding down the sand dune.
        She RIDES DOWN THE MOUNTAIN OF SAND. WE HOLD FOR A LONG
        TIME, looking down, as she recedes from us, toward the distant
        SALT FLATS below. Random SCATTERED DEBRIS. Her SPEEDER,
        tiny from here.
        Rey moves to her junker SPEEDER, jumps on, fires the sputtery
        engine and DRIVES OFF.

        EXT. DESERT - SPACESHIP GRAVEYARD - DAY

        Rey races along the desert floor: a GRAVEYARD OF CRASHED

        SPACESHIPS.

        EXT. NIIMA OUTPOST - DAY

        Rey's speeder PASSES us, heading for a dusty, desert town.
        Refueling, small trade, scavengers.

                        

                        (CONTINUED)

                        CONTINUED:
        CRASH! Rey's sack carrying her heavy FOUND OBJECTS hits the
        sand. Working like a tough seaman, Rey hauls the sack from
        her speeder toward the town.

        EXT. NIIMA OUTPOST - CLEANING TABLE - DAY

        TIGHT ON REY'S HANDS as she SCRUBS CLEAN her day's salvage.
        Rey glances up: she looks at an old woman, also cleaning
        some salvage.
        Rey watches her, gets lost in the simple moment. A small,
        passing alien UNDERLING barks something to her in another
        language. She returns to work.

        INT. NIIMA TRADING STRUCTURE - DAY

        Rey looks up to a SERVICE WINDOW: two feet above her, behind
        a protective screen, is her boss, UNKAR PLUTT (50, blobfish,
        unclean). He examines her pieces. Then he offers:

                        UNKAR
        What you've brought me today is
        worth... Hmmm... One quarter
        portion.
        Though disappointed, Rey barely shows it. She nods thanks.
        Unkar pushes through his transfer drawer a SEALED PACKET:
        DRIED GREEN MEAT in one section, BEIGE POWDER in another.
        She takes it.
        She swallows her resentment and heads off.

        EXT. NIIMA OUTPOST - DAY

        The IMMENSE SETTING SUN against the FLAT TERRAIN. Rey's
        SPEEDER races, almost insignificant, across frame.

        INT. REY'S DWELLING - DAY

        She SCRATCHES MARKS into the rusty wall. Another MARK;
        another DAY. And there are THOUSANDS of marks.
        A SIZZLING SOUND over: A DRIED DESERT FLOWER in a rusty ENGINE
        PIECE. A rough, stuffed HANDMADE DOLL, made from what looks
        like orange Rebellion flight suit material and twine.
        Rey's lonely, ramshackle dwelling. Everything reclaimed.
        She cooks for one. Does everything for one. She opens the
        POWDER, moves to the makeshift WOK, where the GREEN MEAT
        SIZZLES. Pours the powder into milky WATER in a tin. Stirs
        it. It GROWS INTO A LOAF as she puts the meat on an old
        plate. Grabs the loaf.

        EXT. REY'S DWELLING - DUSK

        Rey sits, eats like a starving child. Every last drop.
        Licks the metal plate. Looks out at the horizon. A single
        silent ship heads off, a shimmering, thin contrail. She
        wipes her mouth. Picks up an old, broken REBELLION HELMET.

                        

                        (CONTINUED)
        CONTINUED: just 'cause.
        Puts it on,
        WIDE SHOT of Rey sitting, alone and isolated, on the leg of
        an ANCIENT, FALLEN AT-AT in which she lives.
        Then, a distant ELECTRONIC SQUEAL -- instantly she's up,
        helmet too big, she rips it off. Hears ANOTHER BEEPING
        SQUEAL. She hurries to her QUARTERSTAFF and runs off.
        Rey climbs a dune. RISE WITH HER, revealing BB-8, caught in
        a NET but fighting back, being held by a TEEDO (a small,
        brutish desert tyrant), who rides a LUGGABEAST. The teedo
        YELLS at BB-8, who BEEPS madly, struggling to free himself.
        Rey watches this injustice for a beat, finally YELLING OUT:

                        REY
        Tal'ama parqual!
        The Teedo and BB-8 STOP, GO SILENT, turn to her.

                        REY (CONT'D)
        Parqual zatana!
        A half beat and the Teedo YELLS SOMETHING BACK, threatening.
        BB-8's head swivels to him, then back to Rey, like watching
        a tennis match.
        Rey angrily moves to them, pulling a knife from her pouch.
        Rey starts CUTTING BB-8 out of the netting. The Teedo freaks
        out, YELLING. Rey suddenly stands, turns to the Teedo and
        says, fiercely:

                        REY (CONT'D)

        NOMA.
        The Teedo barks a sort of "AHHHHH!" (As if to say, "GO TO
        HELL!"), Then heads off on his beast. This prompts BB-8 to
        start BEEP-YELLING at the departing bully, provocatively.

                        REY (CONT'D)
        Shhhh.
        BB-8 quiets instantly. The two watch the Teedo head off.
        Finally, BB-8 BEEPS a question. She KNEELS to him.

                        REY (CONT'D)
        That's just Teedo. Wants you for
        parts. He has no respect for anyone.
        Your antenna's bent.
        (considers BB-8 for
        the first time,

                        STRAIGHTENS THE

                        ANTENNA)
        Where do you come from?

                        (BB-8 BEEPS)
        Classified. Really? Me too. Big
        secret.
        (points to horizon)
        Niima Outpost is that way, stay off
        Kelvin Ridge.

                        (MORE)

                        

                        (CONTINUED)

                        CONTINUED:

                        REY (CONT'D)
        Keep away from the Sinking Fields in
        the north, you'll drown in the sand.
        (stands, heads off)

                        
        BB-8 starts after her, BEEPS. She turns sharply, he stops.

                        

                        

                        REY (CONT'D)
        Don't follow me. Town is that way.
        (he BEEPS again)
        No!
        She heads off again. Finally he BEEPS to her -- something
        SWEET this time. That he is alone, scared, has no one else.
        This makes her stop. She turns and looks at him. Not liking
        him. But a gesture of her head says, reluctantly, "Come
        on." BB-8 quickly moves to her. They head off together.

                        REY (CONT'D)
        In the morning, you go.

                        (HE BEEPS)
        You're welcome.
        The two disappear behind a dune.

        EXT. STAR DESTROYER - DAY

        Three TIE fighters head to the massive ship high above Jakku.

        INT. STAR DESTROYER HOLDING CELL - DAY

        POE, shackled to a chair, BEATEN, wakes up.

                        KYLO REN
        I had no idea we had the best pilot
        in the Resistance on board.
        Comfortable?
        Through battered lips:

                        POE
        Not really.

                        KYLO REN
        I'm impressed. No one has been able
        to get out of you what you did with
        the map.

                        POE
        Might wanna rethink your technique.
        Kylo Ren says nothing, reaches out to him. Poe flinches in
        the chair as Kylo Ren reaches for his face, not touching
        him. Poe is soon in agony, remains in horrible silence --

                        KYLO REN
        Where is it?

                        

                        

                        (CONTINUED)

                        CONTINUED:

                        POE
        The Resistance will not be intimidated
        by you.

                        KYLO REN
        Where... is it?
        Poe can't take it -- he BEGINS TO SCREAM and we CUT TO:

        INT. STAR DESTROYER CORRIDOR - DAY

        WHOOOSH! The cell door SLIDES UP. Kylo Ren exits, fierce,
        confronts GENERAL HUX (34, scary) who awaits him:

                        KYLO REN
        It's in a droid. A BB unit.

                        GENERAL HUX
        Well then. If it's on Jakku, we'll
        soon have it.

                        KYLO REN
        I leave that to you.

        EXT. NIIMA OUTPOST - DAY

        BB-8 is dropped to the sand.

                        REY
        Don't give up. He still might show
        up. Whoever it is you're waiting
        for. Classified. I know all about
        waiting.
        BB-8 BEEPTALKS a question.

                        REY (CONT'D)
        For my family. They'll be back.
        One day. Come on.
        She tries to force a smile, but can't, really. She heads
        off. BB-8 BEEPS... then heads after her.

        INT. NIIMA TRADING STRUCTURE - DAY

        Rey stands with BB-8 in front of Unkar Plutt, at his window.
        He reviews her goods. He glances quickly at BB-8.

                        UNKAR
        These five pieces are worth... Let
        me see here... One half portion.

                        REY

                        (OBJECTS)
        Last week they were a half portion
        each.
        She hates him. He leans forward.

                        

                        

                        (CONTINUED)

                        CONTINUED:

                        UNKAR
        What about the droid?

                        REY
        What about him?

                        UNKAR
        I'll pay for him.
        BB-8 doesn't like this at all. Rey is awkward, but curious.

                        UNKAR (CONT'D)
        Sixty portions.
        CLOSE ON HER. Stunned. Literally hungry for this amount of
        food, her stomach practically rumbles.
        BB-8 sees her interest and BEEPS furiously, not liking this
        conversation at all.
        She looks at Unkar. Looks down at BB-8. Considers it all.
        Finally, she hears herself say:

                        REY
        Actually... the droid's not for sale.

                        (TO BB-8)
        Come on.
        Unkar furious. Rey, then BB-8, head out. Recovering, Unkar
        watches her go with dark eyes. He picks up a communicator:

                        UNKAR
        Follow the girl and get that droid.
        He SLAMS the service window door SHUT.

        INT. STAR DESTROYER HOLDING CELL - DAY

        The cell door WHOOSHES OPEN -- a STORMTROOPER enters. Poe
        remains shackled, worse for wear. A TROOPER GUARD here.

                        STORMTROOPER
        Ren wants the prisoner.
        TIGHT ON POE, in pain, drained, as the Guard unshackles him.

        INT. STAR DESTROYER CORRIDOR - DAY

        An exhausted, handcuffed Poe is walked down the corridor by
        the Stormtrooper, who holds a blaster at Poe's body.

                        STORMTROOPER
        Turn here.
        Poe turns into a narrow passageway --

        INT. STAR DESTROYER NARROW PASSAGEWAY - DAY

        Heading down the narrow hall the Stormtrooper stops Poe.

                        

                        (CONTINUED)

                        CONTINUED:

                        STORMTROOPER
        Listen carefully: you do exactly as
        I say, I can get you out of here.

                        POE

                        (COMING TO)
        If -- what--?
        The Stormtrooper pulls off his helmet: IT IS FN-2187.

                        FN-2187
        This is a rescue, I'm helping you
        escape. Can you fly a TIE fighter?

                        POE
        You with the Resistance--?!

                        FN-2187
        What?

                        (THAT'S CRAZY)
        No no no! I'm breaking you out.
        Can you fly a TIE fighter?

                        POE
        I can fly anything. Why, why are
        you helping me?

                        FN-2187
        Because it's the right thing to do.

                        POE
        (it hits him)
        You need a pilot.

                        FN-2187
        I need a pilot.
        And Poe, seeing this is for real, smiles a hero's smile.

                        POE
        We're gonna do this.

                        FN-2187
        (unsure but hopeful)
        ... Yeah?

        INT. STAR DESTROYER HANGAR - DAY

        WIDE SHOT ESTABLISHING the hangar. Find FN-2187, again
        masked, walking with Poe. By all appearances he's escorting
        a prisoner. A group of OFFICERS passes in the opposite
        direction.

                        FN-2187
        Okay, stay calm, stay calm.

                        POE
        I am calm.

                        

                        

                        (CONTINUED)

                        CONTINUED:

                        FN-2187
        I'm talking to myself.

                        (BEAT)
        Not yet. Okay, go. This way.
        FN-2187 walks quickly toward the far wall -- Poe follows --
        up the stairs to a two-man SPECIAL FORCES TIE FIGHTER --

        INT. TIE FIGHTER - DAY

        FN-2187 and Poe (wincing, sore) drop into the back-to-back
        cockpit. FN-2187 pulls off his helmet as Poe removes his
        cuffs and jacket, fires up the ship with excitement.

                        POE
        I always wanted to fly one of these
        things. Can ya shoot?

                        FN-2187
        Blasters, I can!

                        POE
        Okay, same principal! Use the toggle
        on the left to switch between
        missiles, cannons, and mag pulse --
        use the site on the right to aim,
        triggers to fire!

                        FN-2187
        This is very complicated
        FWOOOOOOM! The TIE FIGHTER LURCHES FORWARD --

                        POE
        I can fix this.

        INT. HANGAR SIX CONTROL ROOM - DAY

        WIDE: see the ship STRUGGLE TO RISE, CABLES connected to it --
        PULL BACK FAST to REVEAL we're inside the main control room.

        STAR DESTROYER TECHNICIAN
        We have an unsanctioned departure
        from bay two.
        WHIP TO a FIRST ORDER COLONEL, who responds:

        FIRST ORDER COLONEL
        Alert General Hux and stop that
        fighter.

        INT. STAR DESTROYER HANGAR - DAY

        The TIE Fighter LIFTS OFF from the bay, rips CHARGING cables!
        Stormtroopers UNPACK and aim MEGABLASTERS.

        INT. TIE FIGHTER - DAY

        FN-2187 opens fire.

        INT. STAR DESTROYER HANGAR - DAY

        FN-2187 TEARS UP PARKED TIE FIGHTERS and GUN EMPLACEMENTS
        WITH WELL-AIMED, STRATEGIC LASER BLASTS! Hits the CONTROL

        ROOM!

        INT. HANGAR SIX CONTROL ROOM - DAY


        THE WINDOWS ARE BLOWN IN BY LASER BLASTS!

        INT. TIE FIGHTER COCKPIT - DAY


                        POE
        I got it!

        EXT. STAR DESTROYER - DAY

        The TIE Fighter blasts from the ship --

        INT. TIE FIGHTER - DAY

        Poe pilots -- amazed, almost enjoying it.

                        POE
        Woooahhh! This thing really moves.
        All right, we gotta take out as many
        cannons as we can or we're not gonna
        get very far!

                        FN-2187
        All right!

                        POE
        I'm gonna get us in position, just
        stay sharp!

        EXT. STAR DESTROYER - DAY

        The TIE Fighter ARCS BACK, DIVES THROUGH THE OPENING BETWEEN
        THE LEVELS OF THE MASSIVE SHIP, then FLIES DOWN AND BACK,
        along the ship's belly --

        INT. TIE FIGHTER - DAY

        Poe flies toward the CANONS --

                        POE
        Up ahead! Up ahead! You see it?
        I've got us dead centered. It's a
        clean shot.

                        FN-2187
        Okay, got it.
        FN-2187 gets a target, FIRES!

        EXT. STAR DESTROYER - DAY

        LASERS BLAST from the TIE Fighter -- A SERIES OF CANNONS
        EXPLODE! Our TIE Fighter SLICES THROUGH the debris!

        INT. TIE FIGHTER - DAY

        FN-2187 YELLS in celebration:

                        FN-2187
        YES! You see that?! DID YOU SEE

        THAT?

                        POE
        I saw it! Hey, what's your name?

                        FN-2187

        FN-2187!
        Poe reacts, this tells him volumes about FN-2187's history.

                        POE
        FN-whaa?

                        FN-2187
        That's the only name they ever gave
        me!

                        POE
        Well I ain't using it! FN, huh?
        Finn. I'm gonna call you Finn!
        That all right?
        Even in the madness, Finn can't suppress his smile.

                        FINN
        "Finn." Yeah, "Finn", I like that!
        I like that!

                        POE
        I'm Poe. Poe Dameron.

                        FINN
        Good to meet you, Poe!

                        POE
        Good to meet you too, Finn!

        INT. STAR DESTROYER MAIN BRIDGE - DAY

        General Hux looks over the shoulder of LIEUTENANT MITAKA, at
        a console.

                        LIEUTENANT MITAKA
        Sir, they've taken out our turbolasers--

                        GENERAL HUX
        Use the ventral cannons.

                        

                        

                        (CONTINUED)

                        CONTINUED:

                        LIEUTENANT MITAKA
        Yes, sir. Bringing them online --

        KYLO REN (O.S.)
        General Hux. Is it the Resistance
        pilot?
        Hux turns: Kylo Ren enters fast, looms large, angry.

                        GENERAL HUX
        Yes, and he had help.

                        (VEXED)
        From one of our own.
        PUSH IN ON REN as Hux says:

        GENERAL HUX (CONT'D)
        We're checking the registers now to
        identify which Stormtrooper it was.

                        KYLO REN
        ... The one from the village. FN-

        2187.
        Hux is unnerved that Ren knows -- he chalks it up to Ren's
        Force ability. Kylo Ren heads off.

                        LIEUTENANT MITAKA
        Sir. Ventral cannons hot.

                        GENERAL HUX
        Fire.

        EXT. STAR DESTROYER - DAY

        Massive WARHEAD LAUNCHERS SPIN and FIRE BLASTS toward the
        TIE fighter, which flies EVASIVE MANEUVERS -- most blasts
        hit the DEBRIS from the TURBOLASER DESTRUCTION.
        The TIE fighter then PULLS A BIG TURN, BACK TOWARD JAKKU,

        THE SANDY PLANET WHERE POE LEFT BB-8.

        INT. TIE FIGHTER - DAY


                        POE
        One's coming towards you. My right,
        your left. Do you see it?

                        FINN
        Hold on! I see it!

                        POE
        Nice shot.
        Finn looks up suddenly in alarm --

                        FINN
        Where are you going?

                        

                        

                        (CONTINUED)

                        CONTINUED:

                        POE
        We're going back to Jakku. That's
        where.

                        FINN
        No no no! We can't go back to Jakku!
        We need to get outta this system!
        NEAR-MISS LASER BLASTS as Poe pilots aggressively.

                        POE
        I got to get to my droid before the
        First Order does!

                        FINN
        What - a droid?!

                        POE
        That's right. He's a BB unit! Orange
        and white: one of a kind.

                        FINN
        I don't care what color he is! No
        droid can be that important!

                        POE
        This one is, pal.

                        FINN
        We need to get as far away from the
        First Order as we can! We go back
        to Jakku, we die!

                        POE
        That droid's got a map that leads
        straight to Luke Skywalker!

                        FINN
        Oh, you gotta be kidding me!!! I--
        Suddenly BAM! THEY ARE HIT!

        EXT. TIE FIGHTER - DAY

        The TIE FIGHTER SPARKS AND SMOKES, SPIRALING out of control
        toward the surface of Jakku!

        INT. STAR DESTROYER MAIN BRIDGE - DAY

        Captain Phasma and General Hux stand before a holographic
        projection detailing FN-2187's service records.

                        CAPTAIN PHASMA
        FN-2187 reported to my division, was
        evaluated and sent to Reconditioning.

                        GENERAL HUX
        No prior signs of non-conformity?

                        

                        

                        (CONTINUED)

                        CONTINUED:

                        CAPTAIN PHASMA
        This was his first offense.
        A technician checks her readings, reports to General Hux.

                        TECHNICIAN #1
        General. They've been hit.

                        GENERAL HUX
        Destroyed?

                        TECHNICIAN #1

                        (GETTING READINGS)
        Disabled. They were headed back to
        Jakku -- the fighter's projected to
        crash in the Goazon badlands.

                        GENERAL HUX
        They were going back for the droid --
        send a squad to the wreckage.

        EXT. JAKKU DESERT - DAY

        TIGHT ON FINN'S FACE: His EYES OPEN. He goes from unconscious
        to terrified, fast. He sits up, looks around. CUT BACK
        WIDE: he sits in the middle of an EPIC DESERT, DUNES FOREVER.
        A BLACK CHUTE blows in the wind behind him, scattered debris.
        Then he sees, over distant dunes, RISING BLACK SMOKE. He
        gets up -- moves toward it, calling out:

                        FINN
        Poe! Poe!
        Finn scrambles over the massive dune to the TIE FIGHTER,
        SMOKING AND ON FIRE, small debris around it. He thinks he
        sees POE'S ARM -- he pulls on it, but it's JUST POE'S JACKET.
        He throws that off and tries to find a way in -- even a way
        to LOOK INSIDE, but the smoke and heat make it impossible.

                        FINN (CONT'D)
        Poe!!! POE!
        Suddenly the ship BEGINS TO SINK -- like it's being CONSUMED
        INTO QUICKSAND -- Finn is slipping in too --

                        FINN (CONT'D)

        POE!!! POE!!!
        It becomes clear fast: if Finn doesn't get away, he's gonna
        get sucked in too! So Finn scampers away from the TIE FIGHTER
        as it SINKS INTO THE SAND! We're in the Sinking Fields. A
        few moments and IT'S GONE.
        Finn's out of breath. Horrified. Then A GIANT EXPLOSION
        ERUPTS FROM below, SENDING SAND AND DEBRIS EVERYWHERE!
        Finn sees this, disoriented, scared, exhausted and defeated.
        And all alone.

        EXT. DESERT - DAY

        ENDLESS DUNES BEHIND HIM, Finn walks, removing pieces of his
        Stormtrooper gear, using Poe's FLIGHT JACKET for shade.

        EXT. DESERT - DAY

        Exhausted, Finn continues his trek across the endless, sandy
        nothingness.

        EXT. DESERT - DAY

        Finn, parched and losing hope, he walks to the edge of a
        massive dune, looks out into the epic valley below. Miles
        ahead: NIIMA OUTPOST.

        INT. STAR DESTROYER - BRIDGE - DAY

        General Hux and Kylo Ren walk the length of the bridge.

                        GENERAL HUX
        Supreme Leader Snoke was explicit.
        Capture the droid if we can, but
        destroy it if we must.

                        KYLO REN
        How capable are your soldiers,
        General?

                        GENERAL HUX

                        (WITH VITRIOL)
        I won't have you question my methods.

                        KYLO REN
        They're obviously skilled at
        committing high treason. Perhaps
        Leader Snoke should consider using a
        clone army.

                        GENERAL HUX

                        (YOU SON-OF-A-BITCH)
        My men are exceptionally trained --
        programmed from birth--

                        KYLO REN
        Then they should have no problem
        retrieving the droid. Unharmed.

                        GENERAL HUX
        Careful, Ren. That your "personal
        interests" not interfere with orders
        from Leader Snoke.

                        KYLO REN
        I want that map. For your sake, I
        suggest you get it.
        Ren heads off. Hux hates him.

        EXT. NIIMA OUTPOST - DAY

        Sun-scorched and exhausted, Finn stumbles out of the desert
        into the Outpost. In a heatstroke daze he moves past enormous
        old SHIP PARTS, MERCHANTS, SCAVENGERS and TENTED STALLS.

                        FINN
        Water... water... water..
        He sees a WATER TROUGH where a filthy, slobbering hippo-like
        creature (a HAPPABORE) DRINKS. Finn moves to it, uses his
        hands to desperately DRINK the filthy water. After a couple
        swallows he SPITS IT OUT, disgusted.

                        FINN (CONT'D)
        -- Awgh, GAH!
        But he's parched and immediately RETURNS FOR MORE.
        ACROSS THE MARKETPLACE, REY kneels with an emphatically

        BEEPING BB-8.
        Just then, TWO of UNKAR'S THUGS approach and stop her. One
        clearly tells her that they're taking the droid. BB-8 reacts
        nervously as Rey resists them -- one pulls a SACK over BB-8
        while the other grabs Rey's arm -- in the tussle, Rey KNOCKS
        OVER METAL URNS for sale --
        Finn, still drinking, is PUSHED OVER by the happabore. He
        falls to the ground, then turns to look when he HEARS
        CRASHING. He sees, through the tents, REY FIGHTING.
        He moves UP CLOSER to help this young woman being accosted --
        but he STOPS when Rey begins to FIGHT BACK -- scrappy and
        feral, she KICKS, BITES and HITS. Finn is taken aback as
        she DEFEATS the attackers, who hit the sand, hard.
        Finn just watches, stunned.
        Rey moves to the COVERED BB-8 -- PULLS THE SACK OFF OF HIM.
        Finn cannot believe his eyes. IT'S POE'S DROID!
        Rey talks to BB-8, who, nervous now, looks around and...
        SEES FINN! BB-8 STARTS BEEPING like crazy. Then something
        insane happens: REY LOOKS AT FINN.

                        REY
        (To BB-8) Who? Him?
        Finn is confused. Rey stands, staring at Finn, defiant.
        Finn can feel trouble coming -- and Rey begins CHARGING AT
        HIM, quarterstaff in hand.
        Realizing he's the target, Finn begins to RUN -- away from
        her, through the tent marketplace. Rey goes after him -- he
        turns a corner -- then another -- then BAM! She's got
        ahead of him and SLAMS HIM TO THE GROUND WITH HER STAFF!
        Finn is on his back, out of breath and freaked out. She
        holds the staff on him threateningly:

                        REY
        What's your hurry, thief?

                        FINN
        What--?! Thief?
        BB-8 ROLLS UP FAST, MOVES TO FINN -- a WELDING ARM TELESCOPES

        FROM HIS BODY AND SHOCKS FINN!

                        FINN (CONT'D)
        OW! HEY! What?!

                        REY
        The jacket! This droid says you
        stole it!

                        FINN
        I've had a pretty messed up day,
        alright?! So I'd appreciate it you
        stop accusing me -- OW!!!
        (BB-8 has ZAPPED him

                        AGAIN)

        STOP IT!

                        REY
        Where'd you get it? It belongs to
        his master.
        Finn looks at her -- then the agitated droid, Finn's mind
        racing. He puts it all together. Frustrated, but sighs
        heavily, needing to respond somehow. So he makes a hard
        decision: to tell the truth.

                        FINN
        It belonged to Poe Dameron. That
        was his name, right?
        Rey and BB-8 react, surprised and wanting more.

                        FINN (CONT'D)
        He was captured... by the First Order!
        I helped him escape but our ship
        crashed.

                        (RELIVING IT)
        Poe didn't make it.
        (sees BB-8 is sad,

                        ROLLS OFF)
        Look, I tried to help him. I'm
        sorry...
        BB-8 heads off to the side, depressed. Rey watches BB-8,
        then considers Finn again. Says, a bit impressed:

                        REY
        So you're with the Resistance?

                        

                        (CONTINUED)

                        CONTINUED:
        Finn's mind races again. He makes an easy decision: to lie.

                        FINN
        Obviously. Yes. I am. I'm with
        the Resistance, yeah.

                        (WHISPERS)
        I'm with the Resistance.
        Rey lowers her staff, Finn stands. Rey studies him:

                        REY
        I've never met a Resistance fighter
        before.

                        FINN
        Well, this is what we look like.
        Some of us. Others look different.

                        REY
        BB-8 says he's on a secret mission,
        he has to get back to your base.

                        FINN
        Apparently he's carrying a map that
        leads to Luke Skywalker, and
        everyone's after it.
        She turns to him, concerned, curious. And asks:

                        REY
        Luke Skywalker? I thought he was a
        myth.
        Just then BB-8 BEEPS MADLY at something he sees.

                        REY (CONT'D)
        What is it?
        Rey moves to him, peeks around a tent corner. Now Finn moves
        to see: at a distance, TWO STORMTROOPERS TALKING TO UNKAR'S
        THUGS -- who POINT THEIR WAY!
        Finn urgently grabs her hand and heads for the tents:

                        REY (CONT'D)
        (re: her hand)
        What are you doing?!

                        FINN
        Come on!
        Suddenly LASER BLASTS RIP PAST THEM, HIT THE CLEANING UNIT,
        SPEWING STEAM! Rey SCREAMS -- MORE BLASTS as they run!

        EXT. NIIMA OUTPOST - DAY

        Finn and Rey holding hands, the three race, ZIGZAGGING through
        a maze of tents:

                        

                        

                        

                        (CONTINUED)

                        CONTINUED:

                        FINN
        Come on, BB-8!

                        REY
        Let go of me!

                        FINN
        No, we gotta move!

                        REY
        (pulls her hand back)
        I know how to run without you holding
        my hand! BB-8 stay close! This
        way!
        Now Finn and BB-8 follow Rey -- ANOTHER BLAST just missing
        them! They disappear through a tent.
        TRACK FAST WITH STORMTROOPERS, through the tent maze. They
        come out of a tent, HAVING MOMENTARILY LOST THEIR TARGET.

                        STORMTROOPER
        Call in the air strike!
        REY, FINN AND BB-8 duck into another tent:

        INT. NIIMA OUTPOST - TENT - DAY

        Rey, Finn and BB-8 move through RUSTY WARES and take cover.
        Quiet, urgent:

                        REY
        They're shooting at both of us!

                        FINN
        Yeah, they saw you with me! You're
        marked!

                        REY
        Well, thanks for that!

                        FINN
        I'm not the one who chased you down
        with a stick! Does anyone have
        blasters around here?!

                        REY

                        (TO BB-8)
        Are you okay?
        Finn QUIETS HER WITH A GESTURE, HEARING SOMETHING.
        PUSH IN ON FINN -- whatever he hears alarms him greatly --
        he GRABS HER HAND AGAIN -- PULLS HER AWAY --

                        REY (CONT'D)
        Stop taking my hand!

        EXT. NIIMA OUTPOST - TENT - DAY

        Finn pulls Rey from the tent -- BB-8 FOLLOWS --
        As they race from the tent a TIE FIGHTER SCREAMS INTO VIEW

        FROM BEHIND THE TENTS! A SECOND FOLLOWS CLOSE BEHIND. IT

        FIRES AT THEM -- A MASSIVE BLAST SENDS REY AND FINN FLYING --

        BB-8 ROLLING!

                        

                        
        WIDE SHOT: TWO TIE FIGHTERS SCREAM OVER the town, the
        EXPLOSION throws sand and debris fifty feet into the air.
        Rey is thrown HARD to the ground -- she is rattled, truly
        afraid. Then she turns: FINN lies nearby, unconscious.
        Suddenly afraid, she scrambles to him, rolls him over. BB-8
        ROLLS OVER, BEEPING in concern.

                        REY
        Hey!
        As Finn comes to, he sees her. Through his fog:

                        FINN
        -- Are you okay?
        And that very question touches her -- having never in her
        life been asked it.

                        REY
        Yeah.
        (extends her hand)
        Follow me.
        Grateful, Finn takes it. They're off.
        LOCALS run amok as TIE fighters DIVE BOMB. REY, Finn and BB-

        8 SPRINT, BLASTER EXPLOSIONS GET CLOSER AND CLOSER!

        EXT. NIIMA OUTPOST - SPACEPORT - DAY

        Rey, STAFF strapped to her back, leads the way as she, Finn
        and BB-8 race into the spaceport. Finn glances back: TWO
        TIE FIGHTERS BANK their return. They YELL:

                        FINN
        We can't outrun them!
        Rey POINTS to a parked, four-engine SHIP ahead:

                        REY
        We might in that quad-jumper!

                        FINN
        We need a pilot!

                        REY
        We've got one!

                        

                        

                        (CONTINUED)

                        CONTINUED:

                        FINN
        You?!
        (then, indicates one

                        OFF-CAMERA)
        What about that ship?

                        REY
        That one's garbage!
        They run for the JUMPER but the passing TIE FIGHTERS FIRE AT
        IT, BLOWING IT APART IN A HUGE FLAME BALL! Rey, coming to a
        quick stop, RIGHT UP TO CAMERA:

                        REY (CONT'D)
        The garbage'll do!
        She turns and runs back -- Finn and BB-8 follow as they all
        run toward the piece of junk -- and we see it for the first
        time: THE MILLENNIUM FALCON!
        TIE fighters BANK AROUND AGAIN. Finn, Rey and BB-8 run up
        the ramp of the semi-tarped Falcon.

        INT. MILLENNIUM FALCON - DAY

        Finn, Rey and BB-8 enter the ship -- she hits a control and
        the door DESCENDS CLOSED as she races to the cockpit:

                        REY
        Gunner position's down there!

                        FINN

                        (CLIMBS DOWN)
        Y'ever fly this thing?

        INT. MILLENNIUM FALCON - COCKPIT - DAY

        Rey tosses her staff aside, jumps into the pilot's seat,
        frantically flips switches. BB-8 rolls in behind her as the
        ENGINES WHINE to life:

                        REY
        No! This ship hasn't been flown in
        years!

        INT. MILLENNIUM FALCON - GUNNER POSITION - DAY

        Finn buckles into the gunner seat -- to his shock the SEAT
        WHIPS TO THE LEFT, startling him -- he grabs the controls to
        steady himself.

                        FINN
        Great.
        (reacts to seat)
        Whoa! I can do this, I can do this--

        INT. MILLENNIUM FALCON - COCKPIT - DAY

        Rey bucks herself up. Doesn't believe her quick words:

                        

                        (CONTINUED)

                        CONTINUED:

                        REY
        I can do this, I can do this--
        Rey pulls the yoke:

        THE FALCON ENGINES LIGHT UP BRIGHT!

        EXT. NIIMA OUTPOST - SPACEPORT - DAY

        The FALCON RISES, WILDLY -- ITS TARPS FLY OFF -- THE SHIP

        SPINS AND TILTS, SLAMS INTO AND CRUMBLES THE TOWN'S ARCHWAY!
        From the tents, Unkar Plutt runs out, SCREAMS:

                        UNKAR

        HEY!!!! THAT'S MIIIIIIINE!!!
        The Falcon BLASTS AWAY, two TIE FIGHTERS chase it, fast!

        INT. MILLENNIUM FALCON - DAY

        Rey pilots, headed for the sky!
        Finn SWINGS into frame, trying to work the GUNS.

                        FINN
        Whoa! Hey! Oh! Stay low! Stay
        low!

                        REY

        WHAT?

                        FINN
        Stay low! It confuses their tracking!
        For a crazy instant Rey LETS GO OF THE YOKE, stretches to
        the co-pilot controls -- THE FALCON CANTS!

                        REY
        BB-8, hold on!
        Rey finally REACHES the switches, returns to the yoke,
        stabilizing the ship, afraid of this next move.

                        REY

        I'M GOING LOW!!!

        EXT. DESERT - DAY

        BEHIND THE FALCON as it DRAMATICALLY BANKS AT AN UPWARD ARC,
        UPSIDE-DOWN, then SWOOPS PERILOUSLY LOW across the sand.
        Two TIE FIGHTERS SCREAM past us!

        INT. MILLENNIUM FALCON - DAY

        In the cylindrical corridor, BB-8 ROLLS TO THE CEILING!
        Rey looks back for a flash as the TIE Fighters pass -- They
        are ROCKED BY A BLAST!

                        

                        (CONTINUED)

                        CONTINUED:

                        REY
        What are you doing back there? Are
        you ever gonna fire back?!

                        
        Finn flicks switches -- The GUN TARGETING LIGHTS UP:

                        FINN
        I'm working on it! Are the shields
        up?
        Rey strains, reaching for something in the co-pilot seat.

                        REY
        Not so easy without a co-pilot!
        Finn struggles with the gun controls and SWEEPING CHAIR:

                        FINN
        Try sitting in this thing!
        Finn finally FIRES BACK at the two TIE FIGHTERS!

        EXT. DESERT - DAY

        Finn's shots MISS. The TIE FIGHTERS ARC BACK IN PURSUIT and
        SCREAM PAST US toward the Falcon! Both TIES FIRING!

        INT. TIE FIGHTER COCKPIT - DAY

        The BLACK-SUITED PILOT FIRES at the Falcon.

        INT. MILLENNIUM FALCON - GUNNER POSITION - DAY

        The Falcon is ROCKED by another BLAST!

                        FINN
        We need cover, quick!

        INT. MILLENNIUM FALCON - COCKPIT - DAY

        Rey HITS SWITCHES, pilots the best she can:

                        REY
        We're about to get some!

                        (TO HERSELF)
        I hope.

        EXT. DESERT - DAY

        The Falcon speeds through a ROCK FORMATION, GRAZING THE ROCK,
        TAKING OUT A CHUNK -- the two TIE Fighters in pursuit, FIRING!
        The Falcon BANKS SO HARD, the edge of the ship RIPS A LINE
        IN THE SAND as it turns, REVEALING THE SHIP GRAVEYARD AHEAD.

        INT. MILLENNIUM FALCON - DAY

        BB-8 EXTENDS MAGNETIC CABLES to brace himself in a corridor.

                        

                        (CONTINUED)

                        CONTINUED:
        Finn continues to fire at the TIE fighters, narrowly missing
        them.

                        FINN
        Damn it!
        Rey maneuvers the ship deeper into the graveyard.

        INT. MILLENNIUM FALCON - GUNNER POSITION - DAY

        Finn SWOOPS into frame, FIRES --

                        FINN
        Come on... come on...
        -- HITS AND SHATTERS the TIE FIGHTER!

                        REY
        Nice shot!

                        FINN
        I'm getting pretty good at this!

        EXT. DESERT - SPACESHIP GRAVEYARD - DAY

        The TIE FIGHTER CRASHES amid the DEBRIS, THREE SCAVENGERS
        instantly there to consume the new bounty.
        The Falcon, pursued by the ONE REMAINING TIE FIGHTER, slaloms
        through the MASSIVE WRECKAGE, GRAZING THE OLD SHIPS as she
        goes, pieces flying.
        The TIE FIGHTER FIRES -- HITTING THE FALCON'S LOWER TURRET,

        SPINNING IT, JAMMING IT INTO FORWARD POSITION!

        INT. MILLENNIUM FALCON - GUNNER POSITION - DAY


        ALARMS BLARE --

                        FINN
        The cannon's stuck in forward
        position, I can't move it! You gotta
        lose 'em!

        INT. MILLENNIUM FALCON - COCKPIT - DAY

        The ship is HIT AGAIN -- afraid, Rey's mind races as she
        scans the area -- and gets an idea.

                        REY
        Get ready!

                        FINN
        Okay! For what?

        EXT. DESERT - SPACESHIP GRAVEYARD - DAY

        Rey pilots the ship up AND INTO THE REAR OF A CRASHED SUPER
        STAR DESTROYER! The final TIE FIGHTER FOLLOWS!

        INT. MILLENNIUM FALCON - DAY

        Finn peers out the window, realizing where they are:

                        FINN

        ARE WE REALLY DOING THIS?!

        INT. WRECKED SUPER STAR DESTROYER - DAY

        The two ships slalom debris inside the giant ship -- the
        Falcon GRAZING ONE SIDE, THEN THE OTHER, SPITTING SPARKS!

        INT. MILLENNIUM FALCON - DAY

        Rey, scared, girds herself as she quickly runs out of space
        in the wreck.

                        REY
        Oh no!
        Just as the TIE PILOT GETS A LOCK,
        Rey YANKS THE YOKE --

        EXT. DESERT - SPACESHIP GRAVEYARD - DAY

        The Falcon makes a HARD RIGHT TURN out of the Destroyer.
        Rey then CUTS POWER AND FLIPS THE SHIP SO BACK FACES FRONT!
        FINN CAN NOW SEE THE PURSUING TIE FIGHTER! He FIRES,

        DESTROYING IT!
        REY GUNS THE ENGINES again, FLIPS THE FALCON and FLIES AWAY
        as the TIE FIGHTER CRASHES!

                        FINN
        Whooo!
        The Falcon ROARS OFF, victorious, leaving the ship graveyard
        and disappearing into the clouds.

        EXT. SPACE - DAY

        The Falcon ROARS from Jakku off to space.

        INT. MILLENNIUM FALCON - COCKPIT - DAY

        Rey excitedly unbuckles her seatbelt and hurries back.

        INT. MILLENNIUM FALCON - CORRIDOR - DAY

        Rey races past BB-8, who is RETRACTING his safety restraints.
        Finn, adrenalized, climbs from the turret, meets Rey in the
        corridor, the LOUNGE in the b.g..

                        

                        

                        

                        

                        (CONTINUED)

                        CONTINUED: REY
        FINN Good shooting! Thanks! I--
        Now that was some I don't know! -- I've
        flying! How did you flown some ships but I've
        do that?! No one never left the planet!
        trained you? No one? Your last shot was dead
        That was amazing! on. You got him with one
        (beat) blast!
        You set me up for it! (laughs)
        (cocky) It was perfect!
        That was pretty good.
        They're just staring at each other now, seeing something odd
        and weird and wonderful -- two people totally inexperienced
        in joy and camaraderie.
        Bb-8 BEEPS something urgent -- she turns to the droid, kneels.

                        REY (CONT'D)
        You're ok. He's with the Resistance.
        He's going to get you home. We both
        will.

                        (TO FINN)
        I don't know your name.

                        FINN
        Finn. What's yours.

                        REY
        I'm Rey.
        BB-8 looks at him: really? Finn is reminded: HE'S LIED TO
        HER. She looks at Finn with a sweet smile.

                        FINN
        Rey...
        But before Finn can say anything they JUMP: across the lounge,
        STEAM BURSTS from under the grating.

                        REY
        Help me with this! Quick!
        They hurry to the grating, PULL IT UP together. BB-8 rolls
        over, watches.

                        FINN
        Whoa! What's going on?
        She goes below as BB-8 BEEPS concern.

        EXT. SPACE - DAY

        The First Order Star Destroyer above Jakku.

        INT. STAR DESTROYER BRIDGE - DAY

        Lieutenant Mitaka moves to Ren, who looks out across the
        star field. Mitaka swallows, uneasy with his task.

                        

                        

                        (CONTINUED)

                        CONTINUED:

                        LIEUTENANT MITAKA
        Sir. We were unable to acquire the
        droid on Jakku.
        Ren turns to look at him, he says nothing.

        LIEUTENANT MITAKA (CONT'D)
        It escaped capture aboard a stolen
        Corellian YT model freighter.

                        KYLO REN
        The droid... stole a freighter?

                        LIEUTENANT MITAKA
        Not exactly, sir. It had help.
        Ren says nothing. Which says everything. Mitaka sweats.

        LIEUTENANT MITAKA (CONT'D)
        We have no confirmation, but we
        believe FN-2187 may have been helped
        in the escape--
        Ren IGNITES HIS LIGHTSABER, TURNS AND SLASHES AT THE CONSOLE
        BEHIND HIM! HOLD ON Mitaka, who reacts, looks away -- winces.
        The horrible SOUNDS of Ren's rage continues. Finally Mitaka
        looks up. The metallic wall behind Ren is RIPPED with glowing
        scars.

                        KYLO REN
        Anything else?
        Mitaka hates to say the following, but:

                        LIEUTENANT MITAKA
        The two were accompanied by a girl.
        Ren reaches out -- Mitaka is suddenly, violently PULLED TOWARD
        REN, into his black glove:

                        KYLO REN
        What girl?

        INT. MILLENNIUM FALCON - LOUNGE AREA - DAY

        Rey's head POPS up from under the grating, surrounded by
        STEAM. An EMERGENCY ALARM BLARES.

                        REY
        It's the motivator! Grab me a Harris
        wrench -- check in there!
        As he checks a storage box, she disappears down below,
        overwhelmed by the technical issues --

                        FINN
        How bad is it?!

                        

                        

                        

                        (CONTINUED)

                        CONTINUED:

                        REY
        If we wanna live, not good!
        BB-8 watches as Finn searches A SELECTION OF TOOLS:

                        FINN
        They're hunting for us now, we gotta
        get outta this system!
        Rey re-emerges, Finn hands her the wrench.

                        REY
        BB-8 said the location of the
        Resistance Base is "need to know" --
        if I'm taking you there, I need to
        know!

                        FINN
        (Throws a tool)
        This?
        She catches it and goes under again, leaving Finn and BB-8
        alone. He contemplates telling her the truth. This is his
        moment. But instead he knees to BB-8, says quietly, urgently:

                        FINN (CONT'D)
        You gotta tell us where the base is.

                        (BB-8 BEEPS)
        I don't speak that. Alright, between
        us, I'm not with the Resistance,
        okay?
        (BB-8 backs up)
        -- I'm just trying to get away from
        the First Order -- but you tell us
        where your base is, I'll get there
        first -- deal?!
        (BB-8 COCKS his head)
        Droid, please.
        Rey pops up again:

                        REY
        Pilex driver, hurry!
        Finn moves for the tool.

                        REY (CONT'D)
        So where's your base?

                        FINN
        (searching, to BB-8)
        Go on BB-8, tell her.

                        (QUIETLY)
        Please!
        She and Finn look to BB-8 -- who considers the whole
        situation, then BEEPS.

                        

                        

                        

                        (CONTINUED)

                        CONTINUED:

                        REY
        The Ileenium system?
        Finn hands her the tool, surprised but thrilled -- Rey
        disappears below again.

                        FINN
        Yeah, the Ileenium system, that's
        the one -- get us there as fast as
        you can.
        A smiling Finn gives BB-8 a THUMBS UP. BB-8 quickly extends
        his WELDING TORCH and TURNS IT UPWARD, then retracts it.

                        REY
        I'll drop you two at Ponemah Terminal.
        I need the bonding tape, hurry!

                        FINN
        (searching for tape)
        What about you?

                        REY
        I gotta get back to Jakku!

                        FINN
        (loses his mind)
        BACK TO JAK--?! Why does everyone
        always wanna go back to Jakku?! !

                        REY
        No, that one! No. No. The one I'm
        pointing to! No. NO. NO. If we
        don't patch it up, the propulsion
        tank will overflow and flood the
        ship with poisonous gas!
        Bb-8 has moved to Finn -- TIPS HIS HEAD, shows him the tool.
        He throws her the tape, she disappears below:

                        FINN
        This?

                        REY
        Yes!

                        FINN
        Hey. Rey. You're a pilot -- you
        can fly anywhere! Why go back?!
        You got a family? You got a
        boyfriend? Cute boyfriend?
        The STEAM and ALARM STOP as Rey pops up, annoyed:

                        REY
        None of your business, THAT'S WHY!
        But then: ALL THE SHIP POWER GOES OUT. BB-8 is nervous.

                        

                        (CONTINUED)

                        CONTINUED:

                        FINN
        ... That can't be good.

                        REY

                        (HEADS OFF)
        -- No it can't be --

        FINN FOLLOWS REY TO:

        INT. MILLENNIUM FALCON - COCKPIT - DAY

        They plop into the seats, in a panic. She checks the dead

                        INSTRUMENTATION PANEL:

                        REY
        Someone's locked onto us -- all
        controls are overridden.
        Finn quickly, awkwardly climbs up, looks out.

                        REY (CONT'D)
        Get off. Get off! See anything?

                        FINN
        ... Oh no.

        EXT. SPACE - DAY

        The Millennium Falcon, powerless, is a sitting duck.
        SOMETHING EPIC appears from ABOVE: THE ANTENNA ARRAY IS THE

        FIRST WE SEE OF A MASSIVE FREIGHTER, ITS GIANT HANGAR OPEN

        LIKE A HUGE MOUTH WHICH SWALLOWS THE FALCON LIKE A WHALE!

        INT. MILLENNIUM FALCON - COCKPIT - DAY

        Finn PLOPS into his seat, horrified.

                        FINN
        It's the First Order.

                        REY
        What do we do-- there must be

                        SOMETHING --
        Finn's mind races -- then:

                        FINN
        You said poisonous gas --

                        REY
        -- Yeah, but I fixed that --

                        FINN
        Can you unfix it?
        Rey stares at him -- and gets his plan! They head off --

        INT. MILLENNIUM FALCON - LOUNGE AREA - DAY

        The GAS MASKS hanging in the lounge are GRABBED.

                        

                        (CONTINUED)

                        CONTINUED:
        Finn and Rey, gas masks on, quickly climb into the open
        grating area.

                        REY
        C'mon BB-8.
        They help BB-8 down, too: they both struggle like crazy, he
        weighs a TON.

                        FINN
        I got it.

                        REY
        Oooh...

                        FINN
        I'm okay. BB-8 get off me...

        UNDER THE GRATING
        Finn pulls the grating over them as Rey works on the controls.

                        REY
        You think this'll work on the
        Stormtroopers?

                        FINN
        Yeah. Their masks filter out smoke,
        not toxins.
        LIGHTS COME ON! SOUND of the SHIP RAMP LOWERING! Finn PULLS
        THE GRATING CLOSED as he says:

                        FINN (CONT'D)
        Hurry!

                        REY
        I'm hurrying!
        Suddenly the FALCON DOOR OPENS -- AND HAN SOLO AND CHEWBACCA
        BOARD THE FALCON, weapons at the ready. PUSH IN ON THEM,
        ready for combat, operating silently, with hand signals only.

                        HAN
        Chewie, we're home.
        Han gives Chewie a nod to check out the ship. Chewie heads
        off one way, Han in another.
        The grating above LIFTS OFF -- hands in surrender, they look
        up at Han, who's training his blaster on them, threatening.
        They're SCARED.

                        HAN (CONT'D)
        Where are the others? Where's the
        pilot?

                        REY
        ...I'm the pilot...

                        

                        (CONTINUED)

                        CONTINUED:

                        HAN
        You?
        Chewie MOAN-TALKS. Rey responds to him --

                        REY
        No, it's true: we're the only ones
        on board.

                        FINN
        You can understand that thing?

                        HAN
        And "that thing" can understand you
        too, so watch it. Come on outta
        there.
        They climb up -- BB-8 uses his magnetic arm to quickly pull
        himself out.

                        HAN (CONT'D)
        Where'd you get this ship?

                        REY
        Niima Outpost.

                        HAN
        Jakku?! That junkyard?

                        FINN
        Thank you! Junkyard!

                        HAN

                        (TO CHEWIE)
        Told ya we should've double-checked
        the Western Reaches!

                        (TO REY)
        Who had it, Ducain?

                        REY
        I stole it from Unkar Plutt. He
        stole it from the Irving Boys, who
        stole it from Ducain.

                        HAN
        Who stole it from me! Well, you
        tell him Han Solo just stole back
        the Millennium Falcon for good.
        Han walks away, takes in the ship: it's his again. Doesn't
        see that Rey is awed. His back to all of them, he smiles.
        Chewie responds as Han heads toward the cockpit.

                        REY
        This is the Millennium Falcon? You're
        Han Solo?

                        

                        

                        

                        (CONTINUED)

                        CONTINUED:

                        HAN
        I used to be.

                        FINN
        Han Solo? The Rebellion General?

                        REY
        No, the smuggler!

                        FINN

                        (TO CHEWIE)
        Wasn't he a war hero?!
        Chewie replies: "Yeah, I guess, kinda..." Rey calls out:

                        REY
        This is the ship that made the Kessel
        Run in fourteen parsecs...!

        INT. MILLENNIUM FALCON - COCKPIT - SAME

        Han enters the cockpit.

                        HAN
        Twelve! Fourteen.
        A moment of private joy. Then he sees something that ANNOYS

                        HIM:

                        HAN (CONT'D)
        Hey! Some moof-milker put a
        compressor on the ignition line!
        Han moves to the corridor.

        INT. MILLENNIUM FALCON - LOUNGE AREA - DAY


                        REY
        Unkar Plutt did. I thought it was a
        mistake too, puts too much stress on

                        THE HYPERDRIVE--

                        HAN

                        (OVERLAPPING HER)
        -- Stress on the hyperdrive--
        (who is she? Then:)
        Chewie, throw 'em in a pod, we'll
        drop them at the nearest inhabited
        planet.

                        REY
        Wait! No -- we need your help!

                        HAN
        My help?

                        REY
        This droid has to get to the
        Resistance base as soon as possible!

                        

                        

                        (CONTINUED)

                        CONTINUED:

                        FINN
        He's carrying a map to Luke Skywalker.
        Yup: Han stops in his tracks.

                        FINN (CONT'D)
        You are the Han Solo that fought
        with the Rebellion. You knew him.
        The mention of Luke has really hit Han. He turns to Finn.

                        HAN
        Yeah, I knew him. I knew Luke.
        Suddenly: a distant, METALLIC KA-CHUNK!

                        HAN (CONT'D)
        Don't tell me a Rathtar's gotten

                        LOOSE--
        Han hurries out -- they all follow, (Chewie, Rey, Finn, then
        BB-8), Finn with WILD CONCERN:

                        FINN
        Wait -- a what?! Did you just say
        Rathtars? Hey!

        INT. CARGO SHIP - HANGAR - DAY

        The Falcon is parked in this giant freighter's hangar. Han
        moves to a CONTROL PANEL, they all follow him.

                        FINN
        You're not hauling Rathtars on this
        freighter, are you?

                        HAN
        I'm hauling Rathtars.
        On the CONTROL PANEL: IMAGES ON SCREENS FROM ALL AROUND THE
        SHIP. Including the EXTERIOR, where a TRANSPORT SHIP is
        LANDING ON THE FREIGHTER. Han is fearful.

                        HAN (CONT'D)
        Oh great. It's the Guavian Death
        Gang -- they must've tracked us from
        Nantoon.
        Han heads off as:

                        REY
        What's a Rathtar?

        INT. CARGO SHIP - CARGO CONTAINER CORRIDOR - DAY

        Han leads our group down a LONG NARROW HALL lined with cargo
        containers.

                        

                        

                        

                        

                        (CONTINUED)

                        CONTINUED: HAN
        They're big and dangerous...

                        FINN
        Y'ever heard of the Trillia Massacre?!

                        REY
        No.

                        FINN
        Good.
        They turn a corner:

                        HAN
        I got three of 'em going to King
        Prana.

                        FINN
        THREE?! How'd you get them on board?

                        HAN
        I used to have a bigger crew.
        Chewie GROAN-TALKS, concurring.

        CUT TO: LOOKING UP AS A HATCH OPENS IN THE FLOOR. HAN AND

        CO. ARE THERE.

                        HAN
        Get below deck and stay there until
        I say so -- don't even think about
        taking the Falcon.

                        REY
        What about BB-8?

                        HAN
        He stays with me -- until I get rid
        of the gang, then you can have him
        back and be on your way.

                        FINN
        What about the Rathtars... where are
        you keeping them?
        A TERRIFYING BAM: a GROTESQUE RATHTAR GIANT TONGUE SLAMS
        into the CARGO CONTAINER window behind Finn, whose heart
        stops.

                        HAN
        There's one.

                        REY
        What are you gonna do?

                        HAN
        Same thing I always do: talk my way
        out of it.

                        (CHEWIE MOAN-TALKS)
        Yes, I do. Every time.

        INT. CARGO SHIP - NARROW CORRIDOR - DAY

        A PORTAL opens. The GUAVIAN DEATH GANG enters. One man in
        a SUIT (BALA-TIK), and five SECURITY SOLDIERS in badass
        UNIFORMS with ROUND-FACE HELMETS. They turn into and stop
        at one end of the corridor. Han, Chewie and BB-8 forty feet
        away in the middle of the long hall.

                        BALA-TIK
        Han Solo. You are a dead man.
        Han smiles innocently, friendly. BB-8 nervously looks back
        and forth at the gang, and Han.

                        HAN
        Bala-Tik. What's the problem?

                        BALA-TIK
        The problem is we loaned you fifty
        thousand for this job.

                        INTERCUT WITH:

        INT. CARGO SHIP - BELOW FLOOR GRATING - DAY

        They look up, trying to get a view.

                        REY
        Can you see them?

                        FINN
        No.
        They start crawling down the crawl space.

                        BALA-TIK
        I heard you also borrowed fifty
        thousand from Kanjiklub.

                        HAN
        You know you can't trust those little
        freaks! How long've we known each
        other?
        Rey and Finn arrive under the gang. They WHISPER:

                        REY
        They have blasters...

                        FINN
        A lot of 'em.
        We RISE THROUGH THE FLOOR to see the GANG and Han and company
        in the distance.

                        BALA-TIK
        The question is how much longer will
        we know each other? Not long. We
        want our money back now.

                        

                        

                        (CONTINUED)

                        CONTINUED:

                        HAN
        Ya think hunting Rathtars is cheap?
        I spent that money.

                        BALA-TIK
        Kanjiklub wants their investment
        back, too.

                        HAN
        I never made a deal with Kanjiklub!

                        BALA-TIK
        Tell that to Kanjiklub.
        The SOUND of a PORTAL OPENING. Han's face GOES WHITE as he
        turns to the OTHER END OF THE CORRIDOR, where KANJIKLUB
        MEMBERS APPEAR. A GANG in a MEDIEVAL BANDITO style.
        Han smiles uncomfortably at the Kanjiklub members. Its
        LEADER, TASU LEECH, out front. Han tries to play it off:

                        HAN
        Tasu Leech. Good to see you.
        Tasu speaks an alien language, we SUBTITLE:

                        TASU LEECH
        Wrong again, Solo. It's over for
        you.
        Tasu COCKS HIS WEAPON, there for blood. BB-8 is nervous.
        Finn and Rey react to the sounds of the new gang -- start
        CRAWLING BACK the other way to see them.

                        HAN
        Boys. You're both gonna get
        what I promised! Have I ever
        not delivered for you before?

                        BALA-TIK
        Yeah.

                        TASU LEECH
        Twice!
        Han realizes he's right.

                        HAN
        What was the second time?

                        BALA-TIK
        Your game is old. There's no one in
        the galaxy left for you to swindle.

                        TASU LEECH
        Nowhere left for you to hide.

                        

                        

                        

                        (CONTINUED)

                        CONTINUED:

                        BALA-TIK
        That BB unit... the First Order is
        looking for one just like it. And
        two fugitives.
        Finn and Rey SUDDENLY STOP CRAWLING, tense.
        BB-8 hides behind Han's leg. PUSH IN ON Han as he realizes:
        Finn and Rey are in real trouble.

                        HAN
        First I've heard of it.
        Below the grating, Finn and Rey look at each other, afraid.
        Above, another Kanjiklubber (RAZOO QIN-FEE) says (SUBTITLED):

                        RAZOO QIN-FEE
        Search the freighter.
        One of the Kanjiklubbers begins moving down the corridor,
        AIMING A FLASHLIGHT DOWN BELOW, searching for:
        FINN AND REY, in a QUIET PANIC BELOW: THEY START CRAWLING
        FAST in the opposite direction they came.
        Rey crawls off fast, Finn follows. They quickly arrive at
        a JUNCTION BOX AREA, Rey looking at the controls.

                        REY
        Wait wait wait wait. If we close
        the blast doors in that corridor, we
        can trap both gangs!

                        FINN
        Close the blast doors from here?

                        REY
        Resetting the fuses should do it.
        Rey begins RESETTING the FUSES, SPARKS shooting from them as
        they do. Finn quickly joins in.
        Rey and Finn FINISH resetting the fuses boxes. Rey smiles
        optimistically. Finn looks hopeful too.
        DOWN AN EMPTY ROW OF LARGE CONTAINERS, which OPEN -- and a
        GIANT RATHTAR -- an ENORMOUS, FIERCE AND RAVENOUS LAND OCTOPUS --

        SLITHERS OUT OF ITS CAGE!
        BACK UP TOP as BANKS OF LIGHTS BEGIN GOING OFF, ONE BY ONE.
        The GANGS look around.
        Han's eyes go wide -- he gets it -- and it's bad. QUIETLY:

                        HAN
        ... I got a bad feeling about this...
        Suddenly all the LIGHTS COME ON AGAIN -- even down below,
        where Rey realizes it hasn't gone as planned.

                        REY
        Oh no.

                        FINN
        Oh no, what?

                        REY

                        (PALE)
        Wrong fuses.

        IN ANOTHER CORRIDOR, BACK WITH THE GANGS:

                        BALA-TIK
        Kill them! And take the droid!
        The gangs AIM THEIR WEAPONS JUST AS A RATHTAR APPEARS BEHIND

        THE GUAVIAN DEATH GANG, GRABBING TWO MEMBERS! THE OTHERS
        SCREAM AND RUN! The gang FIRES BACK -- BLASTS FLY!
        Han and Chewie react, flinching -- then turn to Kanjiklub as
        a RATHTAR APPEARS BEHIND THEM, ROARING DEAFENINGLY! The
        Gang turns -- others run, FIRE AT IT.

        INT. CARGO SHIP CORRIDOR A - DAY

        Han, Chewie and BB-8 race down the hall -- A MEMBER OF THE
        KANJIKLUB GANG comes around the corner. Han PUNCHES him
        with one blow, throws him toward the Rathtar. They keep
        steppin....

        INT. CARGO SHIP - BELOW FLOOR GRATING - DAY

        Rey and Finn hurriedly crawl through the space below decks.

                        FINN
        This was a mistake!

                        REY
        Huge!

        INT. CARGO SHIP CORRIDOR A - DAY

        Two Guavian Death Gang members run through the ship -- passing
        Tasu Leech, who sees another Kanjiklub member down the
        corridor -- who gets GRABBED BY A TENTACLE! Tasu tries to
        help him, but he gets PULLED UP AND AWAY! Tasu hears a
        distant terror-scream of a Rathtar, and runs the other way.
        Other Kanjiklub members YELL at him to avoid that direction --
        they all turn a corner -- a RATHTAR IS THERE AND GRABS THE
        TWO OTHERS! Tasu FIRES at the beast and RUNS OFF -- and we
        land on a FLOOR HATCH, which opens. Rey and Finn climb out,
        quickly.

                        
        They turn a corridor --

                        REY
        What do they look like?

                        

                        (CONTINUED)

                        CONTINUED:
        Another corner -- and GANG MEMBERS ARE BATTLING A HORRIBLE
        RATHTAR! Rey COVERS HER MOUTH.

                        FINN
        They look like that.
        Finn yanks her away. They race around another corner -- a

        RATHTAR IS THERE!

                        FINN (CONT'D)
        This way!

                        REY
        Are you sure?
        They scream and run off -- but Finn is GRABBED, PULLED AWAY

        FAST!

                        REY (CONT'D)

        FINN!
        But the Rathtar's fast and TURNS A CORNER, losing Rey --

                        FINN

        REY!

        INT. CARGO SHIP CORRIDOR E - DAY

        TIGHT ON FINN as he's being yanked down the hall, SCREAMING
        as he struggles to get loose!
        Rey turns the corner -- Finn is gone -- nowhere to be seen.

                        REY

        FINN!!!!
        Without Finn, she is instantly distraught -- then she
        realizes: SHE'S JUST PASSED A CONTROL PANEL! Her eyes light
        up as she moves to it: a BANK OF VIDEO MONITORS OF THE SHIP --
        and there's Finn, being dragged by a Rathtar toward an OPEN
        BLAST DOOR. Rey's hand on the button, she waits... then

        SLAMS THE BUTTON!

        INT. CARGO SHIP CORRIDOR B - DAY

        The BLAST DOOR INSTANTLY CLOSES ON ONE OF THE RATHTAR'S
        TENTACLES! It SCREAMS IN PAIN, ITS SEVERED TENTACLE STILL
        WRAPPED AROUND FINN'S LEG! Finn scrambles up, desperately
        shaking the sticky tentacle off his leg!
        Rey arrives, runs to Finn, beaming to see him alive -- he is
        adrenaline-rushed, in shock:

                        REY
        Finn!

                        FINN
        It had me! But the door--!

                        

                        

                        (CONTINUED)

                        CONTINUED:

                        REY
        That was lucky!
        ANOTHER CORRIDOR - Finn and Rey run towards the Falcon.

        INT. CARGO SHIP CORRIDOR D - DAY

        Han, Chewie and BB-8 take cover, Han exchanging BLASTER FIRE
        with GANG MEMBERS AT THE OTHER END OF THE HALL.

                        HAN
        I got the door. Cover us!
        Chewie GROAN-AGREES. Chewie FIRES DOWN THE HALL as Han
        CROSSES THE CORRIDOR, BB-8 following nervously. As Chewie
        exchanges blaster fire, Han works the controls.
        THE HATCH OPENS (FALCON in the distance) -- just as CHEWIE
        IS HIT IN THE SHOULDER BY ENEMY FIRE! He goes down with a

        LOUD GROAN!

                        HAN (CONT'D)
        Chewie! You okay?
        Han GRABS CHEWIE'S BOWCASTER, FIRES at the DOOR CONTROLS,

        BADASS!

                        HAN (CONT'D)
        (looks at bowcaster)
        Wow. Come on! Come on!

        INT. CARGO SHIP HANGAR - DAY

        Run with Finn and Rey as they turn into the hangar, toward
        the Falcon. Han helps WOUNDED CHEWIE up the ramp, sees them.

                        REY
        Han!
        Finn and Rey race past BB-8 -- as they go up the ramp, Han
        says to Rey:

                        HAN
        You, close the door behind us!

                        (TO FINN)
        You take care of Chewie!
        Han and Rey race up the ramp as Finn heads up with Chewie,
        who SCREAMS WILDLY IN PAIN!

        INT. MILLENNIUM FALCON - COCKPIT - DAY

        Han stands at the navicomputer, hitting switches. Rey enters
        fast, moves past him to Chewie's seat.

                        HAN
        Hey, where are you going?

                        

                        

                        

                        

                        (CONTINUED)

                        CONTINUED:

                        REY
        Unkar Plutt installed a fuel pump
        too -- if we don't prime that we're
        not going anywhere.

                        HAN
        I hate that guy.
        Han sits as, Rey hitting buttons:

                        REY
        And you could use a co-pilot.

                        HAN
        I got one, he's back there.

        IN THE LOUNGE, CHEWIE IS IN PAIN --

        INT. MILLENNIUM FALCON - COCKPIT - DAY

        Han and Rey in the seats:

                        HAN
        Watch the thrust, we're goin' out of
        here at lightspeed --

                        REY

                        (SHOCKED)
        From inside the hangar? Is that
        even possible?

                        HAN
        I never ask that question until after
        I've done it.
        A RATHTAR JUMPS ONTO THE WINDSHIELD -- REY SCREAMS! Its
        GIANT MOUTH CHEWING AT THE GLASS! Han works the controls:

                        HAN (CONT'D)
        This is not how I thought this day
        was gonna go -- angle the shields --
        Hang on back there!
        IN THE LOUNGE, Chewie is in pain -- Finn going through a
        first aid kit -- the ship is HIT again --

                        FINN

                        (HUGE PROBLEM)
        No problem!

        INT. CARGO SHIP - HANGAR - DAY

        Three GANG MEMBERS race out here and FIRE AT THE FALCON --
        hitting FUEL LINES, BLASTING THE SHIP HARD!
        The ship is hit.

        INT. MILLENNIUM FALCON - COCKPIT - DAY


                        HAN
        Come on baby, don't let me down!
        He hits a switch -- but NOTHING.

                        HAN (CONT'D)
        What?!
        But Rey reaches over, hits a switch, matter-of-factly.

                        REY
        Compressor.
        Han doesn't like it but she's right -- he hits the switch
        again and the HYPERDRIVE FIRES! The hangar is FILLED WITH
        LIGHTSPEED BLAST as the ATTACKING GANG MEMBERS ARE BLASTED
        BACK LIKE DRY LEAVES. In the cockpit the RATHTAR RIPS AWAY
        as THE STARS STRETCH LIKE ELASTIC and we CUT TO:

        EXT. CARGO SHIP - DAY

        Camera ROTATES as the Falcon DISAPPEARS IN A STREAK, leaving
        the cargo ship behind.

        INT. CARGO SHIP - DAY

        PUSH IN on a HANGAR DOOR where Bala-Tik arrives at the window,
        SEETHING. Makes a CALL:

                        BALA-TIK
        Inform the First Order that Han Solo
        has the droid they want. And it's
        aboard the Millennium Falcon.

        EXT. STARKILLER BASE - DAY

        A pair of TIE fighters roar towards a magnificent PLANET,
        frozen WHITE. This is the STARKILLER BASE, a natural planet
        that has been hacked and modified into something sinister.
        Over this we HEAR a DEEP, almost SOOTHING VOICE. A voice
        very much in control, of power:

        SNOKE (V.O.)
        The droid will soon be delivered to
        the Resistance...

        INT. STARKILLER PLANET - ASSEMBLY ROOM - NIGHT

        KYLO REN and General Hux in a dark space, looking UPWARD at
        someone addressing them.
        We're in a massive and dark ASSEMBLY ROOM. Hundreds of DESKS
        in a stadium arc, focused on a platform where we see SUPREME
        LEADER SNOKE. Not entirely human, at nearly twenty-five
        feet tall. All of him a STONY GREY. Old, wounded, fragile
        and powerful, all at the same time.

                        

                        

                        (CONTINUED)

                        CONTINUED:

                        SNOKE
        ... Leading them to the last Jedi.
        If Skywalker returns, the new Jedi
        will rise.

                        GENERAL HUX
        Supreme Leader, I take full
        responsibility for th--

                        SNOKE
        General! Our strategy must now
        change.

                        GENERAL HUX
        The weapon. It is ready. I believe
        the time has come to use it. We
        shall destroy the government that
        supports the Resistance, the Republic.
        Without their friends to protect
        them, the Resistance will be
        vulnerable, and we will stop them
        before they reach Skywalker.
        Snoke considers. Almost seems to die for a moment. Then:

                        SNOKE
        Go. Oversee preparations.

                        GENERAL HUX
        Yes, Supreme Leader.
        General Hux, proud, cocksure, exits. Kylo Ren watches him
        go. Snoke SITS. A new intimacy in his voice.

                        SNOKE
        There's been an awakening. Have you
        felt it?

                        KYLO REN
        Yes.

                        SNOKE
        There's something more. The droid
        we seek is aboard the Millennium
        Falcon. In the hands of your father,
        Han Solo.
        Kylo Ren reacts with subtle, but real, surprise.

                        KYLO REN
        He means nothing to me.

                        SNOKE
        Even you, master of the Knights of
        Ren, have never faced such a test.

                        

                        

                        

                        

                        (CONTINUED)

                        CONTINUED:

                        KYLO REN

                        (STEELY RESOLVE)
        By the grace of your training, I
        will not be seduced.

                        SNOKE
        We shall see. We shall see.
        A gentle, satisfied nod from Snoke, and Kylo Ren, obsessed,
        filled up, exits. Snoke watches him disappear, a grotesque
        evil SMILE growing -- as he DISINTEGRATES -- Snoke has been
        a HOLOGRAM all along.

        EXT. LIGHTSPEED SPACE - DAY

        RACING with the Falcon through the STRINGLIGHT of lightspeed.

        INT. MILLENNIUM FALCON - DAY

        CHAOS: INTERCUT between the COCKPIT where Han and Rey pilot,
        ALARMS SOUNDING, problems everywhere, and the LOUNGE where
        CHEWIE YELPS as Finn nervously works to BANDAGE HIS SHOULDER.

        SPARKS!

                        HAN
        Electrical overload!

                        REY
        I can fix that!

                        HAN
        The coolant's leaking!

                        REY
        Try transferring auxiliary power to
        the secondary tank--

                        HAN
        -- Secondary tank, I got it!

        INT. LOUNGE:

        CHEWIE HOWLS IN PAIN! Finn hangs in there, wraps a bandage
        on Chewie's shoulder: Chewie ROARS. BB-8 scurries off.

                        FINN
        Chewie, come on! I need help with
        this giant hairy thing! Stop moving!
        Chewie!

        INT. FALCON COCKPIT:


                        HAN
        You hurt Chewie, you're gonna deal
        with me!

        INT. LOUNGE:

        As Finn struggles to bandage the Wookiee:

                        FINN
        Hurt him?! He almost killed me six
        times!
        (Chewie GRABS HIM by
        the collar, ROARS)
        Which is fine.

        INT. FALCON COCKPIT:


                        HAN
        This hyperdrive blows there's gonna
        be pieces of us in three different
        systems.
        Han at the controls when all the alarms STOP. Rey, satisfied,
        sits in the co-pilot seat. Han is confused.

                        HAN (CONT'D)
        What'd you do?

                        REY
        I by-passed the compressor.
        He looks at her. A little, appreciative laugh. Han exits,
        walking past BB-8.

                        HAN
        Move, Ball.

        INT. MILLENNIUM FALCON - LOUNGE AREA - DAY

        Han kneels at Chewie, who lies awake but recovering. Han
        checks his friend's wound with care. Chewie MOAN-TALKS.

                        HAN
        Nah, don't say that, you did great.
        Just rest.
        Han turns to Finn, who sits at the HOLOCHESS set, BB-8 beside
        him. This is awkward for Han, but damn, he means it:

                        HAN (CONT'D)
        Good job, kid. And thanks.

                        FINN
        You're welcome.
        Finn has accidentally hit a button on the chess set, and the
        PIECES appear, looking up at Finn, curiously. The pieces
        start to FIGHT as Finn fiddles with the controls, trying to
        turn it off.

                        HAN
        So, fugitives, huh?

                        REY
        The First Order wants the map.

                        (MORE)

                        (CONTINUED)

                        CONTINUED:

                        REY (CONT'D)
        (re: Finn and BB-8)
        Finn is with the Resistance...

                        (SHRUGS)
        ... I'm just a scavenger.
        Han gives Finn a skeptical once-over as Finn finally manages
        to TURN THE CHESS SET OFF as Rey enters. Han looks to BB-8.

                        HAN
        Let's see whatcha got.

                        REY

                        (TO BB-8)
        Go ahead.
        BB-8 rolls forward -- and suddenly PROJECTS A HOLOGRAPHIC

        MAP, FILLING THE ROOM. PLANETS, STARS, SYSTEMS.
        They all react. Chewie sits to look up. Han moves through
        stars, becomes reflective.

                        HAN
        This map's not complete. It's just
        a piece. Ever since Luke disappeared,
        people have been looking for him.

                        REY
        Why'd he leave?

                        HAN
        He was training a new generation of
        Jedi. One boy, an apprentice turned
        against him, destroyed it all. Luke
        felt responsible... He walked away
        from everything.

                        FINN
        Do you know what happened to him?

                        HAN
        There're a lot of rumors. Stories.
        The people who knew him the best
        think he went looking for the first
        Jedi temple.

                        REY
        The Jedi were real?

                        HAN
        I used to wonder that myself. Thought
        it was a bunch of mumbo-jumbo --
        magical power holding together good,
        evil, the dark side and the light.

                        (BEAT)
        'Crazy thing is, it's true. The
        Force, the Jedi, all of it. It's
        all true.

                        

                        

                        (CONTINUED)

                        CONTINUED:
        An alarm rings on the control station, prompting Han to toggle
        some switches. BB-8 cuts off the hologram. Chewie rises
        and moans to Han, but Han motions for Chewie to lay back

                        DOWN:

                        HAN (CONT'D)
        No, you rest.
        (To Rey and Finn)
        You want my help? You're getting
        it. Gonna see an old friend. She'll
        get your droid home. This is our
        stop.
        Han leaves towards the cockpit, Rey and Finn following.

        EXT. LIGHTSPEED TO SPACE - DAY

        BEHIND THE FALCON as it DROPS OUT OF LIGHTSPEED, revealing a
        BEAUTIFUL GREEN PLANET ahead, TAKODANA.

        INT. MILLENNIUM FALCON - COCKPIT - DAY

        Han pilots. Finn and BB-8 beside him, Rey as co-pilot.
        Han notices Rey looking out the windshield, almost in tears.

                        REY

                        (QUIETLY)
        ... I didn't know there was this
        much green in the whole galaxy...
        Han watches her -- sees a vulnerability that touches him.

        EXT. TAKODANA PLANET - DAY

        The Falcon CRESTS OVER an ENDLESS GREEN FOREST TO REVEAL a
        CASTLE on a picturesque LAKE.
        The Falcon lands near the castle, among dozens of WORN,
        smallish freighters.

        EXT. LANDING PAD - NEAR MAZ'S CASTLE - DAY

        Rey steps off the Falcon, UP TO CAMERA, BB-8 at her side.
        She takes in the towering stone CASTLE, FOREST to one side,
        LAKE to the other. Serene, beautiful, all new to her.

        INT. MILLENNIUM FALCON - LOUNGE AREA - DAY

        From BLACKNESS: a storage unit opens. Han rummages,
        retrieving old BLASTERS. Finn arrives behind him, concerned.

                        FINN
        Hey, Solo -- I'm not sure what we're
        walking into here --

                        HAN
        D'you just call me "Solo"?

                        

                        

                        (CONTINUED)

                        CONTINUED:

                        FINN
        Sorry. Han-- Mr. Solo. You should
        know, I'm a big deal in the
        Resistance. Which puts a real target
        on my back. Are there any
        conspirators here? First Order
        sympathizers?

                        HAN
        Listen big deal, you've got another
        problem. Women always figure out
        the truth.
        Hands him a BLASTER.

                        HAN (CONT'D)
        Always.
        Han walks off. Finn watches him go, wracked with guilt.

        EXT. MAZ'S CASTLE - DAY

        Han hands Rey a blaster pistol as she stands at looks at the
        castle.

                        HAN
        You might need this.

                        REY
        I think I can handle myself.

                        HAN
        I know you do. That's why I'm giving
        it to you. Take it.
        Rey picks it up. Grips it.

                        HAN (CONT'D)
        You know how to use one of these?

                        REY
        Yeah, you pull the trigger.

                        HAN
        There's a little bit more to it than
        that. You got a lot to learn. You
        got a name?

                        REY
        Rey.

                        HAN
        Rey. I've been thinkin' about
        bringing on some more crew, Rey. A
        second mate. Someone to help out.
        Someone who can keep up with Chewie
        and me, appreciates the Falcon.

                        

                        

                        

                        (CONTINUED)

                        CONTINUED:

                        REY
        Are you offering me a job?

                        HAN
        I wouldn't be nice to you. It doesn't
        pay much.

                        REY
        You're offering me a job.

                        HAN
        I'm thinking about it.
        Rey wants to say yes. But something stops her. A line she
        can't cross.

                        HAN (CONT'D)
        Well?

                        REY
        If you were, I'd be flattered. But
        I have to get home.
        Han looks at her, questioningly.

                        HAN
        Jakku?
        Rey looks off, in thought. Yeah, Jakku.

                        REY

                        (BEAT)
        I've already been away too long.

                        HAN

                        (TO CHEWIE)
        Chewie, check out the ship as best
        you can.

                        HAN (CONT'D)
        It's too bad. Chewie kind of likes
        you.
        Han heads off. HOLD on Rey.

        EXT. MAZ'S CASTLE - DAY

        Han walks them to the castle.

                        FINN
        Solo, why are we here again?

                        HAN
        To get your droid on a clean ship.

                        REY
        Clean?

                        

                        

                        

                        (CONTINUED)

                        CONTINUED:

                        HAN
        Do you think it was luck that Chewie
        and I found the Falcon? If we can
        find it on our scanners, the First
        Order's not far behind. Want to get
        BB-8 to the Resistance? Maz Kanata
        is our best bet.

                        FINN
        We can trust her, right?

                        HAN
        Relax, kid. She's run this watering
        hole for a thousand years. Maz is a
        bit of an acquired taste, so let me
        do the talking. And whatever you
        do, don't stare...

        REY AND FINN
        At what?

                        HAN
        Any of it.
        The door opens. Music. Madness. And...

        INT. MAZ'S CASTLE - MAIN ROOM - DAY

        We ENTER THE LOUD, CROWDED MESS of a hall -- PUSHING PAST a
        room full of rough and odd ALIENS AND HUMANS, who gamble,
        drink, scheme, negotiate, argue -- until we end up on the
        BACK of a tiny, thousand year-old, four foot tall ALIEN, who
        suddenly STARTS, as if SENSING something -- the Alien TURNS
        TO US: she is FEMALE, wearing large ADJUSTABLE GOGGLES.
        This is MAZ KANATA.

                        MAZ
        Han Solo!
        Everyone turns to look. It's ALL QUIET in here.

                        HAN
        (Sotto) Oh boy. (Louder, waving)
        Hey, Maz!
        NOISE returns. Maz walks to them, pushes someone away.

                        MAZ
        Where's my boyfriend?

                        HAN
        Chewie's working on the Falcon.

                        MAZ
        I like that Wookiee. I assume you
        need something. Desperately. Let's
        get to it.

                        

                        

                        (CONTINUED)

                        CONTINUED:
        Maz walks off, gesturing for them to follow. Finn and Rey
        are confused. Han indicates for them to follow. They do --
        passing the enormous GRUMMGAR, who sits with vixen BAZINE
        NETAL, who watches them suspiciously.
        A SMALL DROID (GA-97), who turns its head to see BB-8
        following Rey across the room. GA-97, now animated, makes a
        small TRANSMITTING SOUND, which is subtitled.

                        GA-97
        Alert the Resistance. Their missing
        droid is here!
        And we CUT TO:

        IN A DARK ALCOVE - MOMENTS LATER
        Bazine enters a shadowy space, stealthily makes a call on a
        communicator. Clearly, BAZINE IS A SPY. Subtitled:

                        BAZINE
        Inform the First Order... I've found
        the droid.

        EXT. STARKILLER BASE - DAY

        A massive Star Destroyer hovers over the hacked ice planet.

        INT. STAR DESTROYER - KYLO REN'S CHAMBERS - DAY

        A dark space. Kylo Ren, CLOSE TO CAMERA, addresses someone
        OFF-CAMERA whom we do not see.

                        KYLO REN
        Forgive me. I feel it again. The
        pull to the light. Supreme Leader
        senses it. Show me again, the power
        of the darkness, and I will let
        nothing stand in our way. Show me,
        Grandfather, and I will finish what
        you started.
        As his emotion builds, he stands and heads off -- we FOLLOW
        HIM, PIVOTING TO REVEAL who he was talking to: THE BURNT,

        ASHEN, GHOSTLY DEFORMED MASK OF DARTH VADER.

                        CUT TO:

        INT. MAZ'S CASTLE - TABLE - DAY

        Maz is putting together some FOOD as she says:

                        MAZ
        A map to Skywalker himself? You're
        right back in the mess.

                        HAN
        Maz, I need you to get this droid to
        Leia.

                        

                        (CONTINUED)

                        CONTINUED:

                        MAZ
        Hmm. No. You've been running away
        from this fight for too long. Han,
        nyakee nago wadda. Go home!

                        HAN
        Leia doesn't want to see me.

                        FINN
        Please, we came here for your help.

                        REY
        What fight?

                        MAZ
        The only fight: against the dark
        side. Through the ages, I've seen
        evil take many forms. The Sith.
        The Empire. Today, it is the First
        Order. Their shadow is spreading
        across the galaxy. We must face
        them. Fight them. All of us.

                        FINN
        There is no fight against the First
        Order! Not one we can win. Look
        around. There's no chance we haven't
        been recognized already. I bet you
        the First Order is on their way right--
        Finn stops, seeing Maz adjusting her goggles, scrutinizing
        him -- her eyes get HUGE.

                        FINN (CONT'D)
        What's this? What are you doing?
        Maz adjusts the goggles again. Her eyes get impossibly
        BIGGER. She grunts recognition. She hoists herself on the
        tabletop, knocking over food and plates, crawling towards
        Finn.

                        FINN (CONT'D)
        Solo, what is she doing?

                        HAN
        I don't know, but it ain't good.

                        MAZ
        If you live long enough you see the
        same eyes in different people. I'm
        looking at the eyes of a man who
        wants to run.

                        FINN
        (eyes on Maz)
        You don't know a thing about me.
        Where I'm from. What I've seen.

                        (MORE)

                        

                        

                        (CONTINUED)

                        CONTINUED:

                        FINN (CONT'D)
        You don't know the First Order like
        I do. They'll slaughter us. We all
        need to run.
        Rey is stunned. Maz, not so much. She crawls back to her
        chair. She points to some pirates in the corner.

                        MAZ
        You see those two? They'll trade
        work for transportation to the Outer
        Rim. There, you can disappear.
        Finn sees them. Considers.

                        REY
        Finn!

                        FINN
        Come with me.

                        REY
        What about BB-8? We're not done
        yet. We have to get him back to
        your base.

                        FINN
        I can't.
        Finn stands to leave. He offers the gun back to Han.

                        HAN
        Keep it, kid.
        Finn heads off. Rey gets up to follow. Maz dials her lenses
        back to normal, and turns to Han.

                        MAZ
        Who's the girl?

                        ON FINN
        Who has arrived at the table with the ALIEN SMUGGLERS.

                        FINN
        I was told you could get me to the
        Outer Rim.
        Rey barges into the conversation, interrupting.

                        REY
        What are you doing?
        Finn gets up to talk to her.

                        FINN
        (to Big Head)
        Don't leave without me.

                        

                        

                        (CONTINUED)

                        CONTINUED:
        Embarrassed, Finn moves her away.

                        REY
        You can't just go. I won't let you.

                        FINN
        I'm not who you think I am.

                        REY
        Finn, what are you talking about?

                        FINN
        I'm not Resistance. I'm not a hero.
        I'm a Stormtrooper.

                        (STOPS HER)
        Like all of them, I was taken from a
        family I'll never know. And raised
        to do one thing...

                        (EMOTIONAL)
        But my first battle, I made a choice.
        I wasn't going to kill for them. So
        I ran.

                        FINN (CONT'D)
        Right into you. And you looked at
        me like no one ever had. I was
        ashamed of what I was. But I'm done
        with the First Order. I'm never
        going back. Rey, come with me.

                        REY
        Don't go.

                        FINN
        Take care of yourself. Please.
        Rey looks at him, crushed. With quiet resignation, Rey
        watches Finn return to the aliens...
        And all three head off. He gets to the front door and walks
        through it.
        Rey is heartsick, but she turns as she hears the sound of a
        young girl in anguish, crying. She follows the sound into
        the castle, turning so she can't see that Finn has looked
        back at her one last time.

        INT. MAZ' CASTLE - BASEMENT CORRIDOR - DAY

        Rey steps down into the basement corridor. BB-8 follows
        her. Walking carefully and confused, she is not sure why
        she's down here. She can hear the echoing sounds of a young
        girl crying. She heads down the hall... to the very end,
        where there is a door. It is almost as if a SOULFUL VIBRATION
        draws her closer. She looks at the door lock -- AND THE

        DOOR OPENS.
        Hesitant, Rey enters.

        INT. MAZ'S CASTLE - CRYPT ROOM - DAY

        Rey moves into the dark, small, vaulted storage room. Old
        treasures line the floors and walls, but there is something
        specific Rey is drawn to: on a table, an old wooden BOX.
        She moves to it, unsure, afraid, as if an energy from inside
        the box has been calling her here. BB-8 nervously follows.
        Rey reaches out, very slowly, to touch the box. A moment
        heavy with tension.
        Rey OPENS THE BOX and sees inside Luke Skywalker's original
        lightsaber. With hesitation, she reaches towards it, but
        she cannot resist. As her hand makes contact with it, there
        is the piercing sound of a lightsaber igniting. She moves
        her hand away, as REY HEARS A MECHANICAL BREATHING sound.
        The CAMERA MOVES, LIGHTING CHANGES -- and we see behind her
        something impossible: a HALLWAY OF FROM DEEP INSIDE CLOUD
        CITY. Disembodied voices fill the air.

                        YOUNG GIRL

        NO!
        She stands -- looks around, confused by all she sees and
        hears. -- Turns and sees, through a DOORWAY.
        We follow Rey and she runs down the corridor, but it all
        TILTS -- TURNS -- and she lands on the
        WALL -- which is now the GROUND -- dried GRASS.
        She turns to look -- we PIVOT -- and see a BURNING TEMPLE AT
        NIGHT. We PAN to:
        R2-D2 -- who watches the flames -- and a MAN appears (LUKE,
        whose face we do not see). He falls to his knees, reaches
        out to the droid -- with a MECHANICAL RIGHT HAND.
        We PUSH IN ON REY as RAIN BEGINS -- and DAY TURNS TO NIGHT --
        and she LOOKS UP -- we TILT UP --
        To see we're LOOKING UP AT A WARRIOR as he is STABBED BY A
        FIERY LIGHTSABER! He screams and falls to the ground -- we
        FOLLOW HIM, revealing Rey again, now in a nighttime
        battlefield. She gets to her feet, frightened by what she
        sees. We PIVOT AROUND HER to REVEAL KYLO REN, and the six
        other KNIGHTS OF REN, who flank him!
        Come back around to Rey, soaking now, as the RAIN STOPS and
        SUNLIGHT illuminates her -- she turns to look -- we PIVOT --
        and see...
        A little girl. Rey as a child. She is sobbing, hysterical.
        Unkar Plutt's meaty hand holds her thin arm. She is on Jakku,
        watching a starship fly into the sky, abandoning her.

                        YOUNG GIRL
        No, come back!

                        

                        

                        (CONTINUED)

                        CONTINUED:

                        UNKAR PLUTT
        Quiet, girl!
        The ship flies towards the desert sun, which is strangely
        eclipsed, as if being eaten by darkness. Rey looks around
        her to see she is..
        In a NIGHTTIME, BARREN, SNOWY WOODS. She's losing her mind,
        confounded and lost and she gets to her feet, her breath
        seen in the frigid air -- and then: THE SOUND OF CLASHING
        LIGHTSABERS! She moves through the woods, toward the sound.
        Rey runs, heart pounding, when KYLO REN EMERGES FROM BEHIND
        A TREE! She stops, SCREAMS, FALLS BACK and LANDS IN:

        INT. MAZ' CASTLE - BASEMENT CORRIDOR - DAY

        She falls back, out of the room, suddenly sitting in the
        hall, out of breath, alarmed and perplexed.
        She HEARS something and turns to look.
        Maz stands at the end of the corridor, realizing what has
        just happened.

                        REY
        What was that? I shouldn't have
        gone in there.

                        MAZ
        That lightsaber was Luke's. And his
        father's before him and now, it calls
        to you!
        Rey stands, fast. Still overwhelmed, emotional, speechless.

                        REY
        I have to get back to Jakku.

                        MAZ
        Han told me.
        (reaches out, hold

                        REY'S HAND)
        Dear child. I see your eyes. You
        already know the truth. Whomever
        you're waiting for on Jakku, they're
        never coming back. But... there's
        someone who still could.

                        REY
        Luke.

                        MAZ
        The belonging you seek is not behind
        you. It is ahead. I am no Jedi,
        but I know the Force. It moves
        through and surrounds every living
        thing. Close your eyes. Feel it.

                        (MORE)

                        

                        (CONTINUED)

                        CONTINUED:

                        MAZ (CONT'D)
        The light. It's always been there.
        It will guide you. The saber. Take
        it.
        Rey suddenly stands.

                        REY
        I'm never touching that again. I
        don't want any part of this.
        And Rey runs off, passing Maz.
        Rey's mind is spinning -- she can't take it -- she turns and
        heads off, fast. BB-8 follows her. TIGHT ON MAZ, watching
        her go. Maz SIGHS, feeling for the young girl.

        EXT. MAZ'S CASTLE - DAY

        Rey exits the castle, needs to run, but doesn't know where.
        Heads toward the woods.

        EXT. FOREST - DAY

        Rey moves through the foliage, heart racing. Over this, we
        HEAR a RUMBLING -- intense, an OMEN of something horrible to
        come.

        EXT. STARKILLER BASE - ASSEMBLY AREA - DAY

        A massive rally: a thousand STORMTROOPERS, TIE FIGHTERS,
        OFFICERS and VEHICLES. BRUTALIST STRUCTURES, mountainous
        SNOWY LANDSCAPE. Addressing them at a podium, flanked by
        RED FIRST ORDER BANNERS, is HUX. His voice ECHOES:

                        GENERAL HUX
        Today is the end of the Republic!
        The end of a regime that acquiesces
        to disorder! At this very moment,
        in a system far from here the New
        Republic LIES to the GALAXY while
        secretly supporting the treachery of
        the loathsome Resistance. This fierce
        machine which you have built, upon
        which we stand, will bring an end to
        the Senate! To their cherished fleet!
        All remaining systems will bow to
        the First Order! And will remember
        this... as the last day of the
        Republic!

                        

        INT. STARKILLER BASE - CONTROL ROOM - DAY

        ENGINEERS perform FINAL FIRING PROTOCOL. There's a sense of
        nervousness -- WILL THIS MASSIVE WEAPON ACTUALLY WORK?

        EXT. STARKILLER BASE - ASSEMBLY AREA - DAY


                        GENERAL HUX

        FIRE!
        And Hux TURNS to give the signal as we CUT BACK WIDE -- a
        ROAR OF BOOTS ON PAVEMENT as the thousand Stormtroopers TURN
        to face an endless snowy landscape. WHAT IS ABOUT TO HAPPEN?!

        EXT. STARKILLER BASE - DAY

        A view PAST THE RALLY. For a moment, nothing. Then, eerily

        SILENT, AN IMPOSSIBLE BLAST OF FIRE LIGHT -- LIKE AN ATOMIC

        BOMB TEST TIMES A ZILLION -- BLASTS FROM MILES AWAY, INTO
        THE SKY! Seconds later, a TERRIBLE EXPLOSIVE ROAR!
        The Troopers -- everyone -- is nearly PUSHED BACK by the
        FORCE of it -- the magnitude! Many have to COVER THEIR EYES!
        For MILES around the FIREBEAM, ICE AND SNOW MELTS INSTANTLY!
        Runoff tunnels FLOODED with AN OCEAN OF FRESH WATER. AIRBORNE
        CREATURES by the thousands burst from trees and take flight.
        Hux watches, his eyes WILD WITH POWER AND EVIL. From HIS
        eyes, CUT TO:

        INT. STAR DESTROYER BRIDGE - DAY

        TIGHT ON KYLO REN as he watches the Starkiller firing.

        EXT. MAZ' CASTLE - DAY

        Finn boards the Alien Freighter. The SOUND FROM THE SKY
        makes him turn back. He sees the PATH OF FIRE and his blood
        runs cold, his heart sinks.

        EXT. REPUBLIC SYSTEM - NIGHT

        At a massive distance we see PLANETS THE REPUBLIC CAPITAL

        SYSTEM -- INCREASINGLY LIT, THEN POWERFULLY HIT BY THE VAST

        FIREBLAST WHICH OBLITERATES IT ALL!

        EXT. REPUBLIC CITY - NIGHT

        The galaxy CENTER OF GOVERNMENT at NIGHT. Impressive
        structures. Senators and dignitaries look in uncomprehending
        horror to the night sky. LIGHT GROWING --
        FROM A GREAT DISTANCE a CIRCLE OF FIRE -- LIKE A SMALL SUN

        APPEARING FROM NOWHERE AND GROWING CLOSE AND MASSIVE, TURNING
        NIGHT TO DAY! And in seconds THE FIRE BLOCKS OUT EVERYTHING

        ELSE, AND THE ENTIRE PLANET OF HOSNIAN PRIME IS INCINERATED!

        EXT. MAZ'S CASTLE - DAY

        A crowd of ALIENS files out from inside, all eyes on the
        FIRE IN THE SKY. Dozens of LANGUAGES exclaiming fear and
        horror. Find Han and Chewie moving out, looking up.

                        

                        

                        (CONTINUED)

                        CONTINUED:

        FINN (O.S.)
        It was the Republic.
        Han and Chewie turn as Finn arrives, moving quickly through
        the crowd. With dread:

                        FINN (CONT'D)
        The First Order, they've done it.
        Where's Rey?

        EXT. FOREST - DAY

        Rey races through the forest and finally comes to a stop,
        overwhelmed and exhausted. At an emotional breaking point,
        she has no idea where to go, who to turn to. Then she HEARS
        A BEEP -- turns to see BB-8, catching up with her.

                        REY
        What are you doing?

                        (HE BEEPS)
        You have to go back.
        (he BEEPS again)

                        REY (CONT'D)
        BB-8. No, you can't -- you have to
        go back, you're too important.
        They'll help you.
        Then, ANOTHER SOUND -- LOUDER NOW -- they LOOK UP AGAIN: in
        front of the system attack, A FLEET OF FIRST ORDER SHIPS
        ROAR OVERHEAD, TOWARD THE CASTLE! Rey's heart sinks: HER

        FRIENDS ARE IN DANGER!

        INT. MAZ'S CASTLE - BASEMENT CORRIDOR - DAY

        Maz leads Han, Finn and Chewie down the hall, fast:

                        MAZ
        I've had this for ages...

        MAZ'S CASTLE - TREASURE ROOM - DAY
        Maz opens the box -- holds out the lightsaber to Finn:

                        MAZ
        Kept it locked away.

                        HAN
        Where'd you get that?

                        MAZ
        A good question for another time.

                        (TO FINN)
        Take it! Find your friend!
        Finn grabs it as the room is SHAKEN by an above ground attack.

                        MAZ (CONT'D)
        Those beasts! They're here!

        EXT. FOREST - DAY

        Rey and BB-8 race fast back toward the castle -- EXPLOSION
        SOUNDS can be HEARD from the direction they're headed!

        EXT. FOREST - DAY

        Rey races through the trees -- sees Maz' castle -- BEING
        DESTROYED BY FIRST ORDER SHIPS! Aliens RUNNING, GETTING
        OBLITERATED by SCREAMING TIE FIGHTERS! Other TIE FIGHTERS
        and TRANSPORTERS LAND, STORMTROOPERS in attack.
        Just then, filtered RADIO CALLS get Rey's attention: nearby
        STORMTROOPERS have spotted her, AND FIRE!

                        STORMTROOPER
        FN-417, hold position!
        Rey takes cover, grabs her BLASTER -- but IT WON'T FIRE!
        She panics, then realizes:

                        REY
        Safety!
        SHE SWITCHES OFF THE SAFETY and FIRES BACK! HITS TWO TROOPERS
        and retreats, calls to BB-8:
        BB-8 follows Rey AWAY FROM THE CASTLE, firing back at more
        chasing Troopers!

        EXT. MAZ' CASTLE RUINS - DAY

        Kylo Ren moves through the DEBRIS. A Stormtrooper approaches:

                        STORMTROOPER #4
        Sir, the droid was spotted heading
        west, with a girl.
        Kylo Ren LOOKS BACK SHARPLY, in Rey's direction --

        EXT. FOREST - DAY

        Rey and BB-8 move swiftly, terrified -- she stops them:

                        REY
        You have to keep going, stay out of
        sight, I'll try to fight 'em off.
        (BB-8 BEEPS; bravely
        through her fear)
        I hope so, too.
        BB-8 BEEPS and heads off -- Rey RUNS and TAKES COVER behind
        a massive, mossy tree. TIGHT on her TERRIFIED FACE --

        EXT. CASTLE DEBRIS - DAY

        Han, Chewie, Finn and Maz, exhausted, CLIMB UP, peek through
        debris.

                        

                        

                        (CONTINUED)

                        CONTINUED:

                        HAN
        Come on, Chewie!
        Maz turns to Finn:

                        MAZ
        Rey and BB-8, they need you. Now
        go.

                        FINN
        I need a weapon.
        Maz grabs his wrist -- holds up his hand -- THE SABER.

                        MAZ
        You have one!
        He looks at her questioningly -- he's supposed to use the
        lightsaber?! He TURNS IT ON.
        HAN AND CHEWIE RUN, TAKE COVER from BLASTS, FIRING BACK at
        Stormtroopers, taking some out!

                        HAN
        Hey, can I try that?
        Han borrows Chewbacca's bowcaster, fires on Stormtroopers
        and sends them flying.

                        HAN (CONT'D)

                        (TO CHEWBACCA)
        I like this thing.
        FINN SURPRISES A STORMTROOPER WITH THE LIGHTSABER, then
        another! Untrained, he's athletic, brave, impressive. One
        Stormtrooper has a MACE --

                        STORMTROOPER
        Traitor!
        FINN and the TROOPER WITH THE MACE battle. The Mace Trooper
        KNOCKS FINN DOWN! The Stormtrooper is about to end him,
        when THE STORMTROOPER IS SHOT AND FALLS!
        Wide-eyed Finn sees Han run over, having fired the blast!
        Han helps him up.

                        HAN
        You okay, Big deal?

                        

                        FINN
        Thanks!
        But TEN STORMTROOPERS come over a RISE, BLASTERS AIMED.

                        STORMTROOPER
        Don't move! TK-338, we have targets
        in custody!

                        

                        (CONTINUED)

                        CONTINUED:
        No way out, they DROP THEIR WEAPONS: TIGHT on the LIGHTSABER
        as it HITS THE GROUND. A STORMTROOPER HAND picks it up.
        Han's MIND RACES as a SQUAD OF TROOPERS appears behind them.
        Finn, Han and Chewie are MARCHED by Stormtroopers back toward
        a transport, hands on their heads.
        But then -- A FAMILIAR ROAR RIPPING ACROSS THE LAKE -- Han
        turns -- they all do: coming toward them across the water, X-

        WINGS AND RESISTANCE SPACECRAFT APPEAR, BEGIN FIRING AT THE

        FIRST ORDER SHIPS!

        PUSH IN ON HAN, HOPE SURGING -- CHEWIE TALKS.

                        STORMTROOPER (CONT'D)
        We have incoming at two-eight-point-
        six! Move! Dispatch! Move!
        Scramble all squads! Repeat, scramble
        all squads! Anti-air cover en route
        to our position!

                        HAN
        It's the Resistance.
        One X-WING in particular -- MARKED IN BLACK -- SWOOPS DOWN
        and takes out the parked TIE FIGHTERS and Troopers!

        INT. POE'S X-WING - DAY

        It's Poe Dameron at the stick of his X-wing.

                        POE
        Go straight ahead and don't let these
        dogs scare you!

        JESS (V.O.)
        Copy that!

        SNAP (V.O.)
        We're with you, Poe!
        The Stormtroopers around Finn, Han and Chewie SCATTER, TOSSED
        in EXPLOSIONS! The LIGHTSABER LANDS AGAIN -- FINN PICKS IT

        UP.

                        HAN
        Quick!
        Chewie picks up his Bowcaster, Han takes the blaster. Shoots
        a Trooper.

                        FINN
        Woohoo! YEAH! That's one helluva
        pilot!

        INT. POE'S X-WING - DAY


                        POE

        WOOHOO!

        EXT. FOREST - DAY

        In the darkened woods, Rey, terrified, keeps her blaster
        aimed. Her eyes dart around for her pursuer.
        And then: THE UNIQUE SOUND OF KYLO REN'S RASPING LIGHTSABER
        COMING TO LIFE -- A SOUND she's HEARD BEFORE in the FORCEBACK.
        Rey's heart skips a beat: she's even more scared now.
        Kylo Ren appears from behind a tree -- Rey FIRES again and
        again -- Kylo Ren moves toward her, USING HIS LIGHTSABER TO

        DEFLECT EVERY BLAST.
        She FIRES ferociously, but Kylo Ren keeps coming! His hand
        rises -- Rey suddenly STOPS -- GASPS -- UNABLE TO MOVE.

                        KYLO REN
        The girl I've heard so much about.
        He walks AROUND HER, slowly, she won't let herself cry.

        KYLO REN (CONT'D)
        The droid.
        He comes around to see her face. After a scary beat he WHIPS

        HIS SABER UP TO HER EYES, ILLUMINATING HER FACE.

        KYLO REN (CONT'D)
        Where is it?

        WIDE SHOT: THE EPIC BATTLE BETWEEN RESISTANCE AND FIRST

        ORDER TROOPS, REFLECTED IN THE STILL LAKE.

                        STORMTROOPER
        Request air support!

        EXT. FOREST - DAY

        Kylo Ren TURNS OFF HIS SABER, reaches up... and REACHES
        TOWARDS REY'S FACE. She can't move, strains in agony. After
        a beat, surprised by what he finds, he removes his hand.
        She is relieved but still afraid.

                        KYLO REN
        The map. You've seen it.
        Rey is horrified. He TOUCHES HER FACE again: the pain, tears
        stream. Kylo Ren, taking more from her mind...
        She stares at him, TERRIFIED, straining in agony --
        Kylo Ren, mid-interrogation, TURNS TOWARD THE SOUND OF THE
        EXPLOSIONS. Stormtroopers APPROACH through the woods.

                        STORMTROOPER #5
        Sir, Resistance fighters! We need
        more troops.
        Kylo Ren TURNS BACK TO Rey, his hand still on her face.

                        

                        (CONTINUED)

                        CONTINUED:

                        KYLO REN
        Pull the division out. Forget the
        droid. We have what we need.
        A GESTURE from Kylo Ren and REY LOSES CONSCIOUSNESS, FALLS

        FROM FRAME!

        EXT. CASTLE DEBRIS - DAY

        The BLACK-MARKED X-WING SWOOPS DOWN again, FIRING, EXPLODING
        another TIE Fighter! On the ground:

                        STORMTROOPER
        Pull back the tree line!
        Han and Chewie dodge debris, FIRING and TAKING OUT TROOPERS.
        FINN takes out 2 TROOPERS with the blaster, then, out of
        breath, turns to see: Kylo Ren in the forest, CARRYING REY
        IN HIS ARMS, INTO HIS SHUTTLE! Finn's heart SHATTERS --
        Han stops -- turns -- sees Kylo Ren entering his shuttle.
        Han is ROCKED.

                        FINN

        NO!! REY!!!
        Heroically, Finn runs toward the shuttle through LASER BLASTS
        AND EXPLOSIONS, but the shuttle TAKES OFF -- Finn irrationally

        CHASES IT, SCREAMS DESPERATELY:

                        FINN (CONT'D)
        No, no, no, no... REY!!
        In crazed frustration, Finn stops running, watches the
        receding First Order ships, Rey their captive.

        EXT. FOREST - DAY

        BB-8 moves fast, then stops and looks up as the First Order
        ships RETREAT, OFF PLANET. A considered beat, and BB-8 heads

        BACK FOR THE CASTLE.

        EXT. MAZ'S CASTLE RUINS - DAY

        Post battle. Finn runs to Han:

                        FINN
        He took her! Did you see that? He
        took her. She's gone!

                        HAN

                        (WALKS PAST)
        Yeah, yeah, I know...
        And he and Chewie head off.

        EXT. MAZ'S CASTLE RUINS - DAY

        Han moves toward a RESISTANCE TRANSPORT landing in the debris.
        BB-8 rolls up beside him, in wait for the transport.
        ON HAN'S FACE, knowing exactly what's about to happen.
        Finally, the transport door opens.
        And standing there is LEIA.
        She sees Han and is stunned. A silent beat, husband and
        wife reunited for the first time in years. In the smoke and
        embers, no one says a word.
        Then C-3PO walks out from the transport, into the field:

                        C-3PO
        Goodness! Han Solo! It is I, See-
        Threepio!
        (sees Han, stops)
        You probably don't recognize me
        because of the red arm.
        (sees Leia,

                        INCREASINGLY AWKWARD)
        Look who it is! Did you see who?
        Oh. Excuse me, Prin-- uh, General.
        Sorry. Come along, BB-8. Quickly.

                        (BB-8 BEEPS)
        Yes, I must get my proper arm
        reinstalled.
        He hurries off. Finally, alone again.

                        HAN
        You changed your hair.

                        LEIA
        Same jacket.

                        HAN
        No, new jacket.
        Chewie glad to see Leia, greets her with a hug. Chewie MOANS
        a few words, looks at Han then boards the ship.
        It is complicated and loving and painful. Han says, quietly:

                        HAN (CONT'D)
        ... I saw him. Leia, I saw our son.
        He was here.
        Leia hears this.
        Maz watches through the smoke.

        EXT. SPACE - DAY

        The FALCON and surviving X-WINGS ROAR past camera toward a

        PLANET WITH GREEN FLORA AND A RING OF ASTEROIDS.

                        

                        (CONTINUED)

                        CONTINUED:
        This is D'QAR.

        EXT. D'QAR - DAY

        The SHIPS DESCENDING among grassy mounds and sunken
        structures.

        EXT. RESISTANCE BASE - DAY

        LARGE GRASS MOUNDS cover HANGARS, beneath the odd, giant
        trees. BOOM DOWN as RESISTANCE GROUND CREW direct an X-WING
        to a LANDING. In the FOREGROUND, another X-wing canopy OPENS,
        a PILOT climbs out. PAN TO REVEAL the landed Millennium
        Falcon. Finn runs down the ramp, UP TO CAMERA, desperate,
        searching.
        Then BB-8 SPEEDS RIGHT PAST HIM, almost knocking him down --
        Finn watches as BB-8 rolls over to the PILOT GETTING OUT OF
        THE BLACK-MARKED X-WING. The Pilot's helmet comes off.

        IT IS POE!
        Finn can't believe what he's seeing. And Poe, kneeling in
        WARM REUNION with BB-8, listens and reacts to something the
        droid tells him. Poe looks up and sees Finn -- and he can't
        believe it either! Poe smiles, points at Finn. From a
        distance, Finn gestures in sheer amazement that Poe is alive.

                        FINN
        Poe. Poe Dameron.
        They move to each other -- and embrace.

                        FINN (CONT'D)
        You're alive!

                        POE
        So are you!

                        FINN
        What happened to you?

                        POE
        What happened? I got thrown from
        the crash, woke up at night -- no
        you, no ship, nothing--
        BB-8 BEEPS -- Poe listens, turns to Finn.

                        POE (CONT'D)
        BB-8 says that you saved him.

                        FINN
        No, no, no. It wasn't just me.

                        POE
        You completed my mission, Finn.
        That's my jacket?

                        

                        

                        (CONTINUED)

                        CONTINUED:

                        FINN
        Oh here.

                        POE
        No, no, no. Keep it. It suits you.
        You're a good man, Finn.

                        FINN
        Poe -- I need your help.

        INT. RESISTANCE BASE - DAY

        MOVE FAST with Finn and Poe. Finn takes in this makeshift
        command center, buried deep among vines and roots. They
        arrive at Leia, who stands with a group of Resistance
        Officers, including ADMIRALS ACKBAR and STATURA:

                        POE
        General Organa. Sorry to interrupt,
        this is Finn, he needs to talk to

                        YOU --

                        LEIA
        (takes Finn's hand)
        And I need to talk to him. That was
        incredibly brave, what you did.
        Renouncing the First Order, saving
        this man's life --

                        FINN
        (surprised she knows)
        Thank you, ma'am -- but a friend of
        mine was taken prisoner--

                        LEIA
        Han told me about the girl, I'm sorry.
        Finn is startled -- Poe jumps in:

                        POE
        Finn's familiar with the weapon that
        destroyed the Hosnian system. He
        worked on the base.

                        LEIA
        We're desperate for anything you can
        tell us.

                        FINN
        That's where my friend was taken --
        I've got to get there, fast.

                        LEIA
        And I will do everything I can to
        help, but first you must tell us all
        you know.

        INT. RESISTANCE BASE - DAY

        Chewbacca sits on a bed in the med bay. DR. KALONIA uses a
        device to help heal his shoulder. Chewie TALKS.

        DR. KALONIA

                        (CHEWIE TALKS)
        That sounds very scary.

                        (CHEWIE TALKS)
        You must be so brave.
        Chewie agrees.

        INT. RESISTANCE BASE - DAY

        C-3PO takes the DATA DEVICE from BB-8 and inserts it into a
        BASE COMPUTER. THE PROJECTED MAP APPEARS in HOLOGRAM. Leia
        enters, studying it, dispirited. PAN as she moves, REVEALING
        HAN. C-3PO is here and some others.

                        C-3PO
        General, I regret to inform you, but
        this map recovered from BB-8 is only
        partially complete. And even worse,
        it matches no charted system on
        record. We simply do not have enough
        information to locate Master Luke.

                        LEIA
        I can't believe I was so foolish to
        think that I could just find Luke
        and bring him home.

                        HAN
        Leia...

                        LEIA
        Don't do that.

                        HAN
        Do what?
        She heads off.

                        LEIA
        Anything.
        Flummoxed, Han follows looking at C-3PO.

                        C-3PO
        Princesses.
        Han follows Leia across the base floor:

                        HAN
        I'm trying to be helpful!

                        

                        

                        

                        

                        (CONTINUED)

                        CONTINUED:

                        LEIA
        When did that ever help? And don't
        say the Death Star.

                        HAN

                        (SIGHS)

        INT. RESISTANCE BASE - DAY

        LOW WITH BB-8 as he rolls over and finds, under a dark and
        dusty tarp in a corner, R2-D2. BB-8 BEEPS at R2, pulls off
        the tarp and tries to start a conversation. But R2 DOESN'T
        RESPOND AT ALL. BB-8 tries again. Nothing. BB-8 NUDGES
        R2. Nothing. Then:

        C-3PO (O.S.)
        BB-8. You're wasting your time.
        BB-8 looks up at C-3PO, who stands there. C-3PO SIGHS.

        C-3PO (CONT'D)
        It is very doubtful that R2 would
        have the rest of the map in his backup
        data.

                        (BB-8 BEEPS)
        I am afraid not. R2-D2 has been in
        low power mode ever since Master
        Luke went away. Sadly, he may never
        be his old self again.

        INT. RESISTANCE BASE - DAY

        Leia hears the change in Han's voice and softens. She turns.

                        HAN
        Listen to me, will you? I know every
        time you... every time you look at
        me, you're reminded of him.

                        LEIA
        You think I want to forget him? I
        want him back!
        Han looks at her with sympathy.

                        HAN
        There was nothing we could've done.
        (hard for him to say)
        There was too much Vader in him.

                        LEIA
        That's why I wanted him to train
        with Luke. I just never should have
        sent him away. That's when I lost
        him. That's when I lost you both.

                        

                        

                        

                        

                        (CONTINUED)

                        CONTINUED:

                        HAN
        We both had to deal with it in our
        own way. I went back to the only
        thing I was ever good at.

                        LEIA
        We both did.

                        HAN
        We lost our son, forever.

                        LEIA
        No.

                        (LONG BEAT)
        It was Snoke.
        Han takes this in.

                        LEIA (CONT'D)
        He seduced our son to the dark side.
        But we can still save him. Me.
        You.

                        HAN
        If Luke couldn't reach him, how could

        I?

                        LEIA
        Luke is a Jedi... you're his father.
        There's still light in him. I know
        it.

                        GENERAL STATURA
        General, the reconnaissance report
        on the enemy base is coming.

        INT. STARKILLER BASE - HOLDING CELL - DAY

        Rey wakes, disoriented. She is in an angled, upright
        restraining rig. Looks over, startled to see Kylo Ren, mask
        in place, standing there.

                        REY
        Where am I?

                        KYLO REN

                        (LONG BEAT)
        You're my guest.

                        REY
        Where are the others?

                        KYLO REN
        You mean the murderers, traitors and
        thieves you call friends?
        (Rey stares at him)
        You'll be relieved to hear that I
        have no idea.

                        

                        

                        (CONTINUED)

                        CONTINUED:
        Rey studies him. She's fearful... but curious.

        KYLO REN (CONT'D)
        You still want to kill me.

                        REY
        That happens when you're being hunted
        by a creature in a mask.
        Kylo Ren stops, considers her... then reaches up, unlatches
        and REMOVES HIS MASK. Rey reacts, stunned. It takes a moment
        before she regains her own mask of defiance.

                        KYLO REN
        Tell me about the droid.

                        REY
        (a nervous beat)
        He's a BB unit with a selenium drive
        and a thermal hyperscan vindicator --

                        KYLO REN
        He's carrying a section of a
        navigational chart. We have the
        rest, recovered from archives of the
        Empire. We need the last piece.
        And somehow, you convinced the droid
        to show it to you. You. A scavenger --
        Rey reacts -- afraid -- how does he know?

        KYLO REN (CONT'D)
        You know I can take whatever I want.
        Trepidation flashes across Rey's eyes. Kylo Ren moves closer,
        his hand rising toward her. She recoils, but has nowhere to
        go. Kylo Ren nearly TOUCHES HER FACE...
        THEY'RE BOTH SURPRISED: they react to a feeling that passes
        between them -- AN ENERGY THEY RECOGNIZE IN EACH OTHER.
        And then it's gone. Adversaries again. Rey can't move,
        quietly strains in agony, trying to resist Ren's probing.

        KYLO REN (CONT'D)
        ... You're so lonely... so afraid to
        leave...
        (then, slight smile)
        At night, desperate to sleep... you
        imagine an ocean. I see it -- I see
        the island...
        Tears stream down her face as she resists. She tries to
        break free, but can't budge.

        KYLO REN (CONT'D)
        And Han Solo. You feel like he's
        the father you never had. He would've
        disappointed you.

                        

                        (CONTINUED)

                        CONTINUED:
        His hand still on her face, her eyes fierce through the agony:

                        REY
        -- Get out of my head --
        But this just makes Kylo lean closer.

                        KYLO REN
        I know you've seen the map. It's in
        there... and now you'll give it to
        me. Don't be afraid. I feel it
        too.
        Where her strength comes from, she doesn't know, but:

                        REY
        I'm not giving you anything.

                        KYLO REN
        We'll see.
        He peers into her eyes intensely. She meets his gaze --

        DESPITE THE PAIN SHE IS STRONG.
        On Ren's face as HIS CONFIDENCE BEGINS TO MELT AWAY. He has
        slammed up against a barrier in her mind. He looks less
        certain by the moment as Rey seems to GROW IN STRENGTH. The
        FEROCITY of confrontation builds until it hits critical mass

        AND REY DOES THE UNTHINKABLE! SHE ENTERS HIS HEAD, AMAZED

        AT WHAT SHE IS SEEING!

                        REY
        ... You... you're afraid... that you
        will never be as strong as... Darth
        Vader!
        KYLO REN SUDDENLY WITHDRAWS HIS HAND, as if her face were
        FIRE HOT. TAKES A STEP BACK, CONFUSED, RATTLED. Rey's body
        is released, she breathes deeply, her powerful eyes still on
        Kylo Ren, who starts to leave.
        And we PRELAP:

        SNOKE (V.O.)
        This scavenger, resisted you?

        INT. STARKILLER PLANET - ASSEMBLY ROOM - NIGHT

        Kylo Ren, mask off, stands before Snoke.

                        KYLO REN
        She's strong with the Force, untrained
        but, stronger than she knows.
        And while Ren's mind no doubt goes to Luke:

                        SNOKE
        And the droid?

                        

                        

                        (CONTINUED)

                        CONTINUED:
        Kylo Ren hesitates to reveal the truth. Then:

        GENERAL HUX (O.S.)
        Ren believed it was no longer valuable
        to us.
        Ren turns back -- Hux enters the large space, moves to the
        platform beside Ren.

        GENERAL HUX (CONT'D)
        That the girl was all we needed. As
        a result, the droid has most likely
        been returned to the hands of the
        enemy. They may have the map already.
        Snoke is visibly furious.

                        SNOKE
        Then the Resistance must be destroyed
        before they get to Skywalker.

                        GENERAL HUX
        We have their location. We tracked
        their reconnaissance ship to the
        Ileenium system.

                        SNOKE
        Good. Then we will crush them once
        and for all. Prepare the weapon.
        Kylo Ren is stunned by the moment -- that isn't what he meant
        at all --

                        KYLO REN
        Supreme Leader. I can get the map
        from the girl. I just need your
        guidance.

                        SNOKE
        If what you say about this girl is
        true, bring her to me.

        INT. STARKILLER BASE - HOLDING CELL - DAY

        SLOW PUSH IN ON REY, shackled, mind still racing over what's
        happened between her and Kylo Ren. She is flooded with
        emotions, feeling her potential, her strength, that in this
        moment of being restrained, perhaps anything is possible.
        She turns to the Stormtrooper Guard. Studies him for an
        intense beat. Then says:

                        REY
        You will remove these restraints.
        And leave this cell, with the door
        open.
        The Stormtrooper Guard looks at her. A beat.

                        

                        

                        (CONTINUED)

                        CONTINUED:

                        TROOPER GUARD #2
        What did you say?
        Rey's eyes stay trained on him. She shifts in her seat, her
        confidence wavering, but she repeats, with authority:

                        REY
        You will remove these restraints.
        And leave this cell, with the door
        open.
        The Stormtrooper Guard, rifle aimed, MOVES FOR HER.
        Rey's heart pounds -- is she about to be killed, freed, or
        laughed at? The tension unbearable when the Guard says:

                        TROOPER GUARD #2
        I'll tighten those restraints,
        scavenger scum!

        INT. STARKILLER BASE - CORRIDOR 1 - DAY

        LOW ANGLE: Kylo Ren, masked, rounds a corner, PASSES US.

        INT. STARKILLER BASE - HOLDING CELL - DAY

        Rey stares intently at the trooper. Calms herself. And
        tries again.

                        REY
        You will remove these restraints.
        And leave this cell, with the door
        open.

                        TROOPER GUARD #2
        I will remove these restraints. And
        leave this cell, with the door open.
        He reaches down and UNLATCHES THE RESTRAINTS. HE THEN TURNS
        AND STARTS TO HEAD OUT, her back to him as he exits. SHE IS
        IN SHOCK. Then tries, quickly:

                        REY
        And you will drop your weapon.

                        TROOPER GUARD #2
        And I'll drop my weapon.
        The Trooper Guard DROPS HIS WEAPON without turning back --
        Rey HEARS the gun fall. She's incredulous. The guard has

        LEFT THE CELL, ITS DOOR OPEN.
        REY, in ABSOLUTE DISBELIEF, MOVES QUICKLY OUT OF FRAME!

        INT. STARKILLER BASE - HOLDING CELL - DAY

        Kylo Ren enters the cell -- we PUSH IN ON HIM as he takes in
        the empty cell -- AND IMMEDIATELY UNDERSTANDS WHAT HAS

        HAPPENED.

                        

                        (CONTINUED)

                        CONTINUED:

                        KYLO REN

        NO!
        Enraged, he RIPS OUT HIS SABER and --

        EXT. STARKILLER BASE - CORRIDOR 1 - DAY

        WIDE ANGLE, empty corridor, toward the cell: we only HEAR
        the horrible SOUNDS. DESTRUCTION. YELLING. A few pieces
        of red hot DEBRIS BOUNCES into the corridor.
        Two STORMTROOPERS, crossing at the far end of the hall, STOP
        TO WATCH this display of pure FURY. They retreat, and fast.

        INT. STARKILLER BASE - CONTROL ROOM - DAY

        Workers at their controls. Vast snowy landscape seen outside.
        Their GAUGES RISE -- THE WEAPON CHARGING SLOWLY --

                        GENERAL HUX
        Begin charging the weapon!

                        STARKILLER TECHNICIAN
        Yes, sir. Weapon charging.

        EXT. STARKILLER BASE PLANET - DAY

        A vast view of the planet -- a MASSIVE SOLARVAC ARRAY
        surrounds a port TEN MILES IN DIAMETER.
        MILLIONS OF PANELS turn on the ARRAY -- a wave of BRILLIANT
        REFLECTIONS. Suddenly, like a planetary-scale TESLA COIL
        LINE OF ENERGY, THE POWER OF THE SUN begins to TRAVEL DOWN
        to the Starkiller Base planet.

        INT. RESISTANCE BASE - DAY

        Finn, now a member of the inner circle of the Resistance, is
        huddled with the group around the MAP TABLE, which displays
        a WIREFRAME HOLOGRAM of a ROLLING VIEW OF THE SURFACE OF
        STARKILLER BASE. With Finn are Han, Leia, Poe, C-3PO,
        Statura, Ackbar, Brance, SNAP, MAJOR EMATT (60), NIEN NUNB,
        and others. An urgent, messy strategy session --

                        POE
        The scan data from Snap's
        reconnaissance flight confirms Finn's
        report.

                        SNAP
        They've somehow created a hyper
        lightspeed weapon built within the
        planet itself.

                        BRANCE
        A laser cannon?

                        

                        

                        

                        

                        (CONTINUED)

                        CONTINUED:

                        SNAP
        We're not sure how to describe a
        weapon of this scale.

                        MAJOR EMATT

                        (HORRIBLE MEMORIES)
        It's another Death Star.

                        POE
        I wish that were the case, Major.
        Poe hits a control. A WIREFRAME OF THE DEATH STAR APPEARS.

                        POE (CONT'D)
        This was the Death Star.
        Poe hits another control -- the Death Star SHRINKS -- AND
        SHRINKS AND SHRINKS, as the SURFACE AREA OF THE STARKILLER

        BASE IS DRAWN INTO A LARGER IMAGE, REVEALING THE ENTIRE BASE
        PLANET. The Death Star is a minuscule SATELLITE in
        comparison.

                        POE (CONT'D)
        This is Starkiller Base.
        This is news to many here, and they're stunned.

                        HAN
        So it's big.

                        ADMIRAL ACKBAR
        How is it possible to power a weapon
        of this size?

                        FINN
        It uses the power of the sun. As
        the weapon is charged, the sun is
        drained until it disappears.
        An OFFICER runs up, hands Leia a DATACARD.

                        LEIA
        (eyes on datacard)
        The First Order: they're charging
        the weapon again, now.
        (then, heart sinking)
        Our system is the next target.

                        C-3PO
        Oh my. Without the Republic fleet,
        we're doomed.
        They all react to this horrible news.

                        HAN
        Okay, how do we blow it up?
        (all eyes on him)
        There's always a way to do that.

                        

                        

                        (CONTINUED)

                        CONTINUED:
        But no one has anything. Leia watches the silence,
        frustrated. Finally, rallying them:

                        LEIA
        Han's right.
        Han is surprised.

                        ADMIRAL STATURA
        (at first hesitant)
        In order for that amount of power to
        be contained, that base would need
        some kind of thermal oscillator...

                        FINN
        There is one.
        All eyes on Finn as he moves around the hologram to a location
        on the Starkiller Base -- it is ZOOMED IN: A GIANT BLACK

        HEXAGONAL STRUCTURE.

                        FINN (CONT'D)
        Precinct 47. Here.

                        ADMIRAL STATURA

                        (HYPOTHESIZING)
        If we can destroy that oscillator,
        it might de-stabilize the core and
        cripple the weapon.

                        MAJOR EMATT
        ... Maybe the planet.
        Poe then tries to bolster spirits, looking at the BIG
        HEXAGONAL STRUCTURE: the Oscillator.

                        POE
        We'll go in there and we'll hit that
        oscillator with everything we got.

                        ADMIRAL ACKBAR
        They have defensive shields that our
        ships cannot penetrate.

                        HAN
        We disable the shields.

                        (TO FINN)
        Kid, you worked there, what do you
        got?

                        FINN
        (beat, then:)
        I can do it.

                        HAN
        I like this guy.

                        

                        

                        

                        

                        (CONTINUED)

                        CONTINUED:

                        FINN
        I can disable the shields. But I
        have to be there, on the planet--

                        HAN
        We'll get you there.

                        LEIA
        Han, how?

                        HAN
        If I told you, you wouldn't like it.

                        POE
        So we disable the shields, take out
        the oscillator and we blow up their
        big gun. All right. Let's go!
        And everyone splits.

        EXT. HANGARS, RESISTANCE BASE - DAY


        SERIES OF SHOTS: THE RESISTANCE FLEET PREPARES FOR ITS
        MISSION. Pilots inspect crafts, including Snap, Nien Nunb,
        and Poe at his black-marked X-wing. Mechanics make
        adjustments as Crews fuel the jets. Ground controllers move
        ships into takeoff formation. Pilots prep their ships,
        including BB-8, who is PULLED INTO Poe's black X-wing.
        Finn approaches Poe wearing the jacket.
        Poe slaps Finn's shoulder as he heads off. Finn watches
        Poe, despite it all, a little laugh. Over this:

        EXT. RESISTANCE BASE - DAY

        Chewie and Finn follow Han's orders as they prepare the Falcon
        for one more daring run, maybe its last:

                        HAN
        Chewie, check that donal capitator.
        Come on. Let's go. -- Finn, be
        careful with those - they're
        explosives.

                        FINN
        Now you tell me?

                        LEIA
        No matter how much we fought, I've
        always hated watching you leave.
        Han looks over, there's Leia.

                        HAN
        That's what I did it. So you'd miss
        me.
        She laughs, moves up close to him.

                        

                        (CONTINUED)

                        CONTINUED:

                        LEIA
        I did miss you.
        He looks at her, says sweetly, out of the blue:

                        HAN
        It wasn't all bad, was it? Huh?
        Some of it was...good.

                        LEIA
        ... Pretty good.

                        HAN
        Some things never change.

                        LEIA

                        (SMILES)
        True. You still drive me crazy.
        Han places his hands on her shoulders. It could be thirty
        years ago.
        They both know there's a good chance he won't make it back.
        They pull each other tight, holding for dear life. Quietly,

                        LONGINGLY:

                        LEIA (CONT'D)
        If you see our son again, bring him
        home.

        INT. STARKILLER BASE - DAY


                        STORMTROOPER
        Sir, sensors triggered in hangar
        718. We're searching the area.

                        KYLO REN
        She's just beginning to test her
        powers. The longer it takes to find
        her, the more dangerous she becomes.
        Kylo exits.

        INT. STARKILLER BASE - ATRIUM AREA - DAY

        TIGHT ON REY'S FACE as she peers nervously around a corner.
        Rey runs down a long, glossy hall, taking cover in an alcove,
        the Trooper Guard's rifle HELD TIGHT.

        EXT. LIGHTSPEED SPACE - DAY

        The Falcon SCREAMS PAST --

        INT. MILLENNIUM FALCON - COCKPIT - DAY

        Flying at LIGHTSPEED, Finn, with Han and Chewie.

                        

                        

                        

                        (CONTINUED)

                        CONTINUED:

                        FINN
        How are we getting in?

                        HAN
        Their shields have a fractional
        refresh rate. Keeps anything
        traveling slower than lightspeed
        from getting through.
        Finn is suddenly filled with dread.

                        FINN
        We're gonna make our landing approach
        at lightspeed?!
        Chewie, thinking it's crazy too, says: HELL YES WE ARE!

                        HAN
        Alright, Chewie, get ready.
        Chewie GROANS: he's ready. Han studies the PANEL INDICATORS.

                        HAN (CONT'D)
        And Now!
        Chewie and Han hit switches --

                        

        EXT. LIGHTSPEED SPACE/STARKILLER BASE - DAY

        The Falcon's ENVIRONMENT SHIFTS INSTANTLY FROM LIGHTSPEED TO
        PLANET ATMOSPHERE -- it's suddenly FLYING 100 FEET ABOVE THE

        SNOWY, ROCKY GROUND, HEADED FOR A THICK FOREST!

        INT. MILLENNIUM FALCON - COCKPIT - DAY


                        CHEWIE GROANS:

                        HAN

        I AM PULLING UP!!!

        EXT. STARKILLER BASE - DAY

        But the Falcon has no time -- it PLOWS through the trees!
        It then RISES --

        INT. MILLENNIUM FALCON - COCKPIT - DAY

        ALARMS BLARE as the ship SLAMS THROUGH BRANCHES, SHOOTS TOWARD
        SKY! Han does his best to steer -- Chewie GROANS -- in the
        madness Han YELLS:

                        HAN
        I get any higher, they'll see us!
        And the ship DIVES again, back into the trees!

        EXT. STARKILLER BASE - CLEARING - DAY

        A quiet CLEARING on the forest TREELINE. Suddenly the
        MILLENNIUM FALCON HURTLES OUT OF THE FOREST! From an eruption
        of BRANCHES and PINE, the ship DIVES -- SLAMS INTO THE SNOW!
        It DIGS THROUGH A THOUSAND YARDS OF WHITE until it finally
        comes to a canted stop, half buried in the snow!

        INT. STARKILLER BASE - DAY


                        OFFICER
        Sir, she was not found in hangar 718
        but all troops are on alert.

                        KYLO REN
        Put every hangar on lock-down. She's
        going to try to steal a ship to--
        Suddenly, Kylo senses something. Something familiar.

        KYLO REN (CONT'D)
        Han Solo...

        EXT. STARKILLER BASE - DAY

        MASSIVE WIDE SHOT of an EPIC SNOWSCAPE. Han, Finn and Chewie
        cross the terrain. WALKERS appears on the horizon. Han,
        Finn and Chewie take cover behind a base structure. Chewie
        carries a BLACK DUFFEL of EXPLOSIVES.

                        FINN
        The flooding tunnels are over that
        ridge. We'll get in that way.

                        HAN
        What was your job when you were based
        here?

                        FINN
        Sanitation.

                        HAN
        Sanitation? Then how do you know
        how to disable the shields?

                        FINN
        I don't. I'm just here to get Rey.

                        HAN
        People are counting on us! The galaxy
        is counting on us--!

                        FINN
        Solo, we'll figure it out! We'll
        use the Force!

                        HAN
        That's not how the Force works--!

                        

                        (CONTINUED)

                        CONTINUED:
        Chewie MOANTALKS.

                        HAN (CONT'D)
        Oh really, you're cold?

                        FINN
        Come on!
        They follow Finn on the snowy hike. On the horizon, THE

        LASER SIPHON SHOOTING INTO THE SKY, SLOWLY SUCKING THE SUN

        DRY.

        INT. STARKILLER BASE - CONTROL ROOM - DAY

        Technicians at work, the SUN SUCKING seen in the window behind
        him.

                        GENERAL HUX
        Report.

        FIRST ORDER OFFICER
        Weapon charged in fifteen minutes,
        sir.

        INT. STARKILLER BASE - CORRIDOR 4 - DAY

        A STORMTROOPER waits to board a Transport Compartment. The
        door WHOOSHES open -- HAN, FINN and CHEWIE are there!

                        STORMTROOPER FN-9330
        Hey!
        He fumbles for his blaster but Chewie shoots first. WIDE
        ANGLE of the corridor as the Trooper flies back, dead.
        Chewie drags him out of sight. Han and Finn peer around a
        corner, wary.

                        HAN
        The longer we're here, less luck
        we're going to have. The shields?

                        FINN
        I have an idea about that.
        Han and Chewie follow Finn.

        INT. STARKILLER BASE - CORRIDOR - DAY

        Captain Phasma heads down a corridor, distant Stormtroopers.
        Suddenly Phasma is T-BONED HARD AND FAST -- SHOVED OUT OF

        FRAME BY CHEWIE!
        And now we're in a NARROW CROSS-CORRIDOR, CHEWIE WITH HIS

        ARMS AROUND PHASMA, FORCED TO FACE FINN, WHO HOLDS HIS BLASTER
        ON HIS FORMER CAPTAIN. Han stands behind Finn.

                        FINN
        Remember me?

                        

                        (CONTINUED)

                        CONTINUED:

                        CAPTAIN PHASMA

        FN-2187.

                        FINN
        Not anymore. The name's Finn, and
        I'm in charge. I'm in charge now,
        Phasma. I'm in charge.

                        HAN
        Bring it down. Bring it down.

                        FINN
        Follow me.
        Finn SMILES as we CUT TO:

        INT. STARKILLER BASE - ATRIUM AREA - DAY

        TIGHT ON REY'S FACE as she peers nervously around a corner.
        Rey runs down a long, glossy hall, taking cover in an alcove,
        the Trooper Guard's rifle HELD TIGHT.
        From this alcove, she can see down another LONG, PERPENDICULAR
        WALKWAY -- on one side, a STONE AND STEEL WALL. On the other
        side, a VAST ATRIUM, with a railing-free DROP OFF, the white
        pill-light design descending HUNDREDS OF FEET.
        At the end of this walkway is an OPEN HANGAR DOOR, revealing
        HUNDREDS OF TIE FIGHTERS parked outside.
        TIGHT on Rey's face as her plan is clear. But the problem:
        between her and the ship she wants to steal, is a GROUP OF
        STORMTROOPERS. Guards, in conversation.
        As she tries to think about what to do next, we see, FAR
        BEHIND HER in the perpendicular hall, ANOTHER GROUP OF STORM-
        and SNOWTROOPERS headed her way!
        Rey's mind races -- another peek out and she RUNS FAST, across
        the walkway, and CLIMBS DOWN -- her fingertips disappearing
        over the edge just as the Troopers approach and continue.
        WIDE SHOT as Rey holds on carefully as the guards walk off,
        not seeing her over the edge, a death drop below her.
        But then she SEES SOMETHING and has a brainstorm. She
        strenuously cross-climbs to an invisible SERVICE HATCH, which
        She opens, and climbs INSIDE THE WALL, closing the hatch
        behind her.

        INT. STARKILLER BASE - INSIDE THE WALLS - DAY

        A REMARKABLE IMAGE, inside the inner workings of the base.
        Tiny by comparison, Rey climbs amid the incredible
        infrastructure, a drop to infinity beneath her. She is
        between the LIGHT SOURCE and the WHITE PILL SHAPES, as she
        makes her way ACROSS.

        INT. STARKILLER BASE - ATRIUM AREA - DAY

        WIDE SHOT of the Stormtrooper GUARDS, above the drop off
        into the atrium. What they cannot see is a SHADOWED
        SILHOUETTE OF REY against the ENDLESS WHITE PILL LIGHTS as
        she climbs across the space, beneath them, toward her exit!

        INT. STARKILLER BASE - CONTROL ACCESS POINT - DAY

        CLOSE AS PHASMA SITS INTO FRAME in front of a WORKSTATION --
        Finn, Han and Chewie, blasters aimed. Phasma reluctantly
        works controls on the workstation.

                        FINN
        You want me to blast that bucket off
        your head? Lower the shields.

                        CAPTAIN PHASMA
        You're making a big mistake.

                        FINN
        Do it.
        Chewie MOAN/TALKS. Phasma hits a few more buttons -- the
        controls BEEP-CLICK. "SHIELDS DISABLE INITIATE". Eyes on

                        THE WORKSTATION:

                        FINN (CONT'D)
        Solo, if this works, we're not going
        to have a lot of time to find Rey.

                        HAN
        Don't worry kid, we won't leave here
        without her.
        The controls BEEP-CLICK. "SHIELDS DISABLED".

                        CAPTAIN PHASMA
        (to Finn, cruel)
        You can't be so stupid as to think
        this will be easy. My troops will
        storm this block and kill you all.

                        FINN
        I disagree. What do we do with her?

                        HAN
        Is there a garbage chute? Trash
        compactor?

                        FINN
        Yeah, there is...

        INT. RESISTANCE BASE - DAY

        An ALERT: OFFICERS at their consoles, OVERLAPPING, urgent.

                        

                        

                        

                        

                        (CONTINUED)

                        CONTINUED:

                        OFFICER
        General, their shields
        are down!

                        C-3PO
        Thank the Maker!

                        LEIA
        Han did it! Send them
        in!

                        ADMIRAL STATURA
        Give Poe full authorization
        to attack.

                        REAR ADMIRAL

                        GULCH
        Black Leader, go to
        sub-lights. On your
        call.

        INT. X-WING - DAY

        At LIGHTSPEED, Poe pilots:

                        POE
        Roger, base -- red squad, blue squad,
        take my lead.

        INT. X-WING - DAY

        Nien Nunb pilots, acknowledges order in alien language.

        INT. X-WING - DAY

        Another pilot, ZOLO ZIFF.

                        YOLO ZIFF
        Dropping out of lightspeed.

        EXT. SPACE/STARKILLER BASE - DAY

        With CONCUSSIVE BLASTS, the X-WINGS APPEAR and ROAR PAST
        CAMERA toward the Starkiller Base planet!

        EXT. STARKILLER BASE - CLEARING - DAY

        The CRASHED FALCON, two parked TIE FIGHTERS and a TROOP
        TRANSPORT VEHICLE beside it.

        EXT. STARKILLER BASE - CLEARING - DAY

        At a distance, the X-WINGS DROP FROM THE SKY, TOWARD THE

        HEXAGONAL OSCILLATOR STRUCTURE IN THE DISTANCE!

        EXT. STARKILLER BASE - ABOVE OSCILLATOR - DAY

        The squad of X-wings DIVE BOMBS the Oscillator, the Black
        Falcon leads. INTERCUT BETWEEN THIS AND VARIOUS X-WINGS.

        INT. X-WING - DAY


                        POE PILOTS:

                        POE
        Almost in range! Hit the target
        dead center, as many runs as we can
        get!

        INT. X-WING - DAY

        Snap pilots.

                        SNAP
        Approaching target.

        INT. X-WING - DAY

        Nien Nunb acknowledges.

        INT. STARKILLER BASE - CONTROL ROOM - DAY

        LARGE EXPLOSIONS atop the DISTANT OSCILLATOR, seen through
        the large windows! ALARMS BLARE in here -- we PULL BACK as
        Hux moves quickly to see the damage, he turns sharply to a
        First Order Officer:

                        GENERAL HUX
        Dispatch all squadrons...

                        COLONEL DATOO
        Yes, General.

        INT. X-WING - DAY


                        POE
        Let's light it up!

        DIVE BOMBING THE OSCILLATOR, HITTING IT DEAD CENTER IN QUICK

        SUCCESSION!

        INT. X-WING - DAY


        LT. BASTIAN
        Direct hit!

                        ELLO ASTY
        But no damage!
        Jess reacts.

                        POE
        Yeah, we gotta keep hitting it!
        Another bombing run! Remember, when
        that sun is gone, that weapon will
        be ready to fire! But as long as
        there's light, we got a chance.

        INT. X-WING - DAY

        A BEEPING from BB-8, riding in the back of his X-wing, and
        Poe looks out -- can't believe what he's seeing: DOZENS OF

        TIE FIGHTERS!

                        POE
        Guys, we got a lot of company!

        INT. STARKILLER BASE - JUNCTION AREA - DAY

        Finn, Han and Chewie take cover, Chewie pulling some
        EXPLOSIVES out of the duffel. Blast doors nearby.

                        FINN
        We'll use the charges to blow that
        blast door. I'll go in and draw
        fire, but I'm gonna need cover.

                        HAN
        You sure you're up for this?

                        FINN
        Hell no -- I'll go in find and try
        to find Rey --
        (improvising, fast)
        -- The troopers'll be on our tail.
        We have to be ready for that. There's
        an access tunnel that'll leads --
        (Han starts pointing
        with his chin to

                        SOMETHING BEHIND

                        FINN)
        Why are you doing that? Why are you
        doing -- this? I'm trying to come
        up with a plan.
        Finn turns -- AND SEES REY, CLIMBING OUT FROM INSIDE THE
        WALL, carefully climbing back up to the main level! He can't
        believe it! Chewie MURMURS his relief. Han is maybe more
        grateful than anyone.

        INT. RESISTANCE BASE - DAY

        A Resistance Technician turns to Leia:

                        ADMIRAL ACKBAR
        The Oscillator's still standing.

                        OFFICER
        X-wings coming back for another round
        of attacks!

        INT. STARKILLER BASE - CORRIDOR 6 - DAY

        Rey climbs up to the corridor, vigilant. She hears a SOUND,
        SWOOPS her rifle at -- Finn, Han and Chewie! She cannot
        believe it! All Finn wants to do is hug her -- and she him.

                        

                        

                        (CONTINUED)

                        CONTINUED:

                        HAN
        Are you all right?

                        REY
        Yeah.

                        HAN
        Good.

                        FINN
        What happened -- did he hurt you?

                        REY
        Finn. What are you doing here?!

                        FINN
        We came back for you.
        She is speechless -- this is all she's ever wanted anyone to
        do. Chewie TALKS -- and Rey's eyes nearly tear up.

                        FINN (CONT'D)
        What'd he say?

                        REY
        (shrugs, smiles, though
        nearly in tears)
        ... That it was your idea.
        Finn awkwardly smiles. It's his nature. They embrace.

                        REY (CONT'D)
        Thank you.

                        FINN
        How did you get away?

                        REY
        I can't explain it. And you wouldn't
        believe it.

                        HAN
        Escape now. Hug later.

        EXT. STARKILLER BASE - DAY

        The X-Wings DOGFIGHT with the TIE Fighters on the surface of
        the snowy planet. INTERCUT BETWEEN the ships SCREAMING past
        each other, and the COCKPITS of the Resistance and First
        Order fighters. Poe's fighter NEARLY COLLIDES with a close-
        passing TIE Fighter!

                        SNAP
        I got one behind me. See it?

                        JESS
        Yeah, I'm on it!

                        

                        

                        

                        (CONTINUED)

                        CONTINUED:
        A heavy cannon emplacement launches a missile that shreds an
        X-wing fighter.

                        JESS
        Furillo's been hit!

                        SNAP
        Watch out for ground fire!

        EXT. STARKILLER BASE - DAY

        The X-wings ROAR across the sky, BLASTING and DODGING the
        TIE Fighters and missiles.
        PULL BACK TO REVEAL Han, Finn, Rey and Chewie, who run out
        here, into the snow, stopping, eyes on the sky, watching the
        lop-sided battle.

        THE FOUR HEROES TURN TO EACH OTHER, RESOLVE IN THEIR EYES.
        A long moment of communication.

                        HAN
        They're in trouble. We can't leave.
        (to Finn, re: Chewie)
        My friend here has a bag full of
        explosives. Let's use 'em.

        INT. RESISTANCE BASE - DAY

        A Resistance Technician turns to Leia:

        KAYDEL KO CONNIX
        General, are you seeing this?

                        VOBER DAND
        Two more X-wings down. That's half
        our fleet destroyed.

                        C-3PO
        And their weapon will be fully charged
        in 10 minutes! It would take a
        miracle to save us now.

        INT. STARKILLER BASE - OSCILLATOR STRUCTURE - NEAR DARKNESS

        Han and Chewie arrive here to find THREE SECURITY
        STORMTROOPERS approaching a Maintenance Hatch. Instantly,
        Chewie takes out the middle one with his Bowcaster. Han and
        the other two Stormtroopers OPEN FIRE, but Han's aim is true.

        ALARMS START BLARING!

        INT. JUNCTION STATION - NEAR DARKNESS

        Running inside from a parked snowspeeder, Rey opens a service
        hatch. Finn behind her, as she reaches into the mechanics
        of the place, very much like the very first shot we saw of
        Rey.
        And she YANKS a piece of TECH from the machinery and:

        INT. STARKILLER BASE - OSCILLATOR STRUCTURE - NEAR DARKNESS

        The HATCH OPENS! Han and Chewie, having been on the lookout,
        step inside, weapons poised. Chewie MOANS.

                        HAN
        That girl knows her stuff.

        INT. STARKILLER BASE - OSCILLATOR STRUCTURE - NEAR DARKNESS

        Han and Chewie divide the explosives. Talk in hushed tones.

                        HAN
        We'll set the charges at every other
        column.
        He GROAN/TALKS to Han, who looks around, reconsiders.

                        HAN (CONT'D)
        You're right. That's a better idea.
        (checks his detonator)
        You take the top.

                        (CHEWIE DOES)
        I'll go down below. Detonator.
        We'll meet back here.
        They head off in opposite directions.

        INT. OSCILLATOR STRUCTURE - NEAR DARKNESS

        Han finishes placing an explosive. Checks he's all-clear
        and hurries down to the next level. Chewie climbs up a level.

        INT. OSCILLATOR STRUCTURE - MAIN ENTRANCE - NEAR DARKNESS

        A SQUAD of Stormtroopers SNAP to alert as Kylo Ren approaches.
        CONTROLS ARE HIT and the huge DOOR OPENS. Without hesitation,
        Kylo walks INTO THE OSCILLATOR.

        INT. OSCILLATOR STRUCTURE - NEAR DARKNESS

        A COLOSSAL CYLINDRICAL STRUCTURE. DARK CORRIDORS and
        CATWALKS. Kylo Ren comes to a stop. Scans the structure.
        SENSING SOMETHING, he motions the Stormtrooper Squad upwards.

                        KYLO REN
        Find them.
        They rush past him. Kylo Ren turns slowly, and HEADS DOWN.

        INT. STARKILLER BASE - OSCILLATOR STRUCTURE - NEAR DARKNESS

        The Stormtroopers move up the ramp, weapons ready, checking
        carefully where blind corners intersect from the perimeter.
        They come round to the next higher level and PASS CLOSE TO
        CAMERA. When they've passed, TILT to find CHEWIE, in the
        shadows of the grillwork.

                        

                        (CONTINUED)

                        CONTINUED:

                        
        Once they're gone, he plants another charge.

        EXT. STARKILLER BASE - OSCILLATOR STRUCTURE - NEAR DARKNESS

        The Snowspeeder comes to a stop outside the structure. Finn
        and Rey stop for a moment, look to the sky: THE SUN IS NEARLY

        GONE.

        INT. OSCILLATOR STRUCTURE - LOWER LEVEL - NIGHT

        Han finishes setting a charge and is about to move on when
        he HEARS SOMETHING and conceals himself behind a wide,
        vertical support. He peaks around the edge and his whole
        demeanor changes --
        HAN'S POV: Kylo Ren appears and stops at the railing, looking
        down into the filter.
        Han looks at his son with a tortured storm of feelings.
        WE'RE WITH KYLO REN as he resumes his hunt. He heads directly
        toward WHERE HAN IS HIDING! Kylo Ren has an INCREASING SENSE
        OF HAN'S PRESENCE as he moves closer. He comes to where Han
        was hiding -- but HAN IS NOWHERE TO BE SEEN.
        From his hiding place in a narrow, POWER CHAMBER in the wall,

        HAN WATCHES HIS SON PASS ONLY A FEW FEET IN FRONT OF HIM.
        Han SHIFTS HIS POSITION in the tight compartment, so he can
        watch Ren's progress. Kylo Ren turns onto a FLAT BRIDGE
        THAT BISECTS the open space.
        Unaware of his father, Kylo Ren walks purposefully across to
        the opposite side. Han watches his son walk off -- the CLANK-
        CLANK of Kylo Ren's boots receding.
        This is Han's opportunity to escape but Leia's words echo
        through his mind. He makes a decision and moves out, to the
        edge of the catwalk. He calls out, strongly:

                        HAN
        Ben!
        The name ECHOES as Kylo Ren STOPS, far across the vast
        catwalk. He turns.

                        KYLO REN
        Han Solo. I've been waiting for
        this day for a long time.
        Finn and Rey make their way into the space, opening a HATCH
        that allows A BEAM OF PRECIOUS SUNLIGHT to stream down like
        a spotlight on Han and his son. Finn and Rey get to a railing
        and look down. They can SEE and HEAR Han and Kylo Ren on
        the catwalk below.

                        

                        

                        

                        

                        (CONTINUED)

                        CONTINUED:

                        HAN
        Take off that mask. You don't need
        it.

                        KYLO REN
        What do you think you'll see if I
        do?
        Han moves toward Kylo Ren.

                        HAN
        The face of my son.
        Kylo TAKES OFF HIS MASK. Han is JOLTED -- seeing the face
        of his son for the first time as a man.

                        KYLO REN
        Your son is gone. He was weak and
        foolish, like his father. So I
        destroyed him.

                        HAN
        That's what Snoke wants you to believe
        but it's not true. My son is alive.
        SEVERAL LEVELS BELOW them, CHEWIE comes to the rail to watch.

        INT. OSCILLATOR STRUCTURE - LOWER LEVEL - NEAR DARKNESS

        Kylo flares.

                        KYLO REN
        No. The Supreme Leader is wise.
        UP ABOVE, Finn, Chewie and Rey watch, rapt. Stormtroopers
        dot the perimeter of the structure, watching the scene.
        ON THE BRIDGE, Han moves closer, stern:

                        HAN
        Snoke is using you for your power.
        When he gets what he wants, he'll
        crush you -- you know it's true.
        Kylo hesitates. Somehow, he does know it.

                        KYLO REN
        It's too late.

                        HAN
        No it's not. Leave here with me.
        Come home. We miss you.
        For the first time, Kylo Ren seems truly conflicted. Tears
        flood his stoic eyes...

                        KYLO REN
        I'm being torn apart. I want to be
        free of this pain.

        INT. OSCILLATOR STRUCTURE - DARKNESS FALLS

        Han takes one step toward his son, but stops himself.

                        KYLO REN
        I know what I have to do, but I don't
        know if I have the strength to do
        it. Will you help me?
        Han hears his son's voice again, pained and vulnerable.

                        HAN
        Yes. Anything.
        Kylo Ren unholsters his lightsaber and SLOWLY EXTENDS IT to
        Han, within a foot of Han's chest. Han almost can't believe
        it. The moment seems to last forever. And just then, the
        LAST BEAM OF SUNLIGHT streaming through the open hatch

        VANISHES.
        Han actually smiles -- and reaches out for the dark weapon --
        but with the light now gone, KYLO REN'S EYES FILL WITH

        DARKNESS, HE IGNITES THE LIGHTSABER -- THE FIERY BLADE SHOOTS

        OUT, RIGHT THROUGH HAN'S CHEST AND BACK!

                        KYLO REN
        Thank you.
        ABOVE, Finn and Rey GASP -- SCREAM --

                        FINN

                        (PANTING)
        Solo.

                        REY

                        (ALSO PANTING)
        No, no.
        Han's last moment is looking into his son's face. HAN'S
        KNEES BUCKLE. The blade tilts down with him... until KYLO
        REN EXTINGUISHES IT AND HAN HOLDS onto the catwalk -- his
        life slipping away.
        Finally Han FALLS BACK, OFF THE CATWALK, INTO THE DEPTHS OF

        THE STRUCTURE!

        INT. RESISTANCE BASE - DAY

        Leia, feeling it instantly -- knowing -- drops into a seat,

        DEVASTATED.

        INT. OSCILLATOR STRUCTURE - NIGHT

        Kylo Ren is somehow WEAKENED by this wicked act. Himself
        horrified. His SHOCK is broken only when --
        CHEWIE CRIES OUT IN AGONY! Chewie furiously FIRES AT KYLO
        REN, HITTING HIM IN THE SIDE! Kylo Ren falls back, stunned.

                        

                        

                        (CONTINUED)

                        CONTINUED:
        Our MUSIC TAKES OVER, EPIC AND HEARTBREAKING as Stormtroopers
        FIRE AT CHEWIE, who is forced to retreat down a corridor,
        where he holds the EXPLOSIVE REMOTE -- he PUSHES THE BUTTON!
        Hearing ONLY OUR SCORE, FIRST ONE, then TWO, then FOUR, then
        SIX EXPLOSIONS rock the structure -- CATWALKS FALL as the
        walls CAVE IN!
        Kylo Ren SEES REY AND FINN, WATCHING THE EXPLOSIONS IN SHOCK --
        then they SEE KYLO REN, WHO RECOGNIZES THEM BOTH, WITH
        ASTONISHMENT. He rises to his full height and heads for
        them with long strides.
        Stormtroopers begin to BLAST AWAY AT REY AND FINN! CRAZED,

        REY FIRES BACK AS BLASTS HIT AROUND HER. FINN WRAPS AN ARM

        AROUND HER AND DRAGS/CARRIES HER OUT OF SIGHT!

        INT. RESISTANCE BASE - DAY


                        ADMIRAL ACKBAR
        The Oscillator's been damaged but is
        still functional.
        COMMODORE META reacts.

        OFFICER TABALA ZO
        Admiral, their weapon will fire in
        two minutes.

        EXT. FOREST - NIGHT

        From a distance the oscillator is ablaze and fractured from
        the explosives. Then Rey and Finn appear, coming over a
        rising, running into a bare-tree snowy forest.

                        FINN
        The Falcon's this way.
        Finn and Rey, overcome with emotion, race through the snowy
        forest -- until Finn SLOWS AND STOPS. Rey stops too, both
        out of breath. They look at each other. They both know:
        they can't run.

        EXT. STARKILLER BASE - FOREST - NIGHT

        Kylo Ren moves through the trees -- until he STOPS. Takes
        out the saber, ignites it.
        A still figure amidst the gusts of wind and snow.

        STANDING THIRTY FEET AWAY, FACING HIM, ARE FINN AND REY.
        Finn holds LUKE'S LIGHTSABER, Rey the Stormtrooper BLASTER.

                        KYLO REN
        We're not done yet.

                        REY
        You're a monster!

                        

                        

                        (CONTINUED)

                        CONTINUED:

                        KYLO REN
        It's just us now. Han Solo can't
        save you.
        After a beat, Rey moves forward with the blaster -- AIMS IT!
        Kylo Ren RAISES A HAND -- Rey struggles under his FORCE POWER --
        she can't fire -- he strains too, especially with the WOUND
        Chewie inflicted. Kylo Ren GESTURES POWERFULLY -- Rey's
        BLASTER FLIES OUT OF HER HAND -- another GESTURE and Rey
        FLIES BACK and SLAMS INTO A TREE thirty feet away!
        She drops -- LANDS HARD in the snow. Dazed, hurt.

                        FINN
        Rey! Rey! Rey... Rey... Oh no. Oh
        no no no...
        Finn turns to her, afraid and concerned. But the SOUND OF
        KYLO REN'S LIGHTSABER moving makes Finn TURN BACK TO KYLO
        REN, lit by the glowing YELLOW AND RED BLADE.

                        KYLO REN

        TRAITOR!
        In reply, Finn TURNS ON LUKE'S LIGHTSABER -- upon seeing the
        weapon, Kylo Ren REACTS IN SHOCK.

        KYLO REN (CONT'D)
        That lightsaber. It belongs to me!

                        FINN
        Come get it.
        Despite his fear, Finn raises his blade in welcome. Kylo
        Ren CHARGES at him - Finn terrified -- Kylo Ren LUNGES but
        Finn DEFLECTS Ren's SPARK-SPITTING blade!
        Kylo Ren TURNS, ATTACKS, CUTS -- amazingly Finn BLOCKS,
        COUNTER-ATTACKS -- clearly IMPRESSES KYLO REN, who only enjoys
        this challenge more!
        Rey RECOVERS, gets her bearings. Her eyes focus on the two
        men fighting, through the trees.
        Kylo Ren is obviously hampered by his wound, yet he attacks
        with a primal SAVAGERY -- Finn BLOCKS, turning DEFENSIVE
        moves into OFFENSIVE ones. And he ACTUALLY GETS A HIT IN!
        LUKE'S SABER GRAZING KYLO REN'S ARM! Kylo MOVES BACK --
        wounded, but more enraged than weakened. Kylo Ren CHARGES
        AGAIN -- their WEAPONS POUND, SPARKS FLY, their blades LOCK,
        the men are CLOSE, LIT BY the powerful, CRASHING sabers:
        And Kylo Ren PUSHES FINN BACK, attacks with pure ferocity --
        Finn is stunned -- unprepared for this fierceness.
        Rey sees this -- Kylo Ren unleashes a MERCILESS SERIES OF
        BLOWS, pushing Finn further and further back until he loses
        balance.

                        

                        (CONTINUED)

                        CONTINUED:
        That's when KYLO REN STRIKES: HE LANDS A BLOW TO FINN'S TORSO --

        LUKE'S LIGHTSABER FLIES FROM FINN'S HAND, THROWN TWENTY FEET!
        Kylo Ren TURNS OFF HIS LIGHTSABER and REACHES FOR LUKE'S

        LIGHTSABER -- BECKONING IT WITH THE FORCE.

        LUKE'S LIGHTSABER VIBRATES IN THE SNOW.
        Kylo Ren GESTURES, INCREASES HIS POWER -- LUKE'S LIGHTSABER

        FINALLY FLIES OUT OF THE SNOW, BULLETS TOWARD KYLO REN --

        -- AND SPEEDS PAST HIM!

        KYLO REN TURNS TO SEE LUKE'S LIGHTSABER LAND IN THE HAND OF

        REY, WHO STANDS, FACING HIM, HAVING REACHED FOR IT HERSELF,

        BUT UTTERLY STUNNED THAT IT LANDED IN HER HAND! SHE IS

        SHOCKED -- AND SO IS KYLO REN!
        Holding it with both hands, SHE IGNITES LUKE'S LIGHTSABER

        FOR THE FIRST TIME, HER EYES BLAZING.
        Kylo Ren IGNITES HIS SABER.
        It's REY who charges now -- Kylo Ren immediately on the
        defensive. They BATTLE POWERFULLY -- He is clearly rocked
        by her raw, innate skill.

        INT. X-WING - NIGHT


                        NIV LEK
        We just lost R-1!

                        JESS
        We're overwhelmed! What do we do?
        It isn't working!
        Another pilot looks down -- SEES THE EXPLOSION -- coming
        from the OSCILLATOR. Relatively small, it's an opening:

                        YOLO ZIFF
        Black Leader, there's a brand new
        hole in that oscillator. Looks like
        our friends got in!

                        POE
        Red Four! Red Six! Cover us!

        LT. BASTIAN
        I'm on it!

                        ELLO ASTY
        Roger!

                        POE
        Everybody else, hit the target hard!
        Give it everything you got!
        And the X-WINGS DIVE and BLAST the OSCILLATOR --

        EXT. STARKILLER BASE - OSCILLATOR - NIGHT

        Another two X-wings -- including Poe's -- soar through the
        trench leading to the oscillator structure!

                        POE
        I need some help here! I need some
        help!

        LT. BASTIAN
        I'm coming in!

                        JESS
        Watch out!

                        ELLO ASTY
        I'm hit!
        The alien pilot's X-wing is blasted to pieces.

                        POE
        All teams - I'm going in! Pull up
        and cover me!

                        NIV LEK
        Copy that, Black Leader! Good luck,
        Poe!
        The trailing X-wings peel off as Poe's black fighter darts
        into the fiery breach.

        INT. STARKILLER BASE - CONTROL ROOM - NEAR DARKNESS

        Outside, the SUN ALMOST COMPLETELY GONE -- PULL BACK THROUGH

        THE WINDOW TO REVEAL A STARKILLER TECHNICIAN:

                        STARKILLER TECHNICIAN
        Weapon at full capacity in thirty
        seconds.

                        GENERAL HUX
        Prepare to fire.

        EXT. STARKILLER BASE - OSCILLATOR - NIGHT

        Poe's X-wing weaves through the breach. A pursuing TIE
        fighter does not clear the gap, leaving Poe to circle the
        interior of the unguarded structure, firing volley after
        volley of torpedoes.

        EXT. STARKILLER BASE - OSCILLATOR - NIGHT

        The remaining X-Wings -- including Poe's -- BLAST the place --
        and the structure begins to CRATER, deep underground

        EXPLOSIONS!

        EXT. FOREST - NIGHT

        Amid the BARE WHITE TREES, ONLY TWO LIGHTSABERS -- LUKE'S
        BLUE AND REN'S YELLOW-RED -- ILLUMINATE the FLURRIES OF SNOW
        as Rey and Kylo Ren BATTLE HARD.
        She seems to be, impossibly, STRONGER THAN HE IS for half a
        dozen blows -- until he FINDS HIS STRENGTH and FIGHTS BACK --
        MOVING FORWARD and PUSHING REY BACK, into the forest.
        Suddenly a COLOSSAL CHUNK OF THE FOREST RIGHT BEHIND REY
        DROPS AWAY! Rey is suddenly fighting on the EDGE OF A

        MASSIVE, BRAND NEW CLIFF!

                        KYLO REN
        You need a teacher! I can show you
        the ways of the Force!

                        REY
        The Force.
        Rey closes her eyes for a long beat. When Rey opens them,
        she is centered, fortified, and she POUNDS BACK, SINGLE HANDED
        SWIPES, hitting Ren's gnarly, spitting saber with incredible
        FORCE. It's so fast now, so furious, that Kylo Ren FALLS
        BACK -- She ATTACKS HARDER!
        Ren gets up again but she HITS HIS SABER'S HILT -- HIS BLADE
        GOES FLYING OFF, TUMBLING INTO THE SNOW -- and she SLASHES

        AGAIN AND AGAIN AND HITS KYLO REN SQUARE IN THE HEAD AND

        CHEST. HE GOES DOWN, SUDDENLY A FEARFUL MAN, A LARGE BURN
        SCAR SLASHED ACROSS HIS FACE! He still reaches for his saber.
        And she could kill him -- right now, with ONE VICIOUS STRIKE!
        But she stops. Realizing she stands on a greater edge than
        even the cliff -- the edge of the dark side. The earth
        SHAKES. The earth splits. A gully forms.

        INT. STARKILLER BASE - CONTROL ROOM - NIGHT

        The area where the RALLY was held is now COLLAPSING into a
        giant sink hole! We WHIP PAN to a YOUNG TECHNICIAN, who
        watches this out the control room window in horror. He
        hurries off, passing COLONEL DATOO, who admonishes:

                        COLONEL DATOO
        Lieutenant, get back to your station!

                        YOUNG TECHNICIAN
        (stops, fleetingly)
        Just look. We won't survive -- even
        Hux has gone!
        As he hurries off, WE HEAR:

        GENERAL HUX (V.O.)
        Supreme Leader.

        INT. STARKILLER BASE - ASSEMBLY ROOM - NIGHT

        Hux stands before SNOKE'S IMAGE. Relative quiet here, but
        distant SOUNDS OF DESTRUCTION. Hux tries to keep it together
        but is horrified, heartsick:

                        GENERAL HUX
        The fuel cells have ruptured. The
        collapse of the planet has begun.
        Snoke takes this in. Furious, desolate... knowing.

                        SNOKE
        Leave the base at once and come to
        me with Kylo Ren.

                        (GRIM)
        It is time to complete his training.

        EXT. FOREST - NIGHT

        Rey turns, runs a hundred feet through the forest to:
        FINN, who lies, near death, not far from where the GROUND
        FELL AWAY. Rey falls to her knees near him, turns him over,
        sees his cauterized but possibly fatal wound.

                        REY
        Finn! Finn...
        Tears come to her eyes as she lifts him, holds his lifeless
        body in her arms. Snow flurries around them as she cries,
        holding this boy who she just met, who she already adores.
        They are left here to die -- nearby MORE TREES DROP as the
        planet continues to COLLAPSE. And just as it seems like all
        is lost... Her wet eyes look up to see:

        LIGHTS RISE FROM THE NEWLY-FORMED CANYON -- IT'S A SHIP WE
        KNOW -- IT'S THE MILLENNIUM FALCON -- and its lights

        ILLUMINATE REY, WHOSE FACE FILLS WITH HOPE!
        CHEWIE IS AT THE CONTROLS. He ROARS to them!

        EXT. FALCON - NIGHT

        Chewie exits the ship.
        MOMENTS LATER Chewie CARRIES FINN up the ramp. Rey hurries
        with them back into the ship --

        INT. FALCON - NIGHT

        Chewie carries Finn inside, followed by Rey.

        EXT. SPACE - NIGHT

        And we FLY WITH THE FALCON as it leaves the planet -- we can
        see CHEWIE AND REY PILOTING, the COLLAPSING PLANET BEHIND
        US. The Resistance X-wings, led by Poe, follow the Falcon.

        INT. X-WING - NIGHT


                        POE
        All teams! I got eyes on them!

                        SNAP
        Yes!
        The X-wings ROAR OFF, skyward as the MUSIC SOARS, the PLANET
        IMPLODES -- THE SUNLIGHT IT CONTAINS BURSTS FORTH, and as we
        get further and further distance from what was Starkiller
        Base, we witness the REBIRTH OF A SUN. Light restored to a
        corner of the galaxy.
        The Millennium Falcon and the X-wings RIP THROUGH SPACE,
        headed home.

                        POE
        Our job's done here. Let's go home!

        EXT. D'QAR - DAY

        ESTABLISHING SHOT as the Falcon on the landing strip.

        EXT. RESISTANCE BASE - DAY

        The Falcon has landed among the remaining Resistance ships.
        Poe is there, watching as Chewie scuttles down the ramp
        carrying an unconscious Finn. Medical Personnel and Officers,
        meet them, usher them inside.

                        MEDIC
        Easy, easy. He's hurt. We've got a
        heartbeat.
        Rey walks down the ramp and sees, for the first time, Leia.
        C-3PO and BB-8 behind her. The crowds are cheering.
        Rey is so sad for Leia, so sorry.
        The two women move for each other. And Leia takes Rey's
        face in her hands. Despite her heartbreak, she is grateful.
        She embraces Rey. A mother's embrace.
        Rey cries, too, in this emotional first meeting.

        INT. RESISTANCE BASE - DAY

        Chewbacca sits quietly, as do many in the base, mourning
        their losses.
        As BB-8 approaches R2-D2, the long dormant droid suddenly
        stirs. The droids beep at each other.

                        C-3PO
        R2-D2! You've come back! You found
        what? How dare you call me that!

                        (MORE)

                        

                        

                        (CONTINUED)

                        CONTINUED:

        C-3PO (CONT'D)
        (he swats R2-D2, who

                        CONTINUES BEEPING)
        Find Master Luke how? Come, R2! We
        must go tell the others at once!

        INT. RESISTANCE BASE - DAY

        Leia stands alone and in silence, heartbroken.

        C-3PO (O.S.)
        General? Excuse me, General?
        Leia turns to see droids.

        C-3PO (CONT'D)
        R2-D2 may contain some much needed
        good news.

                        LEIA
        Tell me.
        Rey stands with Leia, Poe C-3PO, BB-8 and a handful of
        Resistance Officers. Suddenly R2-D2 PROJECTS A HOLOGRAM! A

        LARGE NAVIGATIONAL MAP WITH A SPECIFIC MISSING CHUNK!
        BB-8 BEEPS -- Poe turns to him --

                        POE
        Yeah, all right, buddy, hold on --
        Poe runs over -- removes the ancient data device that Lor
        San Tekka had given him from a base computer. He inserts it
        back inside BB-8, who then PROJECTS HIS MAP -- which he
        SHRINKS DOWN TO SIZE -- and the two droids MOVE SLIGHTLY --

        TOGETHER -- THE TWO HOLOGRAMS UNITE, BB-8'S PIECE FILLING IN

        R2-D2'S PERFECTLY!
        Everyone REACTS -- amazed --

                        C-3PO
        Oh! The map! It is complete!

                        LEIA
        (hand on her heart)
        -- Luke --
        Suddenly there are CHEERS AND EMBRACES.
        C-3PO leans down to R2-D2 and says, quietly, sweetly:

                        C-3PO
        (to R2-D2)
        Oh my dear friend. How I've missed
        you.

        INT. RESISTANCE BASE - I.C.U. - DAY

        A NEW DAY. Finn, unconscious in an I.C.U. POD. His fate
        uncertain. Rey sits with him. Deeply worried. Finally she
        leans in, close to him. She kisses him and says, quietly,
        despite her fear:

                        REY
        We'll see each other again. I believe
        that. Thank you, my friend.

        EXT. D'QAR - DAY

        Chewie does last minute checks of the Falcon. Rey stands
        with Leia a beat and then turns to head to the Falcon. As
        Rey walks off, she hears Leia call out:

                        LEIA
        Rey.
        Rey turns around.

                        LEIA (CONT'D)
        May the Force be with you.
        This fills Rey up. She smiles gratefully. Rey crosses to
        the Falcon.

        INT. MILLENNIUM FALCON - COCKPIT - DAY

        Rey sits in the pilot seat, Chewie as co-pilot. Rey looks
        at him compassionately.
        Rey FLICKS SWITCHES and --

        EXT. D'QAR - DAY

        The Millennium Falcon RISES.
        Leia, with Poe, BB-8, and C-3PO (with his proper arm
        replaced), watches the next generation of Jedi begin her
        journey.

        EXT. SPACE - DAY

        The Falcon FLIES through space and BLASTS to LIGHTSPEED.

        EXT. AHCH-TO - DAY

        A pristine and mighty OCEAN. Endless BLUE, dotted with
        random, beautiful, mountainous BLACK ROCK ISLANDS, dotted
        with countless GREEN TREES.
        The Millennium Falcon FLIES INTO VIEW, BANKS toward one of
        the ISLANDS.

        EXT. AHCH-TO ISLAND - DAY

        Rey, her staff strapped to her back, begins her hike up the
        considerable mountain, glancing back at Chewie and R2-D2,
        who watch her from the bottom of the ramp. A deep breath
        and Rey continues her journey.

        EXT. AHCH-TO ISLAND - STONE STAIRS - DAY

        Built within the rock and foliage of this idyllic island are
        seemingly endless ANCIENT STONE STEPS. Rey continues to
        climb them, determined, despite her fatigue.

        EXT. AHCH-TO ISLAND - STONE STRUCTURES - DAY

        Rey arrives at a clearing. Small, modest, primitive stone
        structures. But no one around. Rey walks past them, sees,
        senses no one.

        And then she stops. Feels something. She turns.
        Standing forty feet away from her, his back to us, is a MAN,
        in a CLOAK AND ROBE.

        Rey stares, knowing exactly who it is. But she just stares
        for what seems like forever. Until he finally TURNS, SLOWLY,
        to her. Pulls back his hood.

        IT IS LUKE SKYWALKER.

        Older now, white hair, bearded. He looks at Rey. A kindness
        in his eyes, but there's something tortured, too. He doesn't
        need to ask her who she is, or what she is doing here. His
        look says it all.

        In response, Rey pulls something from the pack.

        LUKE'S LIGHTSABER.
        And she holds it out to him. An offer. A plea. The galaxy's
        only hope.

        HOLD ON LUKE SKYWALKER'S INCREDIBLE FACE, amazed and
        conflicted at what he sees, as our MUSIC BUILDS, the promise
        of an adventure, just beginning...