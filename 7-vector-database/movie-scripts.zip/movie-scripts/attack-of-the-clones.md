EXT. SPACE
A vast sea of stars severas as a backdrop for the Main Title, following by a rollup, whcih crawls into infinity.

				There is unrest in the Galactic Senate
				Several hundred solar systems under
				the leadership of the rebel leader, Count
				Dooku, have decalred their intentions to
				secede from the Republic.

				This separatist movement has made it
				difficult for the limited number of
				Jedi Kights to maintain peace and
				order in the galaxy.

				Senator Amidala, the former Queen of
				Naboo, is returning to Coruscant
				to vote on the critical issue
				of creating an army to assist the
				overwhelmed Jedi.

PAN UP to reveal the amber city planet of Coruscant. A yellow Naboo Fighter flies OVER CAMERA toward the planet, followed by a large Royal Cruiser and two more Fighters.

EXT. CITYSCAPE, CORUSCANT - DAWN
The ships skim across the surface of the city landscape. The sun glints off the chrome hulls of the sleek Naboo spacecraft as they navigate between the buildings of the capital planet.

EXT. CORUSCANT, LANDING PLATFORM - DAWN
Two Naboo Fighters land on one leaf of a three-leaf-clover landing platform. The Royal Starship lands on the central lead, and the third Fighter lands on the remaining plaform.

A small GROUP OF DIGNITARIES waits to welcome the Senator. One of the members of the group os a well dressed JAR JAR BINKS, a member of the Galactic Representative Commission, and DORME, Senator Amidala's handmaiden.

One of the FIGHTER PILOTS jumps from the wing of his ship and removes his helmet. He is CAPTAIN TYPHO, SENATOR AMIDALA'S Security Officer. He moves over to a WOMAN PILOT.

CAPTAIN TYPHO
We made it. I guess I was wrong,
there was no danger at all.

The ramp ;pwers. TWO NABOO GUARDS appear. SENATOR AMIDALA, ONE HANDMAIDEN (VERSE) and FOUR TROOPERS descend the ramp. AMIDALA is more beautiful now than she was ten years earlier when, as Queen, she was freeing her people from the yoke of the Trade Federation.

The DIGNITARIES start to move forward. SENATOR AMIDALA reaches the foot of the ramp, when suddenly there is a blinding FLASH and a huge EXPLOSION. The DIGNITARIES and PILOTS are hurled to the ground as the starship is destroyed.

Klaxons blare, alarms sound! CAPTAIN TYPHO and the TWO ESCORT PILOTS get up and run to where SENATOR AMIDALA lies dying. Beyond, ARTOO DETOO drops down from the Naboo Fighter and rolls toward the wreckage. The FEMALE ESCORT PILOT kneels by SENATOR AMIDALA and takes off her helmet, revealing SENATOR PADME AMIDALA.

				PADM� 
			Cord�...

She gathers up her decoy double in her arms. Cord�'s eyes are open. She looks up at her.

				CORD�
			... I'm sorry, m'lady... I'm... not sure I... 

CORD� dies. PADM� hugs her.

				AMIDALA
			No!... No!... No!...

PADM� lowers CORD� to the ground. She gets up and looks around at the devastation. There are tears in her eyes.

				AMIDALA
			I should not have come back.

				CAPTAIN TYPHO
			M'Lady, you are still in danger.

Amidala says nothing.

				CAPTAIN TYPHO
			This vote is very important. You did
			your duty and Cord� did hers. Now
			come. (she doesn't respond) M'Lady,
			please!

She turns. They walk away. ARTOO lets out a small whimper and rolls off after them.

EXT. SENATE BUILDING - DAY 
The massive Senate Building glistens in the afternoon sun. Small patches of fog have still to burn off.

INT. SENATE CHAMBER - DAY
The vast rotunda is buzzing with chatter. MAS AMEDDA, the Supreme Chancellor's majordomo, tries to quiet things down as PALPATINE confers with an AIDE, UV GIZEN, riding a small one man floating scooter.

				MAS AMEDDA
			Order! We shall have order! The motion
			for the Republic to commission an army
			takes precedent, and that is what we
			will vote on at this time.

Everything quiets down. The AIDE disperses, and SUPREME CHANCELLOR PALPATINE steps to the podium.

				PALPATINE
			...My esteemed colleagues, excuse
			me... I have just received some
			tragic and disturbing news. Senator
			Amidala of the Naboo system... Has
			been assassinated!

There is a shock silence in the vast arena.

				PALPATINE
				(continued)
			This grievous blow is especially
			personal to me. Before I became
			Chancellor, I served Amidala when
			she was Queen. She was a great
			leader who fought for justice, not
			only in this honourable assembly,
			but also on her home planet. She
			was so loved she could have been
			elected queen for life. She
			believed in public service, and
			she fervently believed in
			democracy. Her death is a great
			loss to us all. We will all mourn
			her as a relentless champion of
			freedom... and as a dear friend.

There is a moment of silence. ASK AAK, the SENATOR of MALASTARE, moves his pod into the centre of the arena.

				SENATOR ASK AAK
			How many more Senators will die
			before this civil strife ends! We
			must confront these rebels now,
			and they need an army to do it.

A second pod moves into the centre of the area with DARSANA, the 
AMBASSADOR OF GLEE ANSELM.

				AMBASSADOR DARSANA
			Why weren't the Jedi able to stop
			this assassination? We are no
			longer safe, under their protection.

Senator ORN FREE TAA swings forward in his pod.

				ORN FREE TAA
			The Republic needs more security
			now! Before it comes to war.

				PALPATINE
			Must I remind the Senator from
			Malastare that negotiations are
			continuing with the separatists.
			Peace is our objective here... not
			war.

The SENATORS yell pro and con. MAS AMEDDA tries to calm things down. SENATOR PADME AMIDALA, with CAPTAIN TYPHO, JAR JAR, and DORME, manoeuvre her pod into the centre of the vast arena.

				AMIDALA
			My noble colleagues, I concur with
			the Supreme Chancellor. At all
			costs, we do not want war!

The Senate goes quiet, then there is an outburst of cheering and 
applause.

				PALPATINE
			It is with great surprise and
			joy the chair recognises the
			Senator from Naboo, Padm� Amidala.

				PADM�
			Less than an hour ago, an
			assassination attempt was made
			against my life. One of my
			bodyguards and six  others were
			ruthlessly and senselessly
			murdered. I was the target but,
			more importantly, I believe this
			security measure before you, was
			the target. I have led the
			opposition to build an army... but
			there is someone in this body who
			will stop at nothing to assure it's
			passage...

Many of the SENATORS boo and yell at SENATOR AMIDALA.

				PADM�
			 	(continuing)
			I warn you, if you vote to create
			this army, war will follow. I
			have experienced the misery of war 
			first-hand; I do not wish to do it
			again.

There is sporadic yelling for and against her statements.

				PADM�
			Wake up, Senators... you must wake
			up! If you offer the separatists
			violence, they can only show us
			violence in return! Many will
			lose their lives. All will lose
			their freedom. This decision
			could very well destroy the very
			foundation of our great Republic.
			I pray you do not let fear push
			you into a disastrous decision.
			Vote down this security measure,
			which is nothing less than a
			declaration of war! Does anyone
			here want that? I cannot believe
			they do.

There is an undercurrent of booing... and groaning. SENATOR ORN FREE TAA moves his pod next to AMIDALA.

				ORN FREE TAA
			My motion to defer the vote must
			be dealt with first. That is the
			rule of law.

AMIDALA looks angry and frustrated. PALPATINE gives her a sympathetic look.

				PALPATINE
			Due to the lateness of the hour
			and the seriousness of this
			motion, we will take up these
			matters tomorrow. Until then, the
			Senate stands adjourned.

EXT. EXECUTIVE QUARTERS BUILDING - DAY 
The giant towers of the Republic Executive Building seem to reach the heavens. Traffic clogs the smoggy sky.

INT. CHANCELLOR'S OFFICE - DAY 
CHANCELLOR PALPATINE sits behind his desk with TWO RED-CLAD ROYAL GUARDS on either side of the door. YODA, PLOT KOON, KI-AD-MUNDI, and MACE WINDU sit acress from him.

				PALPATINE
			I don't know how much longer I can
			hold off the vote, my friends.
			More and more star systems are
			joining the separatists.

				MACE WINDU
			If they do break away -

				PALPATINE
			No! I will not let that happen!

				MACE WINDU
			But if they do, you must realise
			there aren't enough Jedi to
			protect the Republic. We are
			keepers of the peace, not soldiers.

				PALPATINE
			Master Yoda, do you think it will
			really come to war?

YODA closes his eyes.

				YODA
			Worse than war, I fear... Much
			worse. 

				PALPATINE
			What?

				MACE WINDU
			What do you sense, Master?

				YODA
			Impossible to see ... The Dark Side
			clouds everything. But this I am
			sure of -
				(opens his eyes)
			Do their duty the Jedi will.

A muted BUZZER SOUNDS. A hologram of an AIDE, DAR WAC, appears on the Chancellor's desk.

				DAR WAC
			The loyalist committee has arrived,
			my Lord. 

				PALPATINE
			Send them in.

They all stand as SENATOR AMIDALA, CAPTAIN TYPHO, JAR JAR, MAS AMEDDA, DORME, and SENATORS BAIL ORGANA, HOROX RYYDER and ORN FREE TAA enter the office. YODA and MACE WINDU move to greet the SENATOR, YODA taps AMIDALA with his cane.

				YODA
			With you the force is strong...
			young Senator. To see you alive
			brings warm feeling to my heart.

				PADM�
			Thank you, Master Yoda. Do you
			have any idea who was behind
			the attack?

				MACE WINDU
			Our intelligence points to
			disgruntled spice miners, on
			the moons of Naboo.

				PADM�
			I don't wish to disagree but I
			think that Count Dooku was behind
			it.

There is a stir of surprise.

				MACE WINDU
			You know, M'Lady, Count Dooku
			was once a Jedi. He wouldn't
			assassinate anyone, it is not in
			his character.

				KI-ADI-MUNDI
			He is a political idealist, not
			a murderer.

				YODA
			In dark times nothing is what it
			appears to be, but the fact remains
			Senator, in grave danger you are.

PALPATINE gets up, walks to the window, and looks out at the vast city.

				PALPATINE
			Count Dooku has always avoided
			any kind of conflict. It appears
			he has no desire to start a war.
			Why would he kill you? To what end?

				PADM� 
			I don't know, but everything in my
			being tells me he was behind it... 

After gazing out of the window for several moments Palpatine turns to 
Mace.

				PALPATINE
			Master Jedi, may I suggest that
			the Senator be placed under the
			protection of your graces.

				BAIL ORGANA
			Do you think that is a wise use
			of manpower during these stressful
			times?

				PADM�
			Chancellor, if I may comment, I
			do not believe the...

				PALPATINE
			..."situation is that serious."
			No, but I do, Senator.

				PADM�
			Chancellor, please! I don't want
			any more guards!

				PALPATINE
			I realise all too well that
			additional security might be
			disruptive for you, but perhaps
			someone you are familiar with... an
			old friend like... Master Kenobi...

PALPATINE nods to MACE WINDU, who nods back.

				MACE WINDU
			That's possible. He has just
			returned from a Border dispute on
			Ansion.

				PALPATINE
			You must remember him, M'Lady...
			he watched over you during the
			blockade conflict.

				PADM�
			This is not necessary, Chancellor.

				PALPATINE
			Do it for me, M'Lady, please. I
			will rest easier. We had a big
			scare today. The thought of
			losing you is unbearable.

AMIDALA sighs as the JEDI get up to leave.

				MACE WINDU
			I will have Obi-Wan report to you
			immediately, M'Lady.

YODA leans into her ear.

				YODA
			Too little about yourself you
			worry, Senator, and too much about
			politics. Be mindful of your
			danger, Padm�. Accept our help.

As the JEDI leave the office, PALPATINE continues to pace behind his desk.

				PALPATINE
			I will not like this Republiv, that
			has stood for over a thousand
			years, be split in two

EXT. SENATE APARTMENTS - TWILIGHT
A graceful skyscraper twinkles in the evening light of Coruscant.

INT. SENATE BUILDING, APARTMENT CORRIDOR - EVENING
The door to the apartment slides open. JAR JAR walks into the corridor, where TWO JEDI are exiting the elevator. He recognises OBI-WAN and becomes extremely excited, jumping around, shaking his hand.

				JAR JAR
			Obi! Obi! Obi! Mesa sooo smilen
			to see'en yousa. Wahoooooo!

OBI-WAN smiles.

				OBI-WAN
			It's Good to see you, too, Jar Jar.

				JAR JAR
			Oops! Wheresa mesa manners?
			Excuse me, Master Obi-Wan. I
			completely forgot myself for
			a moment there. I have had to learn
			Diplodiaclect... speak it like a
			native now. Don't really see the
			point, actually, but members of
			the Senate seem to prefer it...

JAR JAR notices OBI-WAN'S APPRENTICE.

				JAR JAR
				(continuing)
			...and this, I take it, is your
			apprentice... Nooooooooo! Annie?
			Noooooooo! Little Bitty Annie?
				(Looks at Anakin)
			Nooooooo! Yousa so biggen!
			Yiyiyiyyi! Annie!! Mesa no
			believen.

				ANAKIN
			Hi, Jar Jar.

JAR JAR grabs hold of ANAKIN and envelops him in a big hug.

				JAR JAR
			Annie! Annie! Yiyiyiyiyiyiiii!

INT. SENATE BUILDING, APARTMENT - EVENING
PADME is in a conference with CAPTAIN TYPHO and DORME. JAR JAR enters the room, followed by the TWO JEDI.

				JAR JAR
			Lookie... lookie... Oops!... Oh,
			dear, I'm afraid I've forgotten
			myself again.

PADME and TYPHO rise as OBI-WAN and ANAKIN stop before the SENATOR. OBI-WAN steps forward. ANAKIN stares at PADME. She glances at him.

				OBI-WAN
			It's a great pleasure to see you again,
			M'Lady.

				PADM�
			It has been far too long Master
			Kenobi. I'm so glad our paths
			have crossed again... but I must
			warn you that I think your
			presence here is unnecessary.

				OBI-WAN
			I'm sure the Jedi Council have
			their reasons.

She moves in front of ANAKIN

				PADM�
			Annie??
				(stares)
			My goodness you've grown.

They look at each other for a long moment.

				ANAKIN
				(trying to be smooth)
			So have you... grown more
			beautiful, I mean... and much
			shorter... for a Senator, I mean.

OBI-WAN looks disapprovingly at his apprentice. PADME laughs and shakes her head.

				PADM�
			Oh Annie, you'll always be that
			little boy I knew on Tatooine.

This embarrasses ANAKIN, and he looks down. OBI-WAN and CAPTAIN TYPHO smile.

				OBI-WAN
			Our presence will be invisible,
			M'Lady.

				CAPTAIN TYPHO
			I am very grateful you are here,
			Master Kenobi. The situation is
			more dangerous than the Senator
			will admit.

				PADM�
			I don't need more security, I need
			answers. I want to know who is
			trying to kill me.

				OBI-WAN
				(frowning)
			We're here to protect you
			Senator, not to start an
			investigation.

				ANAKIN
			We will find out who is trying to
			kill you Padm�, I promise you.

He's done it again. He bites his lip in frustration and shame. OBI-WAN gives ANAKIN a dirty look.

				OBI-WAN
			We are not going to exceed our
			mandate, my young Padawan learner.

				ANAKIN
			I meant in the interest of
			protecting her, Master, of course.

				OBI-WAN
			We are not going through this
			exercise again, Anakin. You will
			pay attention to my lead.

				ANAKIN
			Why?

				OBI-WAN
			What??!!

				ANAKIN
			Why else do you think we were
			assigned to her, if not to find
			the killer? Protection is a job
			for local security... not Jedi.
			It's overkill, Master.
			Investigation is implied in our
			mandate.

				OBI-WAN
			We will do as the Council has
			instructed, and you will learn
			your place, young one.

				PADM�
			Perhaps with merely your presence,
			the mysteries surrounding this
			threat will be revealed.  Now if
			you will excuse me I will retire.

Everyone gives AMIDALA a slight bow as she and DORME leave the room.

				CAPTAIN TYPHO
			Well, I know I feel a lot better
			having you here.
			I'll have an officer on every
			floor and I'll be at the command
			centre downstairs.

				JAR JAR 
			Mesa busten wit happiness seein
			Yousa again, Annie. Deesa bad
			times, bombad times.

Captain Typho leaves.

				ANAKIN
			She didn't even recognise me, Jar
			Jar. I thought about her every
			day since we parted... and she's
			forgotten me completely.

				JAR JAR
			Shesa happy. Happier den mesa
			see-en her in longo time.

				OBI-WAN
			Anakin, you're focusing on the
			Negative again. Be mindful of your
			thoughts. She was glad to see us.
			Now lets check the security here.

				ANAKIN
			Yes, my master.

EXT. JEDI TEMPLE - EVENING
The vast Jedi Temple sits on an endless flat plain, silhouetted by a against the traffic-filled sky.

INT. JEDI TEMPLE, CORRIDOR - EVENING
MACE WINDU and YODA walk down the long hallways, silhouetted by a lit room at the end.

				MACE WINDU
			Why couldn't we see this attack on
			the Senator?

				YODA
			Masking the future, is this
			disturbance in the Force.

				MACE WINDU
			The propecy is coming true, the
			Dark Side is growing.

				YODA
			And only those who have turned to
			the Dark Side can sense the
			possibilities of the future. Only
			going through the Dark Side can we
			see.

				MACE WINDU
			It's been ten years, and the Sith
			still have no shown themselves.
			Do you think they are behind this?

				YODA
			...Out there, they are. A
			certainty that is.

				MACE WINDU
			Do you think Obi-Wan's apprentice
			will be able to bring balance to
			the Force?

				YODA
			Only if he chooses to follow his
			destiny.

There is a long silence as they walk away. Only footsteps are heard.

INT. SENATE BUILDING, AMIDALA'S APARTMENT, BEDROOM - NIGHT
PADME is asleep in her bed, lit only by the light of the city outside her window coming through the blinds. ARTOO stands in the corner of the bedroom. His power is off.

INT. SENATE BUILDING, AMIDALA'S APARTMENT, MAIN R0OM - NIGHT
ANAKIN is standing in the living room. He is in a meditative state. It is quiet. We hear DISTANT FOOTSTEPS in the corridor outside the apartment. Suddenly ANAKIN'S eyes pop open. His eyes dart around the room. He reaches for his lightsaber, then smiles and puts it back in his belt.

The door to the apartment slides open, and OBI-WAN enters.

				OBI-WAN
			Captain Typho has more than enough
			men downstairs. No assassin will
			try that way. Any activity up
			here?

				ANAKIN
			Quiet as a tomb. I don't like
			just waiting here for something to
			happen to her.

OBI-WAN checks a palm-sized view scanner he has pulled out of his utility belt. It shows a shot of ARTOO by the door, but no sign of PADME on the bed.

				OBI-WAN
			What's going on?

ANAKIN shrugs.

				ANAKIN
			She covered that camera. I don't
			think she liked me watching her.

				OBI-WAN
			What is she thinking?

				ANAKIN
			She programmed Artoo to warn us if
			there's an intruder.

				OBI-WAN
			It's not an intruder I'm worried
			about. There are many other ways
			to kill a Senator.

				ANAKIN
			I know, but we also want to catch
			this assassin. Don't we, Master?

				OBI-WAN
			You're using her as bait??

				ANAKIN
			It was her idea... No harm will
			come to her. I can sense
			everything going on in that room.
			Trust me.

				OBI-WAN
			It's too risky... and your senses
			aren't that attuned, young
			apprentice.

				ANAKIN
			And yours are?

				OBI-WAN
			Possibly.

INT. SENATE BUILDING, AMIDALA'S APARTMENT, BEDROOM - NIGHT
As PADME sleeps, a PROBE DROID approaches outside her window. It sends out several small arms that attach to the window, creating sparks that shut down the security system. Then a large arm cuts a small hole in the glass. A FAINT SOUND is heard as the small section of glass is removed from the window.

ARTOO wakes up, and his lights go on. The PROBE DROID freezes. ARTOO looks around, makes a PLAINTIVE LITTLE SOUND, then shuts down again. The PROBE DROID attaches a little tube to the window. TWO DEADLY LOOKING CENTIPEDE-LIKE KOUHUNS exit the tube, crawl through the blinds and head toward the sleeping PADME.

INT. SENATE BUILDING, AMIDALA'S APARTMENT, MAIN ROOM - NIGHT
ANAKIN and OBI-WAN continue their conversation in the main room of the apartment.

				OBI-WAN 
			You look tired.

				ANAKIN
			I don't sleep well, anymore.

				OBI-WAN 
			Because of your mother?

				ANAKIN
			I don't know why I keep dreaming
			About her now. I haven't seen her
			since I was little.

				OBI-WAN
			Dreams pass in time.

				ANAKIN
			I'd rather dream of Padm�. Just
			Being around her again is...
			intoxicating.

				OBI-WAN
			Mind your thoughts, Anakin, they
			betray you. You've made a
			commitment to the Jedi order... a
			commitment not easily broken...
			and don't forget she's a
			politician. They're not to be
			trusted.

				ANAKIN 
			She's not like the others in the
			Senate, Master.

				OBI-WAN
			It's been my experience that
			Senators are only focused on
			pleasing those who fund their
			campaigns... and they are more
			than willing to forget the
			niceties of democracy to get those
			funds.

				ANAKIN
			Not another lecture, Master. Not
			on the economics of politics....
			It's too early in the morning... and
			besides, you're generalising. The
			Chancellor doesn't appear to
			be corrupt.

				OBI-WAN
			Palpatine's a politician, I've
			observed that he is very clever at
			following the passions and
			prejudices of the Senators.

				ANAKIN
			I think he is a good man. My
			instincts are very positive
			about...

ANAKIN looks stunned. He looks sharply at OBI-WAN

				OBI-WAN
			I sense it, too.

INT. SENATE BUILDING, AMIDALA'S APARTMENT, BEDROOM - NIGHT
ARTOO sounds an alarm and shines a light on the bed. THE KOUHUNS are inches from PADME'S face. Their mouths are open, and wicked stinger tongues flick out.


OBI-WAN and ANAKIN burst into the room. The KOUHUNS stand on their hind legs and hiss as PADME wakes up. ANAKIN throws himself in front of her, whacking in half the deadly creatures with his lightsaber.

OBI-WAN sees the DROID outside the window and raqces straight at it, crashing through the blinds as he goes through the window.

EXT. WINDOW LEDGE, APARTMENT BUILDING - NIGHT
OBI-WAN flies through the glass window and flings himself at the PROBE DROID, grabbing onto the deadly machine before it can flee. The PROBE DROID sinks under the weight of OBI-WAN but manages to stay afloat and fly away, with the Jedi hanging on for dear life, a hundred stories above the city.

INT. SENATE BUILDING, AMIDALA'S APARTMENT - NIGHT
ANAKIN and PADME stare at the sight of OBI-WAN being carried off by the DROID. ANAKIN turns to her. She pulls her nightdress around her shoulders.

				ANAKIN
			Stay here!

CAPTAIN TYPHO, with TWO GUARDS and DORME, enter the room as Anakin dashes out.

EXT. CITYSCAPE, CORUSCANT - NIGHT
The PROBE DROID sends several protective electrical shocks across its surface, causing OBI-WAN to almost lose his grip. As they dart in and out of the speeder traffic, OBI-WAN disconnects a wire on the back of the DROID. Its power shuts off! OBI-WAN and the DROID drop like rocks. OBI-WAN realises the error of his ways and quickly puts the wire back. The DROID'S systems light up again and it takes off. 

EXT. SENATE APARTMENTS - ENTRANCE - NIGHT
ANAKIN charges out of the building and runs to a line of parked speeders. He vaults into an open one and takes off, gunning it fast toward the lines of speeder traffic high above.

EXT. CITYSCAPE, CORUSCANT - NIGHT
The DROID bumps against a wall, hoping to knock the Jedi loose. It moves behind a speeder afterburner to scorch him. It takesthe JEDI wildly between buildings and finally skims across a rooftop as OBI-WAN is forced to lift his legs, tenaciously hanging onto the DROID. The DROID heads for a dirty, beat-up speeder hidden in an alcove of a building about twenty stories up. When the pilot of the speeder, a scruffy bounty hunter called ZAM WESELL, sees the DROID approach with OBI-WAN hanging on, she pulls a long rifle out of the speeder and starts to fire at the JEDI. EXPLOSIONS burst all around OBI-WAN.

				OBI-WAN
			I have a bad feeling about this.

FINALLY, the DROID suffers a direct hit and blows up. OBI-WAN falls fifty stories, until a speeder drops down next to him, and he manages to grab onto the back end of the speeder and haul himself toward the cockpit. The JEDI struggles to climb into the passenger seat of the open speeder and sit down next to the driver, ANAKIN.

				ANAKIN
			That was wacky! I almost lost you
			in the traffic.

				OBI-WAN
			What took you so long?

				ANAKIN
			Oh, you know, Master, I couldn't
			find a speeder I really liked,
			with an open cockpit... and with
			the right speed capabilities...
			and then you know I had to get a
			really gonzo color...

They zoom upward in hot pursuit of ZAM asshe fires out the open window at them with her laser pistol.

				OBI-WAN
			If you'd spend as much time
			working on your saber skills as
			you do on your wit, young Padawan,
			you would rival Master Yoda as a
			swordsman.

				ANAKIN
			I thought I already did.

				OBI-WAN
			Only in your mind, my very young
			apprentice. Careful!! Hey, easy!!

As this conversation is going on, ANAKIN deftly moves in and out of the oncoming traffic, across lanes, between buildings, and miraculously through a construction site. ZAM WESELL continues firing at them.

				ANAKIN
			Sorry, I forgot you don't like
			flying, Master.

				OBI-WAN
			I don't mind flying... but
			what you're doing is suicide!

They barely miss a commuter train

				ANAKIN
			Master, you know I've been flying
			since before I could walk. I'm very
			good at this.

				OBI-WAN
			Just slow down!

ZAM WESSEL and the JEDI race through a line of cross-traffic made up of giant trucks. The speeders bank sideways as they slide around right-angle turns between buildings. ZAM races into a tram tunnel.

				OBI-WAN
				(continuing)
			Wait! Don't go in there!

ANAKIN zooms into the tunnel after ZAM. They see a tram coming at them. They brake, turn around, and race out, barely ahead of the charging commuter transport.

				OBI-WAN
				(continuing)
			You know I don't like it when you
			do that!

				ANAKIN
			Sorry, Master. Don't worry, this
			guy's gonna kill himself any
			minute now!

ZAM WESSEL turns into oncoming traffic, deliberately trying to throw the JEDI off. Oncoming speeders swerve, trying to avoid ZAM and the JEDI. ZAM does a quick, tight loop-over and ends up behind the JEDI. She is now in a much better position to fire at them with her laser pistol. To avoid being hit by the laser bolts, ANAKIN slams on the brakes and moves alongside ZAM. She now fires point-blank at OBI-WAN.

				OBI-WAN
			What are you doing? He's gonna
			blast me!

				ANAKIN
			Right - this isn't working.

ANAKIN slides underneath Zam's speeder. They race along in traffic, one speeder right on top of the other. The BOUNTY HUNTER skims over the rooftops, causing ANAKIN to drop behind. ANAKIN goes through his gears, zooming around traffic. They race at high speed across a wide, flat surface of the city planet. A large spacecraft almost collides with them as it attempts to land. They round a corner and clip a flag, which gets caught on one of the front air scoops.

				OBI-WAN
			That was too close!

				ANAKIN
			Clear that!

				OBI-WAN
			What??

				ANAKIN
			Clear the flag! We're losing
			power! Hurry!

OBI-WAN leans out of the speeder, then crawls out onto the front engine, pulling the flag free of the scoop. The speeder lurches forward with a surge of power.

				OBI-WAN
			Whooooaaa! Don't do that! I
			don't  like it when you do that!

				ANAKIN
			So sorry, Master.

They chase the BOUNTY HUNTER through a power refinery.

				OBI-WAN
			It's dangerous near those power
			couplings! Slow down! Don't go
			through there!

Huge electrical bolts shoot between the buildings as the speeders pass.

				OBI-WAN
				(continuing)
			Yiiii, what are you doing?

				ANAKIN
			Sorry, Master!

				OBI-WAN
				(sarcastically)
			Oh, that was good...

				ANAKIN
			That was crazy!!!

ZAM slides around a corner sideways, blocking an alley, firing point-blank as ANAKIN approaches.

				ANAKIN
				(continuing)
			Ahh, damn.

				OBI-WAN
			Stop!!

				ANAKIN
			No, we can make it.

ANAKIN barely misses the BOUNTY HUNTER'S speeder as he dives under it, and through a small gap in the building hitting several pipes and going wildly out of control. ANAKIN struggles to regain control of the speeder, narrowly missing a crane, barely clipping a pair of giant struts. A giant gasball shoots up, causing ANAKIN to spin and bump a building, stalling the speeder.

				OBI-WAN
			I'm crazy... I'm crazy... I'm
			crazy.

				ANAKIN
			But it worked... we made it.

				OBI-WAN
				(angrily)
			It didn't work... we've stalled!
			And you almost got us killed!

				ANAKIN
			I think we're still alive.

ANAKIN works to get the speeder started. It quickly races to life.

				OBI-WAN
				(very angrily)
			It was stupid!

				ANAKIN
				(sheepishly)
			I could have made it...

				OBI-WAN
				(furious)
			But you didn't!!! And now we've
			lost him.

Suddenly, there is an ambush. Laser bolts fire everywhere. EXPLOSIONS surround them. They look up to see ZAM WESSEL take off.

				ANAKIN
			No we didn�t...

Out of a cloud of smoke and ball of flames the JEDI tear after ZAM. They are smoking. OBI-WAN slaps out the small fire on the dashboard. ZAM goes up and down, through cross-traffic. There is a near miss as a speeder almost hits them. ZAM turns down and left between two buildings. ANAKIN pulls up and to the right

				OBI-WAN
			Where are you going?! He went
			down there, the other way.

				ANAKIN
			This is a shortcut... I think.

				OBI-WAN
			What do you mean, �You think?�
			What kind of shortcut?! He went
			completely the other way! You�ve
			lost him!

				ANAKIN
			Master, if we keep this chase
			going, that creep�s gonna end up
			deep fried. Personally, I�d very
			much like to find out who in the
			hell he is and who he�s working
			for...

				OBI-WAN
				(sarcastic)
			Oh, so that�s why we�re going in
			the wrong direction.

ANAKIN turns up a side street, zooming up several small passageways, then stops, hovering about fifty stories up.

				OBI-WAN
				(continuing)
			Well, you lost him.

				ANAKIN
			I�m deeply sorry, Master.

ANAKIN looks around front and back. He spots something. He seems to 
start counting to himself as he watches something below approach.

				ANAKIN
				(continuing)
			Excuse me for a moment.

ANAKIN jumps out of the speeder. OBI-WAN looks down and sees Zam�s speeder about five stories below them cruising past. ANAKIN miraculously lands on top of the Bounty Hunter�s speeder. The speeder wobbles under the impact. ZAM looks up and realises what has happened.

ZAM takes off, and ANAKIN slides to the back strut and almost slips off, but manages to hang on. ANAKIN works his way back to the speeder�s cockpit, just as ZAM stops suddenly, and ANAKIN flies forward to the left front fork. ZAM shoots at him with a laser pistol. There is a BLAST near ANAKIN'S hand, which breaks off a piece of the speeder. ANAKIN slides to the right fork of the speeder, where ZAM can�t reach him. He scrambles to the top, holding onto an air scoop.

OBI-WAN has jumped into the driver�s seat of his speeder and is deftly gaining on the rogue speeder. The two speeders dive through oncoming traffic and then through cross traffic. Finally, ANAKIN is able to get hold of his lightsaber and starts to cut his way through the roof of the speeder. ZAM takes out her laser pistol and starts firing at the helpless JEDI, knocking the sword out of his hand. OBI-WAN races under the speeder and catches the Jedi weapon in the passenger�s seat.

ANAKIN sticks his hand into the cockpit and, using the Force, pulls the gun out of ZAM�S hand. She grabs the Jedi�s hand, and they struggle for the weapon. It goes off, blowing a hole in the floor of the speeder. The speeder careens wildly out of control. ZAM struggles to pull the speeder out of it�s nose dive. OBI-WAN gets slowed down by traffic and loses sight of the Bounty Hunter�s speeder.

Just as the dragster is about to nose dive into the ground, ZAM pulls it out, and it slides hard on the pavement in a shower of sparks. ANAKIN goes flying into the street.

EXT. ENTERTAINMENT STREET - NIGHT
ZAM exits the crashed speeder and runs. ANAKIN picks himself up off the pavement and runs down the very crowded street.

It's the seedy underbelly of the city. Broken sidewalks, garish lights reflected on the filthy puddles. It's pretty crowded with various ALIEN LOW-LIFES, PANHANDLING DROIDS, and the occasional group of UPPERCLASS SLUMMERS.

ANAKIN barges into several of them as he chases after the fleeing ZAM. He loses the Bounty Hunter in the crowd, them sees him again. The young Jedi is having a very difficult time getting through the crowd.

Ahead, ZAM turns in through a door and disappears.

A nightclub sighs is flashing over the door. ANAKIN is just about to follow ZAM when there is a sudden swirl of litter from downthrusters. PEOPLE start moving out of the way, and the open speeder lands in the street beside him. OBI-WAN gets out and walks over, holding out ANAKIN'S lightsaber.

				OBI-WAN
			Anakin!

				ANAKIN
			She went into that club, Master.

				OBI-WAN
			Patience.

OBI-WAN hands ANAKIN the lightsaber.

				OBI-WAN
			 	(continuing)
			Here. Next time try not to lose it.

				ANAKIN
			Sorry, Master.

ANAKIN reaches for the lightsaber, but OBI-WAN holds it back.

				OBI-WAN
			A Jedi's saber is his most
			precious possession.

				ANAKIN
			Yes, Master.

He reaches for the lightsaber, OBI-WAN pulls it back.

				OBI-WAN
			He must keep it with him at all
			times.

				ANAKIN
			I know, Master.

				OBI-WAN
			This weapon is your life!

				ANAKIN
			I've heard this lesson before...

OBI-WAN finally holds out the lightsaber and ANAKIN grabs it.

				OBI-WAN
			But, you haven't learned anything,
			Anakin.

				ANAKIN
			I try, Master.

INT. NIGHTCLUB - NIGHT
OBI-WAN and ANAKIN enter the nightclub bar, and everyone stares at them

				OBI-WAN
			Why do I think you are going to be
			the death of me?!

				ANAKIN
			Don't say that Master... You're
			the closest thing I have to a
			father... I love you. I don't want
			to cause you pain.

				OBI-WAN
			Then why don't you listen to me?!

				ANAKIN
			I will. I'll do better, I promise.

				OBI-WAN
			Do you see him him?

				ANAKIN
			I think he's a she...

				OBI-WAN
			Then be extra careful...
				(nods to a room)
			Check it out.

OBI-WAN goes away.

				ANAKIN
			Where are you going, Master?

				OBI-WAN
			To get a drink.

OBI-WAN heads for the bar. ANAKIN blinks in surprise, then moves into the room, where ALIEN FACES look back at him with hostility, suspicion, and invitation as he moves among the tables. OBI-WAN arrives at the bar. He signals the BARMAN.

CLOSE - Somewhere in the room a HAND moves to a pistol in its holster and unsnaps the safety catch. At the bar, a glass is placed in from of OBI-WAN. A drink is poured. He lifts the glass.

				ELAN SLEAZEBAGGANO
			Wanna buy some death sticks?

OBI-WAN looks at him. He moves his fingers slightly.

				OBI-WAN
			You don't want to sell me death-
			sticks.

				ELAN
			I don't want to sell you death-
			sticks.

OBI-WAN moves his fingers.

				OBI-WAN
			You want to go home and rethink 
			your life.

				ELAN
			I want to go home and rethink my
			life.

He leaves. OBI-WAN lifts the drink and tosses it back.

CLOSE. The gun is drawn from its holster and held down out of sight. The BOUNTY HUNTER starts to move toward the bar.

ANAKIN checks out ALIEN FACES. OBI-WAN signals for another drink. The gun moves toward his unsuspecting back.

The drink is poured. OBI-WAN reaches for it. The gun is raised to aim directly at his back, and suddenly OBI-WAN turns fast. His lightsaber flashes. There is a shrill SCREAM and ZAM'S ARM hits the floor. The gun drops from its twitching fingers. Blood spreads.

The room is silent. ALIENS rise menacingly from their seats, and ANAKIN is suddenly at OBI-WAN's side, his lightsaber glowing.

				ANAKIN
			Easy... Official business. Go
			back to your drinks.

Slowly, the ALIENS sit. Conversation resumes. Onstage, THE PERFORMERS pick up their routine. OBI-WAN and ANAKIN lift ZAM and carry her out.

EXT. ALLEY OUTSIDE NIGHTCLUB - NIGHT
OBI-WAN and ANAKIN carry ZAM into the alley and lower her to the ground. OBI-WAN attends to her wounded shoulder. She stares up hatefully at ANAKIN. She winces in pain, then nods.

				OBI-WAN
			Do you know who it was you were
			trying to kill?

				ZAM WESSEL
			The Senator from Naboo.

				OBI-WAN
			Who hired you?

ZAM glares at OBI-WAN.

				ZAM WESSEL
			It was just a job.

				ANAKIN
			Tell us!

				ZAM WESSEL
			That Senator's gonna die soon
			anyway, and the next one won't
			make the same mistake I did...

				OBI-WAN
			This wound's going to need
			treatment.

				ANAKIN
			Who hired you? Tell us... tell us
			now!

ZAM glares hatefully.

				ZAM
			It was a Bounty Hunter called...

There is a sudden FTZZZ sound. ZAM twitches. She blinks in surprise and dies.

There is a WEOOSH from above. OBI-WAN and ANAKIN look up yo see an ARMOURED ROCKET-MAN taking off from a roof high above. OBI-WAN looks down at ZAM. He touches her neck and pulls out a small, wicked-looking dart.

				OBI-WAN
			Toxic Dart...

INT. SENATE BUILDING, AMIDALA'S APARTMENT - DAY
ANAKIN and JAR JAR stand near the door of the anteroom to PADME'S 
bedroom. PADME and DORME move about packing luggage.

				PADM�
			Representative Binks. I know I can
			count on you.

				JAR JAR
			Yousa betchen mesa bottums.

				PADM�
			What?!

				JAR JAR
				(coughs, recovers)
			Oh, pardone-ay, Senator. I mean,
			I am honoured to accept this heavy
			burden. I take on this
			responsibility with deep humility
			tinged with an overwhelming pride.
				(pompously)
			It is not every day that I am
			called upon to...

PADME kisses him on the cheek and gives him a hug. JAR JAR turns red.

				PADM�
			You're a good friend, Jar Jar. I
			don't wish to hold you up. I'm
			sure you have a great deal to do.

				JAR JAR
			Of course, M'lady.

JAR JAR bows and goes out. As he passes ANAKIN, he flashes a dazzling smile... PADME is in a very bad mood.

				PADM�
			I do not like this idea of hiding.

				ANAKIN
			Don't worry. Now that the Council
			has ordered an investigation, it
			won't take Master Obi-Wan long to
			find that bounty hunter.

				PADM�
				(frustrated)
			I haven't worked for a year to
			defeat the "Military Creation Act"
			not to be here when its fate is
			decided.

				ANAKIN
			Sometimes we have to let go of our
			pride and do what is requested of
			us.

				PADM�
			Pride?!? Annie, you're young, and
			you don't have a very firm grip on
			politics. I suggest you reserve
			your opinions for some other time.

				ANAKIN
			Sorry, M'lady. I was only trying
			to...

				PADM�
			Annie! No!

				ANAKIN
			Please don't call me that.

				PADM�
			What?

				ANAKIN
			Annie...

				PADM�
			I've always called you that... it
			is your name, isn't it?

				ANAKIN
			It's Anakin. When you say Annie
			it's like I'm still a little
			boy... and I'm not.

				PADM�
			I'm sorry, Anakin. It's impossible
			to deny you've...
				(looks him over)
			...that you've grown up.

PADME smiles at ANAKIN. He becomes a little shy.

				ANAKIN
			Master Obi-Wan manages not to see
			it...

				PADM�
			Mentors have a way of seeing more
			of our faults than we would like.
			It's the only way we grow.

				ANAKIN
			Don't get me wrong... Obi-Wan is
			a great mentor. As wise as Master
			Yoda and as powerful as Master
			Windu. I am truly thankful to be
			his apprentice. Only... although
			I'm a Padawan learner, in some
			ways... a lot of ways... I'm ahead
			of him. I'm ready for the trials.
			I know I am! He knows it too. He
			believes I'm too unpredictable...
			Other Jedi my age have gone
			through the trials and made it...
			I know I started my training
			late... but he won't let me move
			on.

				PADM�
			That must be frustrating.

				ANAKIN
			It's worse... he's overly
			critical. He never listens! He
			just doesn't understand! It's not
			fair!

PADME cannot surpress a laugh. She shakes her head.

				PADM�
			I'm sorry... You sounded exactly
			like that little boy I once knew,
			when he didn't get his way.

				ANAKIN
			I'm not whining! I'm not.

PADME just smiles at him. DORME laughs in the background.

				PADM�
			I didn't say it to hurt you.

				ANAKIN
			I know...

There is a brief silence. PADME comes over to ANAKIN.

				PADME
			Anakin...

They look into each other's eyes for the first time.

				PADM�
				(continuing)
			Don't try to grow up too fast.

				ANAKIN
			I am grown up. You said it
			yourself.

ANAKIN looks deep into PADME'S eyes.

				PADM�
			Please don't look at me like that.

				ANAKIN
			Why not?

				PADM�
			Because I can see what you're
			thinking.

				ANAKIN
				(laughing)
			Ahh... so, you have Jedi powers
			too?

DORME is watching with concern.

				PADM�
			It makes me feel uncomfortable.

				ANAKIN
			Sorry, M'lady.

ANAKIN backs away as PADME turns and goes back to her packing.

EXT. CORUSCANT, SPACEPORT FREIGHTER DOCKS, TRANSPORT BUS - DAY 
A small bus speeds toward the massive freighter docks of Coruscant's Industrial area. The spaceport is bustling with activity. Transports of various sizes moves supplies and passengers as giant floating cranes lift cargo out of starships. The bus stops before a huge intergalactic freighter starship. It parks in the shadows of an overhang.

INT. CORUSCANT, SPACEPORT FREIGHTER DOCKS, TRANSPORT BUS - DAY
ANAKIN and PADME, dressed in Outland peasant outfits, get up and head for the door where CAPTAIN TYPHO, DORME and OBI-WAN are waiting to hand them their luggage. DORME is dressed to look like Senator Amidala.

				CAPTAIN TYPHO
			Be safe, m'lady.

				PADM�
			Thank you, Captain. Take good
			care of Dorme... the threat's on
			you two now.

				DORME
			He'll be safe with me.

They laugh, and PADME embraces her faithful handmaiden. DORME start to weep.

				PADM�
			You'll be fine.

				DORME
			It's not me, M'Lady. I worry
			about you. What if they realise
			I'm not you?

				PADM�
				(looks to Anakin)
			Then my Jedi protector will have
			to prove how grown up he is.

DORME and PADME smile. ANAKIN frowns as OBI-WAN pulls him aside.

				OBI-WAN
			Anakin, you stay put on Naboo.
			Do not attract any attention. Do
			absolutely nothing without
			checking in with me or the Council.

				ANAKIN
			Yes, Master.

				OBI-WAN
				(to Padme)
			I will get to the bottom of this
			plot quickly, M'Lady. You'll be
			back here in no time.

				PADM�
			I will be most grateful for your
			speed, Master Jedi.

				ANAKIN
			Time to go.

				PADM�
			I know. 

PADME gives DORME a last hug. ANAKIN picks up the luggage, and the TWO PEASANTS exit the speeder bus, where ARTOO is waiting for them.

				OBI-WAN
			May the Force be with you.

				ANAKIN
			May the Force be with you, Master.

They head off toward the giant Starfreighter.

				PADM�
			Suddenly, I'm afraid...

				ANAKIN
			I'm kinda scared too. This is my
			first assignment on my own.

				PADM�
			There's nothing to worry about...
			we have Artoo with us.

The two laugh.

OBI-WAN and CAPTAIN TYPHO watch ANAKIN and PADME disappear into the 
vastness of the spaceport with ARTOO trundling along behind them.

				OBI-WAN
			I hope he doesn't try anything
			foolish.

				CAPTAIN TYPHO
			I'd be more concerned about her
			doing something, than him.

EXT. FREIGHTER DOCKS - CORUSCANT - DAY
The freighter slowly takes off from the huge docks area of Coruscant. It soon moves into the crowded skies.

INT. JEDI TEMPLE, MAIN HALLWAY - LATE DAY
From high above, light streams down from the lofty ceilings. OBI-WAN crosses the floor of the great hallway, heaading for the Analysis Rooms.

INT. JEDI TEMPLE, ANALYSIS CUBICLES - LATE DAY
OBI-WAN walks past several glass cubicles where work is going on. He comes to an empty one and sits down in front of a console. A PK-4 ANALYSIS DROID comes to life. A tray slides out of the console.

				PK-4
			Place the subject for analysis on
			the sensot tray, please.

OBI-WAN puts the dart onto the traym which retracts into the console. The DROID activates the system, and a screen lights up in from of OBI-WAN.

				OBI-WAN
			It's a toxic dart. I need to know
			where it came from and who made it.

				PK-4
			One moment, please.

Diagrams and .... appear on the screem, scrolling past at great speed. OBI-WAN watches as the screen goes blank. They tray slides out.

				PK-4
				(continuing)
			As you can see on your screen,
			subject weapon does not exist in
			any known culture. Markings
			cannot be identified. Probablt
			self-made by a warrior not
			associated with any known society.

				OBI-WAN
			Excuse me? Could you try again
			please?

				PK-4
			Master Jedi, our records are very
			thorough. they cover eight
			percent of the galaxy. If I can't
			tell you where it came from,
			nobody can.

OBI-WAN picks up the dart and looks at it, then looks to the DROID.

				OBI-WAN
			Thanks for your assistance! You
			may not be able to figure this
			out, but I think I know someone
			who might.

EXT. SPACE, STARSHIP FREIGHTER
The massive, slow-moving Freighter suddenly zooms away into lightspeed.

INT. STARFREIGHTER, STORAGE HOLD - DAY
The great, gloomy hold is crowded with EMIGRANTS and their belongings. To one side ARTOO is coming to the head of a food line, where SERVERS are ladling out bowls of mush. ARTOO holds two bowls.

				SERVER
			Keep moving! Keep moving!

ARTOO slips tube into a tub of mush and sucks up a large quantity. With one of his little claw-arms, he grabs several chunks of something that looks like brown bread. A SERVER sees him.

				FOOD SERVER
				(continuing)
			Hey! No Droids!

ARTOO takes one last big suck and heads away from the food line. The SERVER shouts after him angrily. The little droid moves past groups of eating or sleeping EMIGRANTS and comes to where ANAKIN is sound asleep. The young Jedi seems to be having a nightmare. He is very restless.

				ANAKIN
			No, no, Mom, no...

He is sweating. PADME leans over to wipe some of the sweat from his forehead. He wakes up with a start, then realises where he is. PADME simply looks at him. He stares back, somewhat confused. ARTOO fills up two bowls with mush.

				ANAKIN
				(continuing)
			What?

				PADM�
			You seemed to be having a
			nightmare.

ANAKIN looks at PADME a little more closely, trying to see if he has revealed any of his secrets. She hands him a bowl of mush and bread.

				PADM�
				(continuing)
			Are you hungry?

				ANAKIN
			Thank you.

				PADM�
			We went into lightspeed a while
			ago.

ANAKIN looks into PADME'S eyes.

				ANAKIN
			I look forward to seeing Naboo
			again. I've thought about it every
			day since I left. It's by far the
			most beautiful place I've ever
			seen...

PADME is a little unnerved by his intense stare. 

				PADM�
			You were just a little boy then.
			It may not be as you remember it;
			time changes your perception.

				ANAKIN
			I think time has given me much
			more mature feelings to enhance my
			perception.

				PADM�
			It must be difficult having sworn
			your life to the Jedi... not being
			able to visit the places you
			like... or do the things you
			like...

				ANAKIN
			Or be with the people I love.

				PADM�
			Are you allowed to love? I
			thought that was forbidden for a
			Jedi.

				ANAKIN
			Attachment is forbidden.
			Possession is forbidden.
			Compassion, which I would define
			as unconditional love, is central
			to a Jedi's life, so you might say
			we're encouraged to love.

				PADM�
			You have changed so much

				ANAKIN
			You haven't changed a bit. You're
			exactly the way I remember you in
			my dreams. I doubt if Naboo has
			changed much either.

				PADM�
			It hasn't...

				ANAKIN
			I can't wait to breathe the sweet
			breeze that comes off the rolling
			hills. Whenever I try to
			visualise the Force, those hills
			are what I see.

ANAKIN looks at PADME when he says this.

				ANAKIN
				(continuing)
			I love Naboo.

There is an awkward moment.

				PADM�
				(changing the subject)
			Were you dreaming about you
			mother earlier, weren't you?

				ANAKIN
			Yes... I left Tatooine so long
			ago, my memory of her is fading.
			I don't want to lose it. Recently
			I've been seeing her in my
			dreams... vivid dreams... scary
			dreams. I worry about her.

PADME gives ANAKIN a sympathetic look.

EXT. CORUSCANT, DOWNTOWN, BACK STREET - MORNING
OBI-WAN walks down the street. It is a pretty tough part of town. Old buildings, warehouses, beat up speeders and transporter rigs occasional "shiny freighters" hissing through.

OBI-WAN comes to a kind of alien diner. On the steamed-up windowa it says "DEX'S DINER" in alien lettering. He goes inside.

INT. CORUSCANT, DEX'S DINER - MORNING
A young waitress, HERMIONE BAGWA, is wiping off a booth tabletop. There is a counter with stools and a line of booths along the wall by the window. A number of CUSTOMERS are eating - TOUGH-LOOKING WORKERS, FREIGHTER DRIVERS etc. HERMIONE looks up as OBI-WAN comes in.

				HERMIONE
			Can I help ya?

				OBI-WAN
			I'm looking for Dexter.

HERMIONE'S eyes narrow.

				HERMIONE BAGWA
			Waddya want him for?

				OBI-WAN
			He's not in trouble. It's
			personal.

HERMIONE stares at OBI-WAN. There is a brief pause. Then she goes to the open serving hatch behind the counter.

				HERMIONE BAGWA
			Someone to see ya, honey
				(lowering her voice)
			A Jedi, by the looks of him.

Steam billows out from the kitchen hatch behind the counter as a huge head pokes through.

				DEXTER JETTSTER
			Obi-Wan!

				OBI-WAN
			Hey, Dex.

				DEXTER JETTSTER
			Take a seat! Be right with ya!

OBI-WAN sits in a booth.

				HERMIONE BAGWA
			You want a cup of ardees?

				OBI-WAN
			Thank you.

HERMIONE moves off as the door to the counter opens and DEXTER JETTSTER appears. He is big - bald and sweaty, old and alien. Not someone to tangle with. He arrives, beaming hugely.

				DEXTER JETTSTER
			Hey, ol' buddy!

				OBI-WAN
			Hey, Dex.

DEXTER eases himself into the seat opposite OBI-WAN. He can just make it. HERMIONE sets two mugs of steaming ardees in from of them.

				DEXTER JETTSTER
			So, my friend. What can I do for
			ya?

				OBI-WAN
			You can tell me what this is.

OBI-WAN places the dart on the table between them. DEX'S eyes widen. He puts down his mug.

				DEXTER JETTSTER
			Well, whattaya know...

DEXTER picks up the dart delicately between his puffy fingers and peers at it.

				DEXTER JETTSTER
				(continuing)
			I ain't seen one of these since I
			was prospecting on Subterrel
			beyond the Outer Rim!

				OBI-WAN
			Do you know where it came from?

DEXTER grins. He puts the dart down between them.

				DEXTER JETTSTER
			This baby belongs to them cloners.
			What you got here is a Kamino
			Kyberdart.

				OBI-WAN
			Kamino Kyberdart... I wonder why
			it didn't show up in any analysis
			archive.

				DEXTER JETTSTER
			It's these funny little cuts on
			the side give it away...
			Those analysis droids you've got
			over there only focus on symbols,
			you know. I should think you Jedi
			would have more respect for the
			difference between knowledge and
			wisdom.

				OBI-WAN
			Well, Dex, if droids could think, we
			wouldn't be here, would we?
				(laughing)
			Kamino... doesn't sound familiar.
			Is it part of the Republic?

				DEXTER JETTSTER
			No, it's beyond the Outer Rim.
			I'd say about twelve parsecs
			outside the Rishi Maze, toward the
			south. It should be easy to find,
			even for those droids in your
			archive to find. Those Kaminoans
			keep to themselves. They're
			cloners. Damned good ones, too.

OBI-WAN then picks up the dart, holding it midway between them.

				OBI-WAN
			Cloners? Are they friendly?

				DEXTER JETTSTER
			It depends.

				OBI-WAN
			On what, Dex?

Dexter grins. 

				DEXTER JETTSTER
			On how good your manners are...
			and how big your pocketbook is...

EXT. NABOO SPACEPORT - DAY
The Starfreighter lands in the giant port city of Theed.

PADME, ANAKIN and ARTOO are among the EMIGRANTS streaming from the Starfreighter and into the vast docking area. They exit onto the main plaza.

EXT. NABOO PALACE, GRAND COURTYARD (NABOO) - AFTERNOON
The speeder bus pulls up and stops. PADME, ANAKIN, and ARTOO get out. The great courtyard stretches out before them, and they see the rose-colored dome of the palace on the far side. ARTOO WHISTLES. They pick up their gear and start to cross the courtyard. ARTOO trundles behind them.

				ANAKIN
			If I grew up here, I don't think
			I'd ever leave.

				PADM�
				(laughing)
			I doubt that.

				ANAKIN
			No, really. When I started my
			training, I was very homesick and
			very lonely. This city and my Mom
			were the only pleasant things I
			had to think about... The problem
			was, the more I thought about my
			Mom, the worse I felt. But I
			would feel better if I thought
			about the palace - the way it
			shimmers in the sunlight - the way
			the air always smells of flowers...

				PADM�
			...and the soft sound of the
			distant waterfalls. The first
			time I saw the Capital, I was very
			young... I'd never seen a
			waterfall before. I though they
			were so beautiful... I never
			dreamed one day I'd live in the
			palace.

				ANAKIN
			Well, tell me, did you dream of
			power and politics when you were
			a little girl?

				PADM�
				(laughing)
			No! That was the last thing I
			thought of. My dream was to help
			in the "Refugee Relief Movement."
			I never thought of running for
			elected office. But the more
			history I studied, the more I
			realised how much good politicians
			could do. So when I was eight, I
			joined the "Apprentice
			Legislators", then later on became
			a Senatorial advisor, with such a
			passion that, before I knew it, I
			was elected Queen. Partly because
			I scored so high on my education
			certificate, but for the most part
			it was my conviction that reform
			was possible. I wasn't the
			youngest Queen ever elected, but
			now that I think back on it, I'm
			not sure I was old enough. I'm not
			sure I was ready.

				ANAKIN
			The people you served thought you
			did a good job. I heard they
			tried to amend the Constitution so
			you could stay in office.

				PADM�
			Popular rule is not democracy,
			Annie. It gives the people what
			they want, not what they need.
			And, truthfully, I was relieved
			when my two terms were up. So
			were my parents. They worried
			About me during the blockade and
			couldn't wait for it all to be
			over. Actually, I was hoping to
			have a family by now... My
			sisters have the most amazing,
			wonderful kids... but when the
			Queen asked me to serve as
			Senator, I couldn't refuse her.

				ANAKIN
			I agree! I think the Republic
			needs you... I'm glad you chose
			to serve. I feel things are going
			to happen in our generation that
			will change the galaxy in profound
			ways.

				PADM�
			I think so too.

ANAKIN and PADME walk toward the palace. ARTOO continues to follow.

INT. NABOO PALACE, THRONE ROOM - AFTERNOON
QUEN JAMILLIA is seated on the throne, flanked by SIO BIBBLE and a COUPLE OF ADVISORS. FOUR HANDMAIDENS stand close by, and GUARDS are at the doors.

				QUEEN JAMILLIA
			We've been worried about you.
				(takes her hand)
			I'm so glad you're safe, Padm�.

				PADM�
			Thank you, Your Highness. I only
			Wish I could have served you
			better by staying on Coruscant for
			the vote.

				SIO BIBBLE
			Given the circumstances, Senator,
			you know it was the only decision
			Her Highness could have made.

				QUEEN JAMILLIA
			How many systems have joined Count
			Dooku and the separatists?

				PADM�
			About two hundred. And more are
			leaving the Republic every day.
			If the Senate votes to create an
			army, I'm sure it's going to push
			us into a civil war.

				SIO BIBBLE
			It's unthinkable! There hasn't
			been a full-scale war since the
			formation of the Republic!

				QUEEN JAMILLIA
			Do you see any way, through
			negotiations, to bring the
			separatists back into the Republic?

				PADM�
			Not if they feel threatened. The
			separatists don't have an army,
			but if they are provoked, they
			will move to defend themselves.
			I'm sure of that. And with no time
			or money to build an army, my
			guess is they will turn to the
			Commerce Guilds or the Trade
			Federation for help.

				QUEEN JAMILLIA
			The armies of commerce! Why has
			Nothing been done in the Senate
			to restrain them?

				PADM�
			I'm afraid that, despite the
			Chancellor's best efforts, there
			are still many bureaucrats,
			judges, and even Senators on the
			payrolls of the Guilds.

				SIO BIBBLE
			It's outrageous! After all of
			those hearings, and the four trials in
			the Supreme Court, Nute Gunray is
			still the Viceroy of the Trade
			Federation. Do those money
			mongers control everything?

				QUEEN JAMILLIA
			Remember, Counsellor, the courts
			were able to reduce the
			Federation's armies. That's a
			move in the right
			direction.

				PADM�
			There are rumours, Your Highness,
			that the Federation Army was not
			reduced as they were ordered.

				ANAKIN
			The Jedi have not been allowed to
			investigate. It would be to be too
			dangerous for the economy, we were
			told.

				QUEEN JAMILLIA
			We must keep our faith in the
			Republic. The day we stop
			believing democracy can work is
			the day we lose it.

				PADM�
			Let's pray that day never comes.

				QUEEN JAMILLIA
			In the meantime, we must consider
			your own safety.

SIO BIBBLE signals. All the other ADVISORS and ATTENDANTS bow and leave the room.

				SIO BIBBLE
				(to Anakin)
			What is your suggestion, Master
			Jedi?

				PADM�
			Anakin's not a Jedi yet, Counsellor.
			He's still a Padawan learner. I
			was thinking...

				ANAKIN
				(nettled)
			Hey, hold on a minute!

				PADM�
			Excuse me! I was thinking I would
			stay in the Lake Country. There
			are some places up there that are
			very isolated.

				ANAKIN
			Excuse me?! I am in charge of
			security here, M'Lady.

SIO BIBBLE and QUEEN JAMILLIA exchange a look. Something is going on here.

				PADM�
			Annie, my life is at risk, and
			this is my home. I know it very
			well... that is why we're here.
			I think it would be wise for you
			to take advantage of my knowledge
			in this instance.

				ANAKIN
				(takes a deep breath)
			Sorry, M'Lady.

				SIO BIBBLE
				(to Anakin, amused)
			She is right. The Lake Country is
			the most remote part of Naboo.
			Not many people and a clear view
			of the surrounding terrain.

				QUEEN JAMILLIA
			Perfect. It's settled then.

ANAKIN glares at PADME. Then QUEEN JAMILLIA gets up, and they all start to leave.

				QUEEN JAMILLIA
				(continued)
			Padm�, I had an audience with your
			father yesterday. I told him what
			was happening. He hopes you will
			visit your mother before you
			leave... your family's very
			worried about you.

PADME looks worred. They ALL exit down the main staircase.

EXT. JEDI TEMPLE - DAY
The main entrance at the base of the huge temple is bustling with activity. All sorts of JEDI are coming and going.

INT. JEDI TEMPLE, ARCHIVES LIBRARY - DAY
A bronze bust of Count Dooku, stands among a line of other busts of Jedi in the Archive Room. OBI-WAN stands in front it, studying the striking features of the chiselled face.

On the walls, lighted computer panels seem to stretch into infinity. Farther along the room in the background, FIVE JEDI are seated at tables, studying archival material.

After OBI-WAN studies the bust for a few moments before MADAME JOCASTA NU, the Jedi Archivist is standing next to him. She is an elderly, frail-looking human Jedi. Tough as old boots and smart as a whip.

				JOCASTA NU
			Did you call for assistance?

				OBI-WAN
				(distracted in thought)
			Yes... yes, I did...

				JOCASTA NU
			He has a powerful face, doesn't
			he? He was one of the most
			brilliant Jedi I have had the
			privilege of knowing.

				OBI-WAN
			I never understood why he quit.
			Only twenty Jedi have ever left
			the Order.

				JOCASTA NU
				(sighs)
			The Lost Twenty... and Count Dooku
			was the most recent and the most
			painful. No one likes to talk
			about it. His leaving was a great
			loss to the Order.

				OBI-WAN
			What happened?

				JOCASTA NU
			Well, one might say, he was always
			a bit out of step with the
			decisions of the Council... much
			like your old Master, Qui-Gon Jinn.

				OBI-WAN
				(surprised)
			Really?

				JOCASTA NU
			Oh, yes. They were alike in many
			ways. Very individual thinkers...
			idealists...

JOCASTA NU stares at the bust

				JOCASTA NU
				(continuing
			He was always striving to become
			a more powerful Jedi. He wanted
			to be the best. With a lightsaber,
			in the old style of fencing, he
			had no match. His knowledge of
			the Force was... unique. In the
			end, I think he left because he
			lost faith in the Republic. He
			believed that politics were
			corrupt, and he felt the Jedi
			betrayed themselves by serving the
			politicians. He always had very
			high expectations of government.
			He disappeared for nine or ten
			years, then he just showed up
			recently as the head of the
			separatist movement.

				OBI-WAN
			Interesting... I'm still not sure
			I understand.

				JOCASTA NU
			Well, I'm sure you didn't call me
			over here for a history lesson.
			Are you having a problem, Master
			Kenobi?

				OBI-WAN
			Yes, I'm trying to find a planet
			system called Kamino. It doesn't
			seem to show upon any of the
			archive charts.

				JOCASTA NU
			Kamino? It's not a system I'M
			familiar with... Let me see...

JOCASTA NU leans over OBI-WAN'S shoulder, looking at the screen.

				JOCASTA NU
				(continuing)
			Are you sure you have the right
			co-ordinates?

				OBI-WAN
				(nodding)
			According to my information, it
			should be in this quadrant
			somewhere... just south of the
			Rishi Maze.

JOCASTA NU taps the keyboard and frowns.

				JOCASTA NU
			No co-ordinates? It sounds like the
			kind of directions you'd get from
			a street tout... some old miner or
			Furbog trader.

				OBI-WAN
			All three actually.

				JOCASTA NU
			Are you sure it exists?

				OBI-WAN
			Absolutely.

				JOCASTA NU
			Let me do a gravitational scan.

OBI-WAN and JOCASTA NU studt the star map hologram.

				JOCASTA NU
			There are some inconsistencies
			here. Maybe the planet you're
			looking for was destroyed.

				OBI-WAN
			Wouldn't that be on record?

				JOCASTA NU
			It ought to be. Unless it was very
			recent.
				(shakes her head)
			I hate to say it, but it looks
			like the system you're searching
			for doesn't exist.

				OBI-WAN
			That's impossible... perhaps the
			archives are incomplete.

				JOCASTA NU
			The archives are comprehensive and
			totally secure, my young Jedi.
			One thing you may be absolutely
			sure of - if an item does not
			appear in our records, it does not
			exist!

OBI-WAN stares at her, then looks back at the map.

EXT. THEED, RESIDENTIAL AREA, SIDE STREET - AFTERNOON
PEOPLE are passing through the little street, OLD MEN are sunning themslves, WOMEN are gossipping, KIDS are playing. ANAKIN, PADME and ARTOO turn onto a side street. ANAKIN is back in his Jedi robes. PADME wear a beautiful simple dress. She stops, beaming.

				PADME
			There's my house!

PADME starts forward; ANAKIN hangs back.

				PADME
				(continuing)
			What? Don't say you're shy!

				ANAKIN
				(untruthfully)
			No, but I...

Suddenly, there are shouts from two little girils, RYOO (age 6) and POOJA (age 4). They come running toward PADME.

				RYOO & POOJA
			Aunt Padme!! Aunt Padme!!

				PADME
			Ryoo!! Pooja!!

PADME scoops up RYOO and POOJA and hugs them.

				PADME
				(continuing)
			I'm so happy to see you! This is
			Anakin. Anakin, this is Ryoo, and
			this is Pooja.

ANAKIN and the GIRLS say hello shyly. Then:

				RYOO & POOJA
			Artoo!!!

As they see the droid, they hug him. ARTOO WHISTLES and BEEPS. PADME laughs. ANAKIN and PADME go on toward the house. The GIRLS stay and play with ARTOO.

INT. PADME'S PARENTS' HOUSE, MAIN ROOM - AFTERNOON
SOLA, PADME'S beautiful older sister, comes in from the kitchen carrying a big bowl of food.

				SOLA
				(over her shoulder)
			They're eating over at Jev
			Narran's later, Mom. They just
			had a snack. They'll be fine.

SOLA puts the bowl down on the table, where ANAKIN, PADME and RUWEE NABERRIE (Padme's father) are coming into the room.

				PADME
			Anakin, this is my sister, Sola.

				SOLA
			Hello, Anakin.

				ANAKIN
			Hello.

SOLA sits, as JOBAL NABERRIE (Padme's mother) comes in with a heaped bowl of steaming food.

				JOBAL
			You're just in time for dinner. I
			hope you're hungry, Anakin.

				ANAKIN
			A little.

				PADME
			He's being polite, Mom. We're
			starving.

				RUWEE
				(grinning)
			You came to the right place at the
			right time. Sit down, son.

EVERYONE sits and starts passing food.

				JOBAL
				(to Padme)
			Honey, it's so good to see you
			safe. We were so worried.

PADME gives JOBAL a dirty look. RUWEE smiles as he watches.

				RUWEE
			Dear...

				JOBAL
			I know, I know... but I had to say
			it. Now it's done.

				SOLA
			Well, this is exciting! Do you
			know, Anakin, you're the first
			boyfriend my sister's ever brought
			home?

				PADME
				(rolls her eyes)
			Sola!! He isn't my boyfriend!
			He's a Jedi assigned by the Senate
			to protect me.

				JOVAL
			A bodyguard?! Oh, Padme! They
			didn't tell us it was that serious!

				PADME
			It's not, Mom, I promise.
				(glances at Jobal)
			Anyway, Anakin's a friend. I've
			known him for years. Remember
			that little boy who was with the
			Jedi during the blockade crisis?

They nod.

				PADME
				(continuing)
			He grew up.

				JOBAL
			Honey, when are you going to
			settle down? Haven't you had
			enough of that life? I certainly
			have!

				PADME
			Mom, I'm not in any danger.

				RUWEE
				(to Anakin)
			Is she?

				ANAKIN
			...Yes... I'm afraid she is.

				PADME
				(quickly)
			But not much.

EXT. PADME'S PARENTS' GARDEN - AFTERNOON
ANAKIN and RUWEE are walking.

				RUWEE
			Sometimes I wish I'd traveled
			more... but I must say, I'm happy
			here.

				ANAKIN
			Padme tells me you teach at the
			university?

				RUWEE
				(nodding)
			Yes, and before that, I was a
			builder. I also worked for the
			Refugee Relief Movement, when I
			was very young.

INT. PADME'S PARENTS' HOUSE, MAIN ROOM - AFTERNOON
PADME, SOLA and JOBAL are clearing the table.

				SOLA
			Why haven't you told us about him?

				PADM�
			What's there to talk about?  He's
			just a boy.

				SOLA
			A boy? Have you seen the way he
			looks at you?

				PADM�
			Sola - stop it!

				SOLA
			It's obvious he has feelings for
			you. Are you saying, little baby
			sister, that you haven't noticed?

				PADM�
			I'm not your baby sister, Sola.
			Anakin and I are friends... our
			relationship is strictly
			professional.
				(to Jobal)
			Mom, would you tell her to stop it?

				SOLA
				(laughing)
			Well, maybe you haven't noticed
			the way he looks at you. I think
			you're afraid to.

				PADM�
			Cut it out.

				JOBAL
			Sola's just concerned... we all
			are.

				PADM�
			Oh, Mom, you're impossible. What
			I'm doing is important.

				JOBAL
			You've done your service, Padm�.
			It's time you had a life of your
			own. You're missing so much!

EXT. PADME'S PARENTS' GARDEN - AFTERNOON
ANAKIN and RUWEE are walking in the garden. RUWEE stops and faces ANAKIN directly.

				RUWEE
			Now tell me, son. How serious is
			this thing? How much danger is my
			daughter really in?

				ANAKIN
			There have been two attempts on
			her life. Chances are there'll be
			more. My Master is tracking down
			the assassins. I'm sure he'll find
			out who they are. This situation,
			won't last long.

				RUWEE
			I don't want anything to happen to
			her.

				ANAKIN
			I don't either.

INT. PADME'S PARENTS' HOUSE, PADME'S ROOM - AFTERNOON
PADME throws some things into a bag.

				PADME
			Don't worry, this won't take long.

				ANAKIN
			I just want to get there before
			dark.

PADME goes on packing. ANAKIN looks around the room.

				ANAKIN
				(continuing)
			You still live at home.

				PADME
			I move around so much, I've never
			had a place of my own. Official
			residences have no warmth. I feel
			good here. I feel at home.

				ANAKIN
			I never had a real home. Home was
			always where my Mom was.

ANAKIN picks up a framed hologram.

				ANAKIN
				(continuing)
			Is this you?

The hologram shows Padme at age seven or eight surrounded by forty or fifty little green creatures. She is holding one in her arms. They are all smiling hugely.

				PADME
			That was when I went with the
			Relief Group to Shadda-Bi-Boran.
			Their sun was imploding, and the
			planet was dying. I was helping
			to relocate the children. See
			that little one I'm holding? His
			name was N'a-kee-tula, which means
			sweethear. He was so full of 
			life,. All those kids were. I did
			everything I could to save him,
			but he died... they all did. They
			were never able to adapt... to
			live off their native planet.

ANAKIN picks up another hologram. It shows PADME at age ten or eleven. She is wearing official robes and standing between two robed legislators. Her expression is severe.

				PADME
				(continuing)
			My first day as an Apprentice
			Legislator. Notice the difference?

PADME pulls a face. ANAKIN grins. She continues packing. ANAKIN sets the two holograms down side by side - the beaming little girl, and the the stern, unsmiling adolescent.

INT. JEDI TEMPLE, MAIN HALLWAY - DAY
OBI-WAN walks through the main hallway to the training area.

INT. JEDI TEMPLE, TRAINING VERANDA - DAY
OBI-WAN comes out onto the veranda and stops, watching TWENTY or so FOUR-YEAR-OLDS doing training exercises, supervised by YODA. They wear helmets over their eyes and try to strike little TRAINING DROIDS with their miniature lightsabers. The DROIDS dance in front of them.

				YODA
			Don't think... feel... be as one
			with the Force. Help you, it will.
				(he sees Obi-Wan)
			Younglings - enough! A visitor we
			have. Welcome him.

The CHILDREN take off their helmets and turn off their lightsabers.

				YODA
				(continuing)
			Master Obi-Wan Kenobi, meet the
			mighty Bear Clan.

				CHILDREN
			Welcome, Master Obi-Wan!

				OBI-WAN
			I am sorry to disturb you, Master.

				YODA
			What help to you, can I be?

				OBI-WAN
			I�m looking for a planet described
			to me by an old friend. I trust
			him. But the system doesn�t show
			up on the archive maps.

				YODA
			An interesting puzzle. Gather
			round the map reader, younglings.
			Master Obi-Wan has lost a planet.
			Find it, we will try...

The map reader is a small shaft with a hollow opening at the top. The CCHILDREN gather around it. OBI-WAN takes out a little glass ball and places it into the bowl. The window shades close darkening the room and the reader lights up, projecting the star map hologram into the room. The CHILDREN laugh. Some of them reach up to try and touch the nebulae and stars. OBI-WAN walks into the display.

				OBI-WAN
			This is where it ought to be...
			but it isn�t. Gravity is pulling
			all the stars in this area inward
			to this spot. There should be a
			star here... but there isn�t.

				YODA
			Most interesting. Gravity�s
			silhouette remains, but the star
			and all its planets have
			disappeared. How can this be?

There is a brief pause. Then a CHILD puts its hand up. YODA nods.

				JEDI CHILD JACK
			Because someone erased it from the
			archive memory.

				CHILDREN
			That�s right! Yes! That�s what
			happened! Someone erased it!

				JEDI CHILD MAY
			If the planet blew up, the gravity
			would go away.

OBI-WAN stares; YODA chuckles.

				YODA
			Truly wonderful, the mind of a
			child is. Uncluttered. To the
			centre of the pull of gravity go,
			and find your planet you will.

				OBI-WAN
			But Master Yoda who could have
			erased information from the
			archives? That�s impossible,
			isn�t it?

				YODA
				(frowning)
			Much harder to answer, that
			question is.

EXT. NABOO LAKE RETREAT, WATER SPEEDER, LANDING PLATFORM - LATE AFTERNOON
A water speeder driven by PADDY ACCU, the retreat caretaker, skims across the lake away from the island landing platform where a chrome Naboo Starship rests. ANAKIN and PADME are sitting in the speeder as it skims away to where a lodge rises on a beautiful island in the middle of the lake.

EXT. NABOO LAKE RETREAT, LODGE, GARDEN TERRACEM LATE AFTERNOON
ANAKIN and PADME walk up the stairs from where the water speeder is parked onto a terrace overlooking a lovely garden. Behind them, PADDY ACCU supervises two serving girls, NANDI and TECKLA, as they carry the bags into the Lodge.

ANAKIN and PADME stop at the balustrade. PADME looks out across the garden to the shimmering lake and the mountains rising beyond. ANAKIN looks at her silently.

				PADM�
			When I was in Level Three, we used
			to come here for school retreat.
			See that island? We used to swim
			there every day. I love the water.

				ANAKIN
			I do too. I guess it comes from
			growing up on a desert planet.

PADME becomes aware that ANAKIN is looking at her.

				PADM�
			...We used to lie on the sand and
			let the sun dry us... and try to
			guess the names of the birds
			singing.

				ANAKIN
			I don�t like sand. It�s coarse
			and rough and irritating, and it
			gets everywhere. Not like here.
			Here everything�s soft... and
			smooth...

He touches her arm. PADME has become receptive to the way he looks at her but is nervous.

				PADM�
			There was a very old man who lived
			on the island. He used to make
			glass out of sand - and vases and
			necklaces out of the glass. They
			were magical.

				ANAKIN
				(looks into her eyes)
			Everything here is magical.

				PADM�
			You could look into the glass and
			see the water. The way it ripples
			and moves. It looked so real...
			but it wasn�t.

				ANAKIN
			Sometimes, when you believe
			something to be real, it becomes
			real. Real enough, anyway...

They look into each other's eyes. He touches her chin.

				PADM�
			I used to think if you looked too
			deeply into glass, you would
			lose yourself.

				ANAKIN
			I think it's true...

ANAKIN kisses PADME. She doesn't resist. She comes to her senses and pulls away.

				PADM�
			I shouldn't have done that.

				ANAKIN
			I'm sorry. When I'm around you,
			my mind is no longer my own.

				PADM�
			It's the situation... the stress...

He looks at her.

				ANAKIN
			...the view.

EXT. CORUSCANT, LANDING PLATFORM - LATE AFTERNOON
Obi-Wan's Starfighter is ready for takeoff. OBI-WAN and MACE WINDU stand beside it.

				MACE WINDU
			Be wary, this disturbance in the
			Force is growing stronger.

				OBI-WAN
			I am concerned for my Padawan. He
			is not ready to be on his own.

				YODA
			The Council is confident in this decision,
			Obi-Wan.

				MACE
			He has exceptional skills. The
			Council is confident in its
			decision, Obi-Wan. If the
			prophecy is true, he weill be the
			one to bring balance to the Force.

				OBI-WAN
			But he still has much to learn.
			And his abilities have made him...
			well... arrogant. I realise now
			what you and Master Yoda knew from
			the beginning... the boy was too
			old to start the training and...

OBI-WAN hesitates.

				MACE WINDU
			There's something else?

				OBI-WAN
			Master, he should not have been
			given this assignment. I'm afraid
			Anakin won't be able to protect
			the Senator. 

				MACE WINDU
			Why?

				OBI-WAN
			He has a... an emotional
			connection with her. It's been
			there since he was boy. Now
			he's confused... distracted.

				MACE-WINDU
			Obi-Wan, you must have faith that
			he will take the right path.

OBI-WAN climbs into the cockpit of the Starfighter.

				OBI-WAN
			Has Master Yoda gained any insight
			into whether or not this war will
			come about?

				MACE WINDU
			Probing the Dark Side is a
			dangerous process. He could be in
			seclusion for days... May the
			force be with you.

INT. JEDI TEMPLE, YODA'S QUARTERS - LATE AFTERNOON
YODA sits with his eyes closed, meditating. Silence.

EXT. NABOO LAKE RETREAT, LOUNGE, LATE AFTERNOON
The setting sun touches the mountain peaks. The lake glows in the rose-tinted light. Floatinf lamps glean softly like jewels at the lodge.

INT. NABOO LAKE RETREAT, DINING ROOM - LATE AFTERNOON
NANDI place dessert in front of PADME. TECKLA does the same for ANAKIN. The dessert is some kind of fruit. PADME picks up her fork and goes to spear a piece, but it moves! She frowns and tries again -the fruit moves. She lokk up at ANAKIN. His eyes are on his plate.

				PADME
			You did that?

ANAKIN looks up - wide-eyed innocence.

				ANAKIN
			What?

PADME scowls at him. PADME jabs at the fruit - ANAKIN subtly moves his hand and it lifts up from the plate and hovers in front of her.

				PADME
			That! Now stop it!

PADME laughs. ANAKIN laughs. She reaches out for the fruit - it loops.

				PADME
				(continuing)
			Anakin!!

ANAKIN moves his fingers. The fruit flies into his hand.

				ANAKIN
			I'm not really supposed to do
			that... for fun, I mean. If
			Master Obi-Wan were here, he'd be
			very grumpy.

ANAKIN is pleased. He cuts the fruint into several pieces and sends one back to PADME. She bites it out of the air and laughs.

INT. NABOO LAKE RETREAT, LODGE, FIREPLACE ALCOVE - TWILIGHT
A fire blazes in the open hearth. PADME is sitting in front of it, gazing at the flames.

She looks up as ANAKIN arrives. She makes room for him. Brief pause.

				ANAKIN
			May I tell you something?

				PADME
			I don't know.

				ANAKIN
			Then how can I tell you?

				PADME
			Maybe you should use your Jedi
			intuition.

				ANAKIN
			It doesn't work around you. My
			mind is always a muddle... I can
			only think of you.

				PADME
			Anakin, don't...

				ANAKIN
			From the moment I met you, all
			those years ago, a day hasn't gone
			by when I haven't thought of you.
			And now that I'm close to you again,
			I'm in agony. The closer I get to
			you, the worse it gets. The
			thought of not being with you
			mskes my stomach turn over - my
			mouth goes dry. I feel dizzy. I
			can't breathe. I'm haunted by the
			kiss you should never have given
			me. My heart is beating, hoping
			that kiss will not become a scar.
			You are in my very soul,
			tormenting me. What can I do? I
			will do anything you ask...

Silence. The logs flame in the hearth.

				ANAKIN
				(continuing)
			If you are suffering as much as I
			am, tell me.

				PADME
			...I can't. We can't. It's just
			not possible.

				ANAKIN
			Anything's possible. Padme,
			please listen...

				PADME
			You listen. We live in a real
			world. Come back to it. You're
			studying to become a Jedi Knight.
			I'm a Senator. If you follow your
			thoughts through to conclusion,
			they will take us to a place we
			cannot go... regardless of the way
			we feel about each other.

				ANAKIN
			Then you do feel something!
			There's an extraordinary
			connection between us. You can't
			deny that.

				PADME
			Annie, it doesn't make any
			difference. Jedi aren't allowed
			to marry. You swore an oath,
			remember? You'd be expelled from
			the Order. I will not let you
			give up your responsibilities...
			your future, for me.

				ANAKIN
			I was destined to be a Jedi. I
			don't think I could be anything
			else. But you are asking me to be
			rational. That is something I
			know I cannot do. I wish I could
			wish my feelings away... but I
			can't.

				PADME
			I am not going to give into this.
			I'm not going to throw my life
			away. I have more important things
			to do than fall in love.

There is silence as they stare at the fire. ANAKIN is thinking.

				ANAKIN
			It wouldn't have to be that way...
			we could keep it a secret.

				PADME
			Then we'd be living a lie - one we
			couldn't keep even if we wanted
			to. Mt sister saw it. So did my
			mother. I couldn't do that.
			Could you, Anakin? Could you live
			like that?

Silence for a moment.

				ANAKIN
			...No, you're right. It would
			destroy us.

EXT. SPACE
It's just like the star map hologram, plus the storm-shrouded planet of Kamino, which is exactly where it ought to be. Obi-Wan's Starship flies OVER CAMERA and heads down toward the planet.

EXT. TIPOCA CITY, KAMINO LANDING PLATFORM (RAINSTORM) - DAY
Heavy rans and hard-driving winds lash the platform as Obi-Wan's Starship approaches. The huge, ultra-modern city of Tipoca rests on great stilts that keep it above the pounding and ever-present waves that cover the surface of this watery world.

The Starfighter lands. OBI-WAN gets out and makes his way through the bowling wind toward a tower on the far side of the platform. A door slides open. A shaft of brilliant light pierces the swirling rain. OBI-WAN passes through it and goes inside.

INT. TIPOCA CITY, CORRIDOR ENTRANCE
A Brilliant white light. OBI-WAN pushes the soaking hood from his face.

				TAUN WE
			Welcome to Tipoca City, Master
			Jedi.

OBI-WAN wipes the rain from his face and blinks in surprise at a tall, pasty-white alien named TAUN WE. He has large, almond shaped eyes.

				TAUN WE
			Everything is ready. The Prime
			Minister expects you.

				OBI-WAN
				(warily)
			I'm expected?

				TAUN WE
			Of course! He is anxious to see
			you. After all these years, we
			were beginning to think you
			weren't coming. Now please, this
			way!

OBI-WAN masks his surprise as they move away along the corridor.

Obi-Wan follows Taun We cautiously.

INT. TIPOCA CITY, PRIME MINISTER OFFICE - DAY
The door slides open. OBI-WAN and TAUN WE enter and cross to where LAMA SU rises, smiling, from behind his desk, which, like all the furniture on Kamino, seems made out of pure light.

				TAUN WE
			May I present Lama Su, Prime
			Minister of Kamino... and this is
			Master Jedi...

				OBI-WAN
			Obi-Wan Kenobi.

				LAMA SU
			Please...

LAMA SU indicates a chair. OBI-WAN sits. TAUN WE hovers. The room is bathed in brilliant white light. The whole place is ultra high-tech.

				LAMA SU
			I trust you are going to enjoy
			your stay. We are most happy you
			have arrived at the best part of
			the season.

				OBI-WAN
			You make me feel most welcome.

				LAMA SU
			And now to business. You will be
			delighted to hear we are on
			schedule. Two hundred thousand
			units are ready, with another
			million well on the way.

				OBI-WAN
				(improvising)
			That is... good news.

				LAMA SU
			Please tell your Master Sido-Dyas
			that we have every confidence his
			order will be met on time and in
			full. He is well, I hope?

				OBI-WAN
			I'm sorry Master - ?

				LAMA SU
			Jedi Master Sifo-Dyas. He's still
			a leading member of the Jedi
			Council, is he not?

				OBI-WAN
			Oh, yes. Sido-Dyas.

				LAMA SU
				(rising)
			You must be anxious to inspect the
			units for yourself.

				OBI-WAN
			That's why I'm here.

EXT. NABOO, MOUNTAIN MEADOW - LATER AFTERNOON
PADME and ANAKIN are in the middle of an idyllic hilly meadow, its lush grasses sprinkled with flowers. At a distance, a herd of SHAAKS graze contentedly.

Beyond is the shimmering expanse of the lake. Several other lakes stretch to the horizon. The warm air is full of little floating puffballs. They sit on the grass, in a playful, coy mood, talking. PADME is picking flowers.

				PADM�
			I don't know...

				ANAKIN
			Sure you do... you just don't want
			to tell me.

				PADM�
			Are you going to use one of your
			Jedi mind tricks on me?

				ANAKIN
			They only work on the weak-minded.
			You are anything but weak-minded.

				PADM�
			All right... his name was Palo.
			I was twelve. We were both in the
			Legislative Youth Program. He was
			a few years older then I... very
			cute... dark curly hair... dreamy
			eyes.

				ANAKIN
			All right, I get the picture...
			whatever happened to him?

				PADM�
			I went on to become a Queen. He
			went on to become an artist.

				ANAKIN
			Maybe he was the smart one.

				PADME
			You really don't like politicians,
			do you?

				ANAKIN
			I like two or three, but I'm not
			really sure about one of them.
				(smiling)
			I don't think the system works.

				PADME
			How would you have it work?

				ANAKIN
			We need a system where the
			politicians sit down and discuss
			the problems, agree what's in the
			best interests of all the people,
			and then do it.

				PADME
			That is exactly what we do. The
			trouble is that people don't
			wlways agree. In fact, they
			hardly ever do.

				ANAKIN
			Then they should be made to.

				PADME
			By whom? Who's going to make them?

				ANAKIN
			I don't know. Someone.

				PADME
			You?

				ANAKIN
			Of course not me.

				PADME
			But someone.

				ANAKIN
			Someone wise.

				PADME
			That sounds an awful lot like a
			dictatorship to me.

A mischievious little grin creeps across his face.

				ANAKIN
			Well, if it works...

PADME stares at ANAKIN. He looks back at her, straight-faced, and can't hold a smile.

				PADM�
			You're making fun of me.

				ANAKIN
			 	(sarcastic)
			On no, I'd be much too frightened
			to tease a Senator.

				PADM�
			You're so bad!

PADME picks up a piece of fruit and throws it at him. He catches it. PADME throws two more pieces of fruit, and ANAKIN catches them.

				ANAKIN
			You're always so serious. Always
			carrying the weight of the
			universe on your shoulders.

ANAKIN then starts to juggle the fruit. PADME laughs and throws more fruit at him. He manages to juggle them too until there are too many, and he loses control and ducks, letting food fall on his head. They both laugh.

ANAKIN stands in front of a SHAAK, yelling at it and waving his arms. PADME starts laughing as ANAKIN runs in circles, chased by the SHAAK.

The SHAAK crosses in front of PADME. ANAKIN is riding it, facing the SHAAK'S tail. The SHAAK bucks, and ANAKIN falls off. PADME laughs even harder. ANAKIN lies still. PADME jumps uip and runs to where ANAKIN is face down in the grass. She turns him over. He is pulling a stupid face at her. She yelps in mock fury and takes a swing at him. He catches her arm. She struggles. They roll over in the grass. Suddenly, they become aware of the contact between them. They let go of each other quickly and sit up, looking away.

ANAKIN stands up and holds out his hand to her. She take it. He pulls her up. And now they are easy together, not self-conscious any more. PADME scrambles up onto the SHAAK behind ANAKIN. She puts her arms around his waist and leans against his back. ABAJUB digs his heels in. The SHAAK starts forward, and they ride away.

EXT. TIPOCA CITY, PARADE GROUND (RAINSTORM) - DAY
OBI-WAN, LAMA SU and TAUN WE come out onto a balcony. Below is a huge parade ground. The rain and wind are brutal. THOUSANDS OF STORMTROOPERS, faces covered by helmets, are marching and drilling in formations of several hundred.

				LAMA SU
				(beaming)
			Magnificent, aren't they?

OBI-WAN nods slowly.

INT. TIPOCA CITY, CLONE CENTER, COMMINSSARY - DAY
LAMA SU conducts OBI-WAN through a large eating area. TAUN WE follows as they walk by HUNDREDS OF CLONES who look exactly alike, all about twenty years old, dressed in black. They are seated at tables, eating.

				LAMA SU
			We modified their genetic
			structure to make them less
			independent than the original
			host. As a result they are
			totally obedient, taking any order
			without question.

				OBI-WAM
			Who was the original host?

				LAMA SU
			A bounty hunter called Jango Fett.
			We felt a Jedi would be the
			perfect choice, but Sido-Dyas hand-
			picked Jango Fett himself.

				OBI-WAN
			Where is this bounty hunter now?

				LAMA SU
			Oh, we keep him here. After a few
			hundred thousand clones, the
			genetic pattern starts to fade, so
			we take a fresh supply. He lives
			here, but he's free to come and go
			as he pleases.

INT. TIPOCA CITY, CLONE CENTER, BARRACKS - DAY
The tour continues through a long corridor folled with narrow, transparent tubes into which CLONES are climbing. Once in the tube, the CLONE goes to sleep.

				LAMA SU
			Apart from his pay, which is
			considerable, Fett demanded only
			one thing - an unaltered clone for
			himself. Curious isn't it?

				OBI-WAN
			Unaltered?

				LAMA SU
			Pure genetic replication. No
			tampering with the structure to
			make it more docile... and no
			growth acceleration...

				OBI-WAN
			I would like to meet this Jango
			Fett.

				TAUN WE
			I would be most happy to arrange
			it, for you.

TAUN WE bows, and leaves.

INT. TIPOCA CITY, CLONE CENTER, CLASSROOM - DAY
The tour continues through a classroom filled with IDENTICAL YOUNG BOY CLONES.

				OBI-WAN
			You mentioned growth
			acceleration...

				LAMA SU
			Oh yes, it's essential.
			Otherwise, a mature clone would
			take a lifetime to grow. Now, we
			can do it in half the time. Those
			items you saw on the parade ground
			were started ten years ago, when
			Sido-dyas first placed the order,
			and they're already mature...

OBI-WAN looks at the BOY CLONES.

				OBI-WAN
			And these?

				LAMA SU
			About five years ago.

INT. TIPOCA CITY, CLONE CENTER, HATCHERY - DAY
They enter a space filled with great racks of glass spheres, which are filled with fluid in which EMBRYOS are suspended.

				LAMA SU
			They're immensely superior to
			droids, capable of independent
			thought and action.

				OBI-WAN
			Very impressive.

				LAMA SU
			I'd hoped you would be pleased. 

OBI-WAN gazes at the nearest embryos.

				OBI-WAN
				(carefully)
			Tell me, prime minister, when my
			Master Sido-dyas first contacted
			you, did he say the order was
			for... himself... or?

				LAMA SU
			Himself? Of course not. This
			army is for the Republic?

				OBI-WAN
				(astonished)
			The Repubic?

				LAMA SU
			We are also very much agasint this
			Count Dooku and his seccessionist
			movement. We are proud to be of
			help to the Republic.

INT. TIPOCA CITY, APARTMENT - LATE DAY
TAUN WE shows OBI-WAN into his room.

				TAUN WE
			I have arranged for you to meet
			Jango Fett in the morning. Sleep
			well.

TAUN WE goes. The door slides closed behind him. OBI-WAN looks around, then moves swiftly to check the room over. Finally, satisfied, he takes out his comlink.

				OBI-WAN
			Arfour, Arfour...

EXT. TIPOCA CITY LANDING PLATFORM, JEDI FIGHTER, (RAINSTORM) - LATE DAY
The R4 D17, Obi-Wan's Astro-Droid, who is sitting on top of Obi-Wan's Starfighter, switches on and BEEPS.

INT. TIPOCA CITY, APARTMENT - LATE DAY
OBI-WAN hears ARFOUR BEEP through his comlink.

				OBI-WAN
			Arfour, relay this, "scramble code
			five," to Courscant: care of "the
			old folks home."

EXT. TIPOCA CITY LANDING PLATFORM, JEDI FIGHTER, (RAINSTORM) - LATE DAY
ARFOUR BEEPS and WHISTLES. The panels light up inside the cockpit, as the message is transmitted.

EXT. JEDI TEMPLE, LIVINF QUARTERS - EARLY EVENING
YODA and MACE WINDU listen as a hologram of OBI-WAN stands between them broadcasting the massage. The singnal is very weak, the image fades in and out.

				OBI-WAN (V.O.)
			...I've never heard of a Jedi
			called Sido-Dyas, have you, Master?

				MACE WINDU
			No. Whoever placed that order was
			not a Jedi, I can assure you.

				OBI-WAN (V.O.)
			I have a strong feeling that this
			bounty hunter is the assassin
			we're looking for.

				YODA
			Who he is working for... discover
			that, you must.

				OBI-WAN (V.O.)
			I will, Master, and I will also
			find out more about this clone
			army... May The Force...

The hologram switches off, and OBI-WAN fades away.

				WINDU 
			A clone army! Ordered by someone
			in the Senate perhaps... Someone's
			out to start a war.

				YODA
			Inform the chancellor of this, we
			must.

				WINDU
			Who do you think this impostor
			Sido-Dyas, could be?

YODA stares back at MACE WINDU, then slowly shakes his head.

EXT. NABOO LAKE RETREAT - NIGHT
The silent lodge. The triple moons of Naboo reflected in the tranquil waters of the lake.

INT. NABOO LAKE RETREAT, ANAKIN'S BEDROOM - NIGHT
ANAKIN moves restlessly in his sleep. He mutters to himself. Sweat 
forms on his forehead. He turns violently. He cries out.

				ANAKIN
			No...No...No...Mom!...Don't,
			no, don't!

EXT. NABOO LAKE RETREAT, LODGE, BALCONY OVERLOOKING GARDENS - MORNING
ANAKIN is on the balcony overlooking the gardens. After a moment, PAMDE comes onto the balcony behind him. She sees he is meditating and turns to go.

				ANAKIN
				(eyes closed)
			Don't go.

				PAMDE
			I don't want to disturb you.

				ANAKIN
			Your presence is soothing.

Brief pause.

				PADME
			You had a nightmare again last
			night.

				ANAKIN
			Jedi don't have nightmares.

				PADME
			I heard you.

ANAKIN'S opens his eyes and looks at her.

				ANAKIN
			I saw my mother. I saw her as
			clearly as I see you now. She's
			suffering, Padme. She is in
			pain...They're killing her!
				(getting up)
			I know I'm disobeying my mandate
			to protect you, Senator. I know I
			will be punished and possibly
			thrown out of the Jedi Order, but
			I must go. I have to help her!
			I'm sorry, Padme. I don't have a
			choice.

				PADME
			Annie, I told you I wouldn't let
			you give up your future for me.
			I'll go with you. That way you
			can continue to protect me, and
			you won't be disobeying your
			mandate.

				ANAKIN
			What about Master Obi-wan?

PADME smiles and takes his hand.

				PADME
			I guess we won't tell him, will we?

EXT. NABOO LAKE, FLOATING LANDING PLATFORM - DAY
ANAKIN and PADME step onto the landing platform from the water speeder. They enter the Naboo Starship. ARTOO BEEPS, and follows them on board. The ramp retracts.

PADDY ACCU drives the water speeder away from the platform as Anakin's Starship takes off.

EXT. TIPOCA CITY (RAINSTORM) - DAY
Rain lashes the city. Below, mightly waves pound the stilts, breaking almost to the height of the platforms.

INT. TIPOCA CITY, CORRIDOR - DAY
TAUN WE conducts OBI-WAN to the door of Jango Fett's apartment. TAUN WE waves his hand, and a muted bell RINGS.

As they wait, OBI-WAN notes the door lock entry mechanism. Then the door opens, and a ten-year-old boy, BOBA FETT, looks at them. He is identical to the boys in the classroom.

				TAUN WE
			Boba, is your father here?

There is a brief pause, then BOBA FETT nods.

				TAUN WE
				(continuing)
			May we see him?

				BOBA FETT
			Sure.

Another brief pause, then BOBA FETT steps aside, and TAUN WE and OBI-WAN go through.

INT. TIPOCA CITY, FETT APARTMENT - DAY
OBI-WAN, TAUN WE, and BOBA FETT enter the apartment. OBI-WAN looks around the room.

				BOBA FETT
			Dad! Taun We's here!

JANGO FETT comes in from the bedroom. He wears a jumpsuit. He is unshaven and mean looking, his face pitted with scars of old wounds. There are a couple of weird tattoos on his muscular forearms. He eyes OBI-WAN with suspicion.

				TAUN WE
			Welcome back, Jango. Was your
			trip productive?

				JANGO FETT
			Fairly.

OBI-WAN and JANGO FETT size each other up. BOBA FETT studies both of them.

				TAUN WE
			This is Jedi Master, Obi-Wan
			Kenobi. He's come to check on our
			progress.

				JANGO FETT
			That right?

JANGO FETT'S eyes fix OBI-WAN coldly.

				OBI-WAN
			Your clones are very impressive.
			You must be very proud.

				JANGO FETT
			I'm just a simple man, trying to
			make my way in the universe,
			Master Jedi.

				OBI-WAN
			Aren't we all?

OBI-WAN eyes the half-open bedroom door, through which a couple of pieces of body armour can be seen on the floor. JANGO FETT registers OBI-WAN'S look. He moves in front of him, blocking the view.

				OBI-WAN
				(continuing)
			Ever made your way as far into the
			interior as Coruscant?

				JANGO
			Once or twice.

				OBI-WAN
			Recently?

				JANGO
				(eyes Obi-Wan carefully)
			Possibly...

				OBI-WAN
			Then you must know Master Sido-
			Dyas?

				JANGO
			Boba, close the door.

BOBA FETT moves to close the bedroom door. JANGO FETT smiles thinly at OBI-WAN.

				JANGO
				(continuing)
			Master who?

				OBI-WAN
			Sido-Dyas. Isn�t he the Jedi who
			hired you for this job?

				JANGO
			Never heard of him. I was
			recuited by a man called Darth
			Tyranus on one of the moons of
			Bogden.

				OBI-WAN
			No? I thought...

				TAUN WE
			Sido-Dyas told us to expect him.
			And he showed up just when your
			Jedi Master said he would. We
			have kept the Jedi�s involvement
			a secret until your arrival, just
			as your Master requested.

				OBI-WAN
			Curious...

				JANGO
			Do you like your army?

				OBI-WAN
			It seems to me it's your army -
			being that they are all clones of
			you.

				JANGO
				(grinning)
			They'll do their job well, I'll
			guarantee that.

				OBI-WAN
			I look forward to seeing them in
			action. Thank you for your time,
			Jango.

				JANGO
			Always a pleasure to meet a Jedi.

OBI-WAN and TAUN WE go out. The door slides closed. JANGO FETT turns to his son. He is deep in thought.

				BOBA
			What is it, Dad?

EXT. SPACE
The Naboo Starship heads toward the desert planet of Tatooine.

EXT. TATOOINE, MOS ESPA STREETS AND WATTO'S SHIP - DAY
The Naboo Starship lands in a large parking lot of Spaceships on the outskirts of Mos Espa. ANAKIN and PADME ride a rickshaw through the streets. ANAKIN stares at sights he hasn't seen for years. Finally, they come  to Wattos' shop, and the rickshaw stops.

				ANAKIN
				(to the droid driver)
			Wait, please.

ANAKIN and PADME get down. Sitting on a stool in front of the shop is WATTO. He is using a small electronic screwdriver on a fiddly DROID. THREE PIT DROIDS are chattering away and are trying to help him, but they seem only to make him madder.

				WATTO
				(yelling, in Huttese)
			No, not that one - that one!

				ANAKIN
				(arriving)
			Excuse me, Watto.

				WATTO
				(in Huttese)
			What?

				ANAKIN
				(in Huttese)
			I said excuse me.

WATTO turns to the chattering PIT DROIDS.

				WATTO
				(in Huttese)
			Shut down.

The PIT DROIDS snap into their storage position.

				WATTO
				(continuing, in Huttese)
			What? I don't know you... What can
			I do for you? You look like a
			Jedi. Whatever it is... I didn't
			do it.

WATTO drops the screwdriver and curses loudly in Huttese

				ANAKIN
			Let me help you with that.

ANAKIN takes the fiddly piece of equipment and starts to play with it. WATTO blinks in surprise.

				ANAKIN
				(continuing)
			I'm looking for Shmi Skywalker.

WATTO looks at him suspiciously. He stares at PADME, then back to ANAKIN.

				WATTO
			Annie?? Little Annie?? Naaaah!!

Suddenly, the fiddly piece of equipment in Anakin's hands WHIRS into life. WATTO blinks at it.

				WATTO
				(continuing; in English)
			You are Annie! It is you! You
			little womp rat.

WATTO gives ANAKIN a big hug.

				WATTO
				(continuing)
			You sure sprouted Weehoo! A
			Jedi! Waddya know? Hey, maybe
			you couldda help wit some
			daedbeats who owe...

				ANAKIN
			My mother...

				WATTO
			Oh, yeah. Shmi... she's not mine
			no more. I sold her.

				ANAKIN
			Sold her...

				WATTO
			Years ago. Sorry, Anne, but you
			know, business is business.
			Sold her to a moisture farmer
			named Lars. Least I think it was
			Lars. Believe it or not, I heard
			he freed her and married her. Can
			ya beat that?

				ANAKIN
			Do you know where they are?

				WATTO
			Long way from here... someplace
			over on the other side of Mos
			Eisley, I think...

				ANAKIN
			I'd like to know.

ANAKIN'S grim look means business; WATTO gets the hint quickly.

				WATTO
			Yeah... sure... absolutely. Let's
			go look in my records.

ANAKIN and WATTO go into the shop.

EXT. TIPOCA CITY (RAINSTORM) - DAY
The waves crash against the water city as the storm continues. Light suddenlyt streams from the base of a landing platform as a door slides open.

INT. TIPOCA CITY, CORRIDOR - DAY
OBI-WAN stands with LAMA SU and TAUN WE just inside the open door.

				LAMA SU
			Tell your Council the first
			battalions are ready. And remind
			them that if they need more
			troops, we will need time to grow
			them.

				OBI-WAN
			I won't forget.

EXT. TIPOCA CITY, KAMINO LANDING PLATFORM (RAINSTORM) - DAY
OBI-WAN comes out from the tower into the driving ran. The door closes behind him. He pulls his robe around him and stands braced against the gale.

Below, a huge wave crashes against the stilts. Spray flies high and whips across the platform where OBI-WAN is standing. He walks over to his Starfighter, looks to see if anyone is watching, then turns and goes back to the door. It slides open.

INT. TIPOCA CITY, CORRIDOR - DAY
OBI-WAN enters cautiously from outside. Ahead, the corridor is deserted. He moves down it.

INT. TIPOCA CITY, FETT APARTMENT - DAY
OBI-WAN walks in to find the room in complete disorder. The bedroom door is wide open - clear signs of hurried departure. All of the Fetts' personal belongings are gone.

OBI-WAN goes to an ultra-thin computer screen. He punches up AN ONSCREEN PICTURE of JANGO FETT and BOBA FETT unhitching the lines securing their ship to the landing platform. JANGO FETT is wearing his armour and rocket pack. BOBA FETT climbs aboard the small Fighter.

EXT. TIPOCA CITY, KAMINO LANDING PLATFORM (RAINSTORM) - DAY
JANGO FETT picks up a case and swings it up to BOBA FETT, who stows it inside the ship. JANGO FETT picks up another case and is about to swing it, when:

				BOBA FETT
			Dad!!

JANGO FETT turns to see OBI-WAN charging out of the tower toward him. As he runs, OBI-WAN draws his lightsaber from his belt. It flashes on.

JANGO FETT draws his gun and fires at the charging JEDI. OBI-WAN deflects the blast and swings at JANGO FETT.

The bounty hunter rockets up and over OBI-WAN, landing behind him. He fires a thin wire from his wrist pack, trying to entangle the Jedi.

JANGO FETT fire several Kamino Kyber Darts from his elbow launcher. OBI-WAN deflects them back at JANGO FETT, but they strike harmlessly against the bounty hunter's armour.

IN THE COCKPIT of Jango Fett's ship, BOBA FETT grabs the controls of a laser gun and swings it to aim at OBI-WAN.

OUTSIDE, in the driving rain, OBI-WAN and JANGO FETT circle each other, sizing each other up - feinting.

IN THE COCKPIT, each time BOBA FETT is ready to fire, JANGO FETT blocks his view of OBI-WAN.

OUTSIDE, OBI-WAN makes a sudden attack, swinging at JANGO FETT, who deflects the blows. One slices off a piece of the bounty hunter's shoulder plate. JANGO FETT rockets into the air and hovers above OBI-WAN. The Jedi spins as:

IN THE COCKPIT, BOBA FETT fires.

OUTSIDE, the laser shell streaks past OBI-WAN to strike the edge of the tower. JANGO FETT fires down at OBI-WAN. The Jedi deflects the shots back, but JANGO FETT evades them. Then he swoops down, swinging around OBI-WAN. As he shoots past, he kicks the lightsaber out of the Jedi's hand.

The lightsaber skids across the wet surface of the landing platform. OBI-WAN dives after it. JANGO FETT zooms in front of him and grabs the lightsaber. OBI-WAN punches it out of his hand.

IN THE COCKPIT, BOBA FETT watches as:

OUTSIDE, OBI-WAN and JANGO FETT grapple and fight, punching, kicking, grabbing hold, and throwing each other around. OBI-WAN grabs JANGO FETT tightly, and JANGO FETT rockets up into the air and kicks OBI-WAN loose. OBI-WAN crashes to the deck and slides toward the edge. He grapples desperately for a handhold on the slick surface.

JANGO FETT rockets down to kick at him. OBI-WAN hauls himself up. JANGO FETT zooms to the far side of the platform.

OBI-WAN uses Jedi powers to pull part of the structure loose. It hits JANGO FETT, who loses his balance, teetering on the edge. OBI-WAN charges acress, dives, and grabs hold of JANGO FETT just as he falls over the edge.

Locked together, OBI-WAN and JANGO FETT plummet down toward the raging ocean. At the last moment, JANGO FETT fires a cable out of his backpack that shoots upward and locks onto a metal strut on the underside of the platform. OBI-WAN and JANGO FETT swing and CRASH onto one of the stilts.

OBI-WAN is knocked clear and drops onto a SMALL SERVICE PLATFORM just above the waves. He hauls himself to his feet. JANGO FETT hovers in mid-air opposite him, as a HUGE WAVE crashes over OBI-WAN. When it subsides, the Jedi has disappeared.

JANGO FETT rockets up to the landing platform, where he drops down beside his ship. He clambers inside the cockpit and settles into the pilot's seat. He punches buttons. The engines ROAR.

OUTSIDE, Jango Fett's ship lifts off from the platform and heads up into the lowering sky. It disappears. Lightning flashes. Rain lashes the tower and streams across the surface of the platform, to where:

A HAND suddenlt clutches at the very edge of the platform. A moment later, ANOTHER HAND grabs hold.

EXT. TATOOINE, BLUFF OVERLOOKING HOMESTEAD - LATE DAY
The Naboo Starship descends, hovers, and land on a bluff. ANAKIN and PADME get out. They look down from the edge of the bluff to where the homestead is seen on the desert floor below.

				PADME
			Stay with the ship, Artoo.

ARTOO WHISTLES as ANAKIN and PADME start down the trail toward the homestead.

EXT. TATOOINE, DESERT, HOMESTEAD MOISTURE FARM - LATE DAY
C-3PO is working outside the homestead. He still lacks an outer covering; his inner parts and wiring show. He looks up as ANAKIN and PADME arrive,

				C-3PO
			Good evening. May I help you?

				ANAKIN
			Threepio?

				C-3PO
			Oh, my... oh, my! Master
			Anakin! My goodness, I can hardly
			believe it! And this must be Miss
			Padme.

				PADME
			Hello, Threepio.

				ANAKIN
			I've come to see my mother.

				C-3PO
			Oh, dear! I'm so terribly sorry,
			Master Annie.

				PADME
			Threepio, what's happened?

				C-3PO
			I think we'd better go inside.

EXT. TATOOINE, HOMESTEAD, COURTYARD - LATE DAY
ANAKIN, PADME and THREEPIO arrive in the courtyard. THREEPIO shuffles ahead.

				C-3PO
			Master Lars - Master Owen!
			Somebody to see you!

OWEN LARS and BERU WHITESUN come out into the courtyard.

				ANAKIN
			I'm Anakin Skywalker. I'm here
			looking for my mother.

				OWEN
			Owen Lars... I guess I'm your
			step-brother.
				(they shake hands)
			This is my girlfriend, Beru.

				BERU
			Hello.

				PADME
			I'm Padme.

				OWEN
			I had a feeling you might show up
			some day.

				ANAKIN
			Is my mother here?

				CLIEGG
			No, she's not.

CLIEGG LARS swings from the house on a small floating chair. One of his legs is heavily bandaged; the other is missing. He balances awkwardly and puts out a hand.

				CLIEGG
				(continuing)
			Cliegg Lars. Shmi is my wife...
			Come on inside. We have a lot to
			talk about.

INT. TATOOINE, HOMESTEAD, KITCHEN - LATE DAY
BERU puts several steaming cups of ardees on a tray and exits the kitchen...

				CLIEGG (O.S.)
			It was just before dawn. They
			came out of nowhere. A hunting
			party of Tusekn Raiders.

INT. TATOOINE, HOMESTEAD, DINING AREA - LATE DAY
CLIEGG, OWEN, PADME and ANAKIN sit around the table, BERU brings the drinks from the kitchen.

				CLIEGG
			Your mother had gone out early,
			like she always did, to pick
			mushrooms that grow on the
			vaporatos. From the tracks, she
			was about halfway when they
			took her. Those Tuskens walk like
			men, but they're vicious, mindless
			monsters. Thirty of us went out
			after her. Four of us came back.
			Three more are still out there
			looking. I'd be with them,
			only... I just couldn't ride any
			more... until I heal.

CLIEGG grimaces, easing his throbbing leg.

				CLIEGG
				(continuing)
			This isn't the way I wanted to
			meet you, son. This isn't how
			your mother and I planned it. I
			don't want to give up on her, but
			she's been gone a month. There's
			little hope she's lasted this long.

Silence. Then ANAKIN stands up.

				OWEN
			Where are you going?

				ANAKIN
			To find my mother.

				PADME
			No, Annie!

				CLIEGG
			She's daed, son. Accept it.

				ANAKIN
			I can feel her pain, and I will
			find her. I know she's alive.

ANAKIN turns abruptly.

EXT. TATOOINE, HOMESTEAD, MOISTURE FARM - LATE DAY
ANAKIN stands looking across the desert. PADME comes running out of the homestead after him, followed by OWEN. ANAKIN turns to PADME.

				ANAKIN
			You are going to have to stay
			here. These are good people,
			Padme. You'll be safe.

				OWEN
			Take my speeder bike.

				PADME
			Anakin...

PADME hugs him. ANAKIN walks over to Owen's speeder bike, which is standing close by.

				ANAKIN
			I trust you'll watch over her,
			Owen.

				OWEN
			Don't worry.

ANAKIN swings onto the bike. The engine fires.

				ANAKIN
			I won't be long.

ANAKIN takes off across the desert. PADME watches him go.

EXT. SPACE, GEONOSIS
The red planet of Geonosis is circled by a large asteroid field that form rings. Jango Fett's ship appears, heading toward it.

INT. COCKPIT, FETT SHIP, SPACE, GEONOSIS
JANGO FETT grins at BOBA FETT.

				JANGO FETT
			Nearly there, son.

JANGO FETT guides he ship around the asteroids. Suddenly:

				BOBA FETT
			Dad, look!!

On the view screen, Obi-Wan's ship appears, chasing after them. JANGO FETT grabs the controls. They are thrown around as the ship plummets to try to lose OBI-WAN.

				JANGO FETT
			Hang on!

The ship goes into a power-climb. A GREAT SPACE DDOGFIGHT ensues between OBI-WAN and JANGO FETT.

EXT. SPACE, GEONOSIS
The ships flip, roll, and turn at incredible speed, didging, weaving and firing. They tumble from near misses. Hits fly off Obi-Wan's fighter as one of Jango's missiles gets through.

Finally, it seems as if OBI-WAN is getting the upper hand. JANGO FETT breaks off the fight and dives sharply. He maneuvers deftly between two huge asteroids.

In JANGO FETT'S COCKPIT, BOBA FETT flinches as asteroids pass very close by.

				BOBA FETT
			Dad! Watch out!

				JANGO FETT
			Stay calm, son. We'll be fine.
			That Jedi won't be able to follow
			us through this.

But Obi-Wan ship dives into the asteroid belt after them.

IN OBI-WAN'S COCKPIT, his skill is pushed to the limit as he throws the ship from side to side, avoiding great rocks. Then a huge asteroid tumbles across his path. There seem no way he can avoid it. OBI-WAN fires a couple of aerial torpedoes. They streak toward the asteroid.

IN JANGO'S COCKPIT, they see the huge explosion as Obi-Wan's ship appears to smash into the asteroid.

				BOBA FETT
			Got him! Yeahhhhh!

				JANGO FETT
			We won't see him again.

BOBA FETT laughs. Jango Fett's ship emerges from the asteroid belt and heads down toward the planet of Geonosis.

EXT. TATOOINE, DESERT, JAWA CAMP - SUNSET
ANAKIN stands in the middle of a crowd of JAWAS. He asks them from directions. The JAWAS confer exicitedly, then the CHIEF JAWA points in a particular direction. ANAKIN gets on the bike and speeds off to where the JAWA pointed.

EXT. TATOOINE, DUNE SEA, CAMPFIRE - TWILIGHT
ANAKIN rides over a large dune toward a small flickering light in the distance.

He rides up and stops the bike in front of a campfire. There are bodies of THREE DEAD FARMERS lying beside the campfire. TWO EOPIES are thethered nearby, along with a burned and smoking speeder.

EXT. TATOOINE, LANDSCAPE (FULL MOON) - NIGHT
THREE DIFFERENT SHOTS. ANAKIN rids the speeder bike through three exotic landscapes. In one shot, he stops and looks down at some tracks. Then he starts up his speeder and rides off.

EXT. TATOOINE, DESERT, HOMESTEAD (FULL MOON) - NIGHT
The lights of the vaporators blink in the night sky. Somewhere close by, a night animal HOWLS.

EXT. TATOOINE, HOMESTEAD, COURTYARD (FULL MOON) - NIGHT
PADME is pacing the courtyard restlessly. She stops, listening to the animal HOWLING nearby. She shivers slightly, then turns and goes into the garage at the side of the courtyard.

INT. TATOOINE, HOMESTEAD - GARAGE (FULL MOON) - NIGHT
PADME stands looking at a speeder parked in the garage. Short silence. Then:

				C-3PO
			Please don't leave us, Miss Padme.
			These people need your help.

THREEPIO is parked in a corner.

				PADME
			I'm not leaving, Threepio. I just
			can't sleep.

				C-3PO
			That's something I cannot relate
			to. As a Protocol Droid, I'm
			either active or inactive.
			There's no in-between.

				PADME
			I guess you're lucky.

				C-3PO
			Do you really think so..? I
			suppose I shouldn't expect...

				PADME
			You're not happy here?

				C-3PO
			Oh, I'm not unhappy... and my
			masters here ar so kind I
			wouldn't wish to trouuble them,
			it's just... being like this...
			well, it's embarrassing.

				PADME
			Being like what?

				C-3PO
			Naked. If you pardon the
			expression. You see, when Master
			Annie made me, he never quite
			found the time to give me any
			outer covering. It's so
			humiliating. How would you like it
			if you had to go around with all
			your circuits showing?

				PADME
			I guess I wouldn't like it at all.

				C-3PO
			Of course you wouldn't. Nobody
			would. It's simply not protocol.

PADME looks thoughtfully at a pile of spare parts and bits of metal and tools.

				PADME
			Maybe we can do something about it.

				C-3PO
			I don't think so. Only Master
			Annie...

				PADME
			Why not? They seem to have a box
			of old coverings here.

				C-3PO
			Oh? How observant of you, Miss
			Padme. Of course, I'm just not
			mechanically minded... if you see
			what I mean.

PADME picks up a piece of metal and holds it against him.

				PADME
			Let's see, if we put this...
			here...

				C-3PO
			Ooooh! That's tickles.

				PADME
			You'll have to be quiet, Threepio.
			Hold still, please.

EXT. SPACE, GEONOSIS RINGS
A huge chunk of rock tumbles slowly through the asteroid bely. CAMERA CLOSES, to discover Obi-Wan's Starship hidden in a blasted-out area on the pitted back side of the great rock.

INT. COCKPIT, JEDI FIGHTER, SPACE, GEONOSIS RINGS
OBI-WAN looks out toward Geonosis and sees in the distance a large fleet of Trade Federation Ships hidden among the asteroids. He starts the engines of his fighter.

Obi-Wan's Fighter moves out from the back side of the asteroid and heads away from the asteroid field, descending toward Geonosis.

EXT. GEONOSIS, LANDING AREA - NIGHT
Obi-Wan's ship skims across the top of a small mesa along the edge of a rocky ridge. He maneuvers under a rock overhang and lands. He gets out of the Fighter and walks onto the mesa. The wind whips at him. He looks around.

Geonosis is a red rock planet, featureless apart from buttes and mesas, and occasional tall stalagmites that stand out dramatically on the arid plains.

The night is quiet, except for an occasional WEIRD CRY. OBI-WAN checks his bearings, then heads away.

EXT. GEONOSIS, ROCK FACE TRAIL - NIGHT
OBI-WAN climbs a steep, narrow trail. Suddenly, a CRY is heard close by. OBI-WAN stumbles slightly. His foot slips on the edge, sending a stream of peblles skittering into the darkness.

OBI-WAN listens. Silence. He draws his lightsaber but does not ignite it.

He sets off again and works his way around a narrow corner, to confront a crouching MASSIFF (a dog-sized lizard) with slavering fangs! The beast leaps at him, and OBI-WAN ignites his lightsaber as the MASSIFF knocks him on his back. Its jaws open wide. OBI-WAN stabs the creature, throws it off of him, and jumps up.

A SECOND MASSIFF jumps from behind. OBI-WAN swings around and cuts it in half. The MASSIFF flies over the cliff, HOWLING. It plummets to its death hundreds of feet below.

EXT. TATOOINE, CLIFF (FULL MOON) - NIGHT
ANAKIN pulls up near the edge of a cliff. He gets off the bike and creeps to the edge. He looks over to see a Tusken camp in the oasis below. One of the huts at the edge of the camp has TWO TUSKEN GUARDS outside it.

EXT. TATOOINE, TUSKEN RAIDER CAMP, OASIS (FULL MOON) - NIGHT
ANAKIN creeps through the camp, working his way from hut to hut, flattening himself against the wall,s overhearing snatches of Tusken conversation from inside, using the shadows to him him until he arrives at the hut with the TWO GUARDS. They are sitting a short distance from the door. ANAKIN wriggles around the black. He takes out his lightsaber and cuts into the base of the wall.

INT. TUSKEN RAIDER HUTT - NIGHT
The lightsaber completes the hole in the wall. ANAKIN wriggles in. He pulls himself to his feet. There are candles everywhere.

A shaft of moonlight from a hole in the roof pierces the gloom of the hut. By its light, ANAKIN sees SHMI, hanging from a wooden frame in the middle of the hut.

He cuts her free, takes her into his arms, and lowers her gently to the ground. Her eyes are closed. Her face is bloodied. She has been 
terribly beaten. Anakin cradles her tenderly.

				ANAKIN
			Mom... Mom... Mom... 

SHMI'S eyelids flutter - and barely open. They are caked with blood.

				SHMI
			Annie...? Is it you?

SHMI'S eyes focus slowly. ANAKIN gives a little choking gasp.

				ANAKIN
			I�m here, Mom. You�re safe. Hang
			on. I�m going to get you out of
			here...

				SHMI
			I�m so glad... to see you,
			Annie... Now... I am complete...

				ANAKIN
			Just stay with me, Mom. I�m going
			to make you well again.
			Everything�s going to be fine.

				SHMI
			You look so handsome. My son...
			my grown-up son. I�m so proud of
			you, Annie... so proud... I missed
			you so much... I love...

SHMI dies. ANAKIN draws her to his breast. There is silence for a moment. ANAKIN lifts his head, listening for a moment, then he sits on the floor of the Tusken hut, cradling his dead mother in his arms.

EXT. GEONOSIS, ROCK FACE TRAIL - NIGHT
OBI-WAN arrives at the head of the trail. Far below, a flat plain stretches into the distance. He stop, peering into the darkness, where strange shapes loom indistinctly.

OBI-WAN takes a pair of electronic binoculars from his belt and puts them to his eyes. He sees a cluster of great towers like fantastic stalagmites rise from the plain below.

SLOW PAN with the binoculars, and suddenly a line of Battle Starships come into view. OBI-WAN touches the viewfinder. Between fifty and a hundred Federation Starships in near rows. Some are on platforms that are carrying the Starships diwn to an underground facility. Other platforms are rising to the surface. They carry THOUSANDS of BATTLE DROIDS that step off and file into the waiting ships. A fully loaded Starship takes off. OBI-WAN swings the binoculars upward, to see more Federation Starships.

EXT. TATOOINE, TUSKEN RAIDER CAMP, OASIS - DAWN
The pale light grows. Thin tendrils of smoke rise slowly in the cold, clear air. Somewhere an dog BARKS. An OLD WOMAN comes out of one of the huts. She carries a pail. She swirls it and tosses the dirty water onto the ground.

As she goes back inside the hut, a TUSKEN CHILD runs past, dragging a stick in the sand. The CHILD runs through the line of huts, turns a corner, and stops suddenly, staring at the bodies of the TWO TUSKEN GUARDS. Between them, ANAKIN stands outside the hut door. His face is a grim mask. The CHILD stares, then there is a FLASH OF LIGHT as Anakin�s lightsaber switches on.

EXT. GEONOSIS, LANDING AREA - NIGHT
OBI-WAN comes running back to his ship and climbs into the cockpit. He settles into his seat. His ARFOUR DROID beeps a happy greeting. OBI-WAN switches on his comlink.

				OBI-WAN
			"Guiding light" to "old folks
			home."

EXT. CORUSCANT, REPUBLIC EXECUTIVE BUILDING - DAY
LOW ANGLE. A line of reflecting pools with splashing fountains flanked by statues on each side leads to the main entrance to the awesome building.

INT. CORUSCANT, CHANCELLOR'S OFFICE
A hologram of OBI-WAN flickers in front of a group, made up of Jedi (YODA, MACE WINDU, and KI-ADI-MUNDI) and Senators (BAIL ORGANA, ASK AAK, LUMINARA, and JAR JAR). PALPATINE and MAS AMEDDA are in the middle of the group, watching with growing concern.

				OBI-WAN
			...Starships from the Trade
			Federation and the Commerce Guilds
			are taking deliveries of battle
			droids from the foundries on
			Geonosis.

				BAIL ORGANA
			That's outrageous! The treaty
			forbids the Trade Federation from
			building up an army. What are
			they doing?!

				OBI-WAN
			The droid foundry seems to be
			working at full capacity. I am
			going to go down and investigate.
			I will bring Jango Fett back home
			for interrogation.

				PALPATINE
			Those Geonosian foundries are part
			of the Techno Union. We will call
			in their representatives and ask
			them a few very pointed questions.

				OBI-WAN
			One more thing. Jango mentioned
			he was recruited by someone named
			Darth Tyranus. Any idea who that
			might be?

				YODA
			With the forename Darth, a Sith he
			must be.

				MACE WINDU
			Our missing apprentice. They are
			playing their hand at last.

				OBI-WAN
			Do you believe he could be the
			mysterious Sido-Dyas, who made the
			deal for the clone army?

				YODA
			Perhaps too many pieces are missing
			from this puzzle, there are.

				MACE WINDU
			Be careful, Obi-Wan. This
			investigation is becoming less
			than routine. Do you need help?

				OBI-WAN
			Let me see if I can figure out
			what's going on first.

The hologram of OBI-WAN fades off. PALPATINE stares at the spot where the hologram was in disbelief.

				BAIL ORGANA
			The Commerce Guilds are preparing
			for war... there can be no doubt
			of that.

				PALPATINE
			Count Dooku must have made a
			treaty with them.

				MACE WINDU
			We must stop them soon before
			they're fully ready.

				SENATOR ASK AAK
			The debate is over, we need
			that clone army now!

				BAIL ORGANA
			Unfortunately, the debate is not
			over. The Senate will never be
			able to approve the use of that
			army before the separatists
			attack.

Mas Amedda, who had been silent up until now suddenly speaks up.

				MAS AMEDDA
			This is a crisis! If the Senate
			votes the Chancellor emergency
			powers, he could approve the use
			of the army in a minute.

				PALPATINE
			Please, please, I don't wish to
			have emergency powers. That's too
			extreme a solution. It's akin to
			a dictatorship. We must rely on
			the Jedi. Master Yoda, how many
			are available to go to Geonosis?

MACE WINDU and YODA look at one another.

				YODA
			Two Hundred,... less or more.

				BAIL ORGANA
			With all due respect for the Jedi
			Order, two hundred will be no
			match for hundreds of thousands of
			battle droids.

				MACE WINDU
			Patience. We should wait for Obi-
			Wan to report back. We don't know
			that Count Dooku has made a treaty
			with the Corporate Alliance, it's
			speculation.

				SENATOR ASK AAK
			But we must prepare for the worst.
			I'm going to propose a motion
			granting emergency powers to the
			Chancellor at the next session. We
			must not wait!

				PALPATINE
			Out of the question, Senator! You
			and I are too closely aligned.
			The issue will become partisan and
			debates will begin. The proposal
			must come from a neutral source.

				MAS AMEDDA
			If only Senator Amidala were here.

JAR JAR steps forward from the back of the group.

				JAR JAR
			Supreme Chancellor... my august
			colleagues, I would be proud to
			propose the motion in question.
			This is a grave situation, and I'm
			sure Senator Amidala, and the
			Queen of Naboo would agree.

				SENATOR ASK AAK
			Thank you, Representative Binks.

Silence. Then PALPATINE sighs deeply.

				PALPATINE
			If called upon, I will serve. But
			it will be the saddest day of my
			life.

EXT. TATOOINE, DESERT, HOMESTEAD MOISTURE FARM - DAY
All is quiet. BERU comes out of the house. She goes to a moisture line and starts to draw water.

INT. TATOOINE, HOMESTEAD, GARAGE - DAY
PADME fixes the last piece of covering onto THREEPIO.

				PADME
			There!

PADME stands back. OWEN is with her. They look at THREEPIO. He isn't the golden figure we know because PADME has had to use whatever stuff she could findin the garage. He is multi-coloured in several textures, but he is complete.

				C-3PO
			Um. How do I look?

				OWEN
			Great! You look perfect.

				C-3PO
			Perfect? Oh, Miss Padme, I'm so
			happy!
				(extending his hand to shake hers)
			Oh, pardon me.

THREEPIO drops his hand and bows formally.

				THREEPIO
				(continuing)
			Thank you.

He forgets formality and hugs her. PADME hugs him back, laughing.

				C-3PO
				(continuing)
			Thank you! Thank you! Thank you!

				OWEN
				(grinning)
			Well, Padme, I think he should be
			yours from now on... I know that
			is what my Mom would want.

				C-3PO
			Oh, my!

Then suddenly, from outside:

				BERU (V.O.)
			Come topside, everybody! He's
			back! He's back!





PAGE 83

PAGE 84

PAGE 85

PAGE 86

PAGE 87

PAGE 88







INT. TATOOINE, HOMESTEAD, GARAGE - DAY
A rough hologram of OBI-WAN is projected onto the garage by ARTOO. ANAKIN, PADME and THREEPIO watch the flickering image.

				OBI-WAN
			...Alliance have pledged their
			armies to Count Dooku and are
			forming an... Wait!... ah...
			attack... I don't... make it...
			aaaggghhh!

The hologram cuts off. ANAKIN jumps up, agitated.

				ANAKIN
			I'm going after him!

				PADME
			I thought the first thing he said
			was to retransmit his message to
			Coruscant.

				ANAKIN
			Yeah, you're right, you're right.

EXT. TATOOINE, HOMESTEAD, MOISTURE FARM - LATE DAY
ANAKIN, PADME, ARTOO and THREEPIO leave the homestead, waving to CLIEGG, OWEN and BERU as they go into the desert.

INT. COCKPIT, NABOO STARSHIP - SUNSET
ANAKIN sits down in the cockpit with PADME. THREEPIO is behind them. ARTOO is beside him. They are watching a hologram of MACE WINDU.

				MACE WINDU
			We will deal with Count Dooku. The
			most important thing for you,
			Anakin, is to stay where you are.
			Protect the Senator at all costs.
			That is your priority.

				ANAKIN
			Understood, Master.

The hologram switches off. PADME is looking at the readout on the ship's control panel.

				PADME
			They'll never get there in time to
			save him. They have to come half
			way across the galaxy. Look,
			Geonosis is less than a parsec away.

PADME starts to hit buttons and flick switches. ANAKIN puts a hand over hers, stopping her. She stares at him.

				ANAKIN
			If he's still alive.

				PADME
			Annie, are you just going to sit
			here and let him die?? He's your
			friend... your mentor...

				ANAKIN
			...He's like my father, but you
			heard Master Windu. He gave me
			strict orders to stay here.

				PADME
			He gave you strict orders to
			protect me...

PADME pulls her hand free and flicks more switches. The engines fire.

				PADME
				(continuing)
			...and I'm going to save Obi-Wan.
			So if you plan to protect me, you
			will have to come along.

ANAKIN grins and takes the controls.

EXT. TATOOINE, BLUFF OVERLOOKING HOMESTEAD - SUNSET
The Naboo Starship rises from the bluff and zooms away.

EXT. CORUSCANT, JEDI TEMPLE - DAY
TWO HUNDRED JEDI KNIGHTS are assembling outside the huge center of the Jedi Order.

INT. CORUSCANT, JEDI TEMPLE, COUNCIL CHAMBER - DAY
The JEDI COUNCIL are assembled as MACE WINDU makes his plea.

				MACE WINDU
			The longer we wait, the stronger
			Dooku's armies become. We cannot
			wait for the Senate to make up its
			mind about granting the Chancellor
			emergency powers, in order to be
			able to use that clone army... We
			have the authority to go now. We
			must go now.

All of the JEDI COUNCIL nod their approval.

				YODA
			Agreed, Master Windu. Two hundred
			Jedi send. Enough, let's hope
			they are.

INT. CORUSCANT, MAIN SENATE CHAMBER - DAY
Inside the great rotunda, the UPROAR is even louder. Opposing SENATOES yell furiously at one another.

				MAS AMEDDA
			Order! Order!!

Finally, the uproar dies.

				PALPATINE
			In the regrettable absence of
			Senator Amidala, the chair
			recognises Senior
			Representative of Naboo, Jar Jar
			Binks.

Amid the conflicting storm of CHEERS AND BOOS, JAR JAR, with TWO GUNGAN AIDES, floats on his pod to the middle of the vast space. He looks at PALPATINE nervously. PALPATINE nods. JAR JAR clears his throat.

				JAR JAR
			Senators, dellow felagates...

Laughter. Jeers. JAR JAR blushes.

				MAS AMEDDA
			Order! The Senate will accord the
			Representative the courtesy of a
			hearing!

Comparative quiet. JAR JAR grips the edge of the podium.

				JAR JAR
			In response to the direct threat
			to the Republic from the
			Confederacy of Independent
			Systems, I propose that the Senate
			gives immediate emergency powers to
			the Supreme Chancellor.

Uproar. JAR JAR looks a little sheepish.

				JAR JAR
				(continuing)
			Who can deny these are exceptional
			times? Exceptional times demand
			exceptional measures!
			Exceptional measures demand
			exceptional men!

				ORN FREE TAA
			We won't support a dictator.

SHOUTS of agreement.

				JAR JAR
			That is the sentiment every one of
			us agrees with! And when the
			shadow of war has dispersed and
			the bright day of liberty has
			dawned once again, the power we now
			give to the Supreme Chancellor
			will be gladly, and swiftly
			returned. Out ancient liberties
			will be restored to us, burnished
			even more brightly than before!

Brief silence, then a rolling wave of APPLAUSE. JAR JAR beams and bows.

PALPATINE rises.

				PALPATINE
			It is with great reluctance that
			I have agreed to this calling. I
			love democracy... I love the
			Republic. The fact that this
			crisis is demanding I be given
			absolute power to tule over you is
			evident. But I am mild by nature
			and have no desire to destroy
			the democratic process. The power you
			give me I will lay down when this
			crisis has abated, I promise you.
			And all I ask in return is when my
			current term of office is over,
			you allow me to reture and live
			out my life in peace.

				MAS AMEDDA
			We shall proceed to the vote. All
			those in favor of granting
			emergency powers to the Supreme
			Chancellor, signal ate at this
			time... those opposed?

EXT. SPACE
The Naboo Starship heads toward the rings of Geonosis.

EXT. GEONOSIS, LANDING AREA
The Naboo Starship lands.

INT. COCKPIT, NAOO STARFIGHTER - DAY
ANAKIN switches off the engines. ARTOO and THREEPIO are in the navigation area of the cockpit. PADME is in the co-pilot's seat. She gets up.

				ANAKIN
			Hey, where are you going?

				PADME
			To find Obi-Wan.

ANAKIN gets up and goes over to her.

				ANAKIN
			No! You're not!

He grabs her arm.

				PADME
			Let go of me!

				ANAKIN
			I'm not letting you go out there.
			It's too dangerous.

				PADM�
			What?!?

				ANAKIN
			It's my job to protect you. I said
			it's too dangerous. You're not
			going, and that's final!

				PADM�
			Don't you give me orders, Annie!
			I'm a Senator of the Galactic
			Republic. You have no authority
			to contain me, restrain me, or
			direct me! You remember your
			place, young man.
				(standing up)
			Now you can come along and protect
			me or stay here. It's up to you.

PADME storms out of the cockpit of the Naboo Starfighter. ANAKIN stands scratching his head, then follows.

ARTOO BEEPS and WHISTLES.

				C-3PO
			Yes, it is, Artoo. Most
			confusing. One moment they're
			generating a pleasant mutual
			attraction and the next, waves of
			violent hostility. Even though
			I'm programmed to understand them,
			I doubt if I ever shall.

ARTOO WHISTLES a plaintive sigh.

INT. GEONOSIS, CORRIDORS - DAY
ANAKIN and PADME enter the stalagmite city. They stop, looking around in wonder at the emptiness.

				PADME
				(in a low voice)
			It's empty!

They start forward. As they pass, the surface of the pillars seems to pulse slowly and move. High above WINGED CREATURES grow from the pillars and detach themselves.

INT. GEONOSIS, CENTRAL SQUARE - DAY
ANAKIN and PADME cross the square, reaching the middle. They stop suddenly as FOUR GEONOSIANS grabs them. ANAKIN reaches for his lightsaber.

				PADME
			Wait!

TWENTY WINGED GEONOSIANS carrying weapons alight on the flagstones in front of them.

The GEONOSIANS part, and COUNT DOOKU appears. He bows courteously.

				COUNT DOOKU
			Senator Amidala, I've heard so
			much about you.

				PADM�
			Count Dooku, I assume.

				COUNT DOOKU
			I'm delighted to meet you at
			last. We have a great deal to
			discuss, Senator. I hope you can
			keep your young Jedi under control.

				PADM�
			Don't worry he's housebroken.

INT. CONFERENCE ROOM (GEONOSIS) - DAY
COUNT DOOKU sits at a large conference table with PADME on the far 
side. ANAKIN stands behind her with FOUR GEONOSIANS GUARDS standing behind him. JANGO FETT stands behind COUNT DOOKU, and SIX GEONOSIAN GUARDS stand behind him.

				PADM�
			You are holding a Jedi Knight, Obi-
			Wan Kenobi. I am formally
			requesting you turn him over to
			me, now.

				DOOKU
			He has been convicted of
			espionage, Senator, and will be
			executed. In just a few hours, I
			believe.

COUNT DOOKU smiles.

				PADM�
			He is an officer of the Republic.
			You can't do that.

				DOOKU
			We don't recognise the Republic
			here, Senator. But if Naboo were
			to join our Alliance, I could
			easily hear your plea for clemency.

ANAKIN grabs his lightsaber but doesn't turn it on.

				PADM�
			And if I don't join your
			rebellion, I assume this Jedi with
			me will also die?

				DOOKU
			I don't wish to make you to join
			our cause against your will,
			Senator, but you are a rational,
			honest representative of your
			people and I assume you want to do
			what's in their best interest.
			Aren't you fed up with the
			corruption, the bureaucrats, the
			hypocrisy of it all?.. Aren't
			you? Be honest, Senator.

				PADM�
			The ideals are still alive, Count,
			even if the institution is failing.

				DOOKU
			You believe in the same ideals we
			believe in! The same ideals we
			are striving to make prominent.

				PADM�
			If what you say is true, you
			should stay in the Republic and
			help Chancellor Palpatine put
			things right.

				DOOKU
			The Chancellor means well, M'Lady
			but he is incompetent. He has
			promised to cut the bureaucracy,
			but the bureaucrats are stronger
			than ever, no? Senator, the
			Republic cannot be fixed. It is
			time to start over. The
			democratic process in the Republic
			is a sham, a shell game played
			on the voters. It will not be long
			before the cult of greed, called
			the Republic, will lose even the
			pretext of democracy and freedom.

				PADM�
			I cannot believe that. I will not
			forsake all I have honoured and
			worked for and betray the
			Republic. I know of your treaties
			with the Trade Federation, the
			Commerce Guilds, and the others,
			Count. What is happening here is
			not government that has been
			bought out by business... it's
			business becoming government!

				DOOKU
			Are you willing to betray your Jedi
			friends? Without your co-operation
			I can do nothing to stop their
			execution.

				PADM�
			What is to happen to me? Am I to be
			executed also?

				DOOKU
			I wouldn't think of such an
			offence. But, there are
			individuals who have a strong
			interest in your demise, M'lady.
			It has nothing to do with
			politics, I'm afraid. It's purely
			personal, and they have already
			paid great sums to have you
			assassinated. I'm sure they will
			push hard to have you included in
			the executions. I'm sorry but if
			you are not going to co-operate, I
			must turn you over to the
			Geonosians for justice. I've done
			all I can for you.

JANGO FETT moves over to ANAKIN.

				JANGO FETT
			I'll take that weapon.

ANAKIN hesitates.

				DOOKU 
			You may cause a lot of bloodshed,
			my young Jedi, but you will not
			escape.

				PADM�
			Anakin...

ANAKIN hands his lightsaber over to JANGO FETT.

INT. GEONOSIS, HIGH AUDIENCE CHAMBER - DAY
ANAKIN and PADME are standing in the centre of what looks like a courtroom. Seated before them in a tall, boxed-off area is POGGLE THE LESSER, Archduke of Geonosis. He is accompanied by his underling, SUN RIT. Off to one side the Separatist Senators PO NUDU, TESSEK, and TOONBUCK TOORA. Next to them are the Commerce Dignitaries, SHU MAI, NUTE GUNRAY, PASSEL ARGENTE, WAT TAMBOR and SAN HILL of the Intergalactic Bank Clan. Along the wall about a HUNDRED GEONOSIANS wait for a verdict.

				SUN RIT
			You have been charged and found
			guilty of Espionage.

				POGGLE
			Do you have anything to say before
			your sentence is carried out?

				PADM�
			You are committing an act of war,
			Archduke. I hope you are prepared
			for the consequences.

POGGLE laughs. COUNT DOOKU simply smiles.

				POGGLE
			We build weapons, Senator... that
			is our business! Of course we're
			prepared!

				NUTE GUNRAY
			Get on with it. Carry out the
			sentence. I want to see her suffer.

				POGGLE
			Your other Jedi friend is waiting
			for you, Senator. Take them to
			the arena!

FOUR GUARDS take hold of PADME and ANAKIN. They are escorted out of the chamber to the sounds of chuckling.

INT. GEONOSIS TUNNEL TO EXECUTION ARENA - DAY
In the gloomy tunnel, ANAKIN and PADME are tossed into an open cart. The murmur of a vast crowd is heard offscreen. GUARDS extend their arms along the framework and tie them so that they stand facing each other.

The DRIVER gets up onto his seat.

				ANAKIN
			Don't be afraid.

				PADM�
			I'm not afraid to die. I've been
			dying a little bit each day since
			you came back into my life.

				ANAKIN
			What are you talking about?

				PADM�
			I love you.

				ANAKIN
			You love me?! I thought we
			decided not to fall in love. That
			we would be forced to live a lie.
			That it would destroy our lives...

				PADM�
			I think our lives are about to be
			destroyed anyway. My love for you
			is a puzzle, Annie, for which I
			have no answers. I can't control
			it... and now I don't care. I
			truly, deeply love you, and before
			we die I want you to know.

PADME leans toward ANAKIN. By straining hard, it is just possible for 
their lips to meet. They kiss.

				ANAKIN
			I have no desire to be cured of
			this love either. Long or short,
			I vow to spend the rest of my life
			with you.

They kiss again.

The DRIVER cracks his whip over the ORRAY harnessed between the shafts. The cart jerks forward. Suddenly, there isa HUGE ROAR and blinding sunlight as they emerge into the arena

INT. GEONOSIS, EXECUTION ARENA - DAY
The great stadium is packed with tier upon tier of yelling GEONOSIANS. The cart trundles to the center, where OBI-WAN is chained to one of four upright posts thatare three feet in diameter. The cart stops. PADME and ANAKIN are taken down, dragged to posts, and chained to them. PADME is in the center.

				OBI-WAN
			I was beginning to wonder if you
			had gotten my message.

				ANAKIN
			I retransmitted it as you
			requested, Master. Then we decided
			to come and rescue you.

				OBI-WAN
			It looks like you're going a good
			job so far.

Their arms are pulled high above their heads, and the cart drives away. There is another ROAR as POGGLE THE LESSER, COUNT DOOKU, NUTE GUNRAY, THE FETTS and DIGNITARIES arrive in the archducal box and take their places.

				SUN RIT
			The felons before you have been
			convicted of espionage against the
			Sovereign System of Geonosis.
			Their sentence of death is to be
			carried out in this public arena
			henceforth.

The crowd ROARS and CHEERS. In the box, POGGLE THE LESSER rises. The crowd becomes quiet.

				POGGLE
			Let the executions begin!

The crowd goes wild.

				ANAKIN
			I have a bad feeling about this.

From different gates around the arena, THREE MONSTERS are driven in. One is a REEK (bull-like), one is a NEXU (lion-like), and one is an ACKLAY (a kind of dino-lobster). They are driven in by PICADORS carrying long spears and riding ORRAYS. The PICADORS poke the MONSTERS toward the center, then retire to the perimeter.

The MONSTERS toss their heads, looking around, ROARING or SCREECHING. Then they catch sight of the THREE CAPTIVES and start moving toward them.

				OBI-WAN
			Take the one the left. I'll
			take the one on the right.

				ANAKIN
			What about Padme?

PADME has turned around and is pulling herself up by the chain to the top of the post. Within a moment, she is standing on top of it, trying to pull the chain free.

				OBI-WAN
			It looks like she's already on top
			of things.

The REEK charges ANAKIN. He jumps up, and the beast hits the post hard. ANAKIN lands onto its back, wrapping part of his chain around its horn. The REEK backs off, shaking its head angrily, which tears the chain from the post

OBI-WAN ducks around the post as the ACKLAY charges. It knocks the post flat, sending OBI-WAN sprawling. The ACKLAY crunches the post between its claws, freeing the chain. OBI-WAN leaps up and runs towards ONE of the PICADORS. The ACKLAY taks off after him.

The NEXU arrives at PADME'S post and rears on its hind legs. One top, PADME struggles to tear the chain free. The NEXU ROARS, displaying wicked, dripping fangs.

In the archducal box, NUTE GUNRAY beams and rubs his hands.

In the arena, OBI-WAN runs at the PICADOR. The ORRAY rears up. OBI-WAN grabs the PICADOR'S long spear and pole vaults over him. The chasing ACKLAY smashes into the ORRAY. It goes down. The PICADOR tumbles onto the sand, where he is grabbed by the ACKLAY and crunched.

ANAKIN's REEK starts to buck. It charges around the arena with ANAKIN hanging on for dear life. He whirls the free length of chain around his head and casts it into the REEK's mouth. Its jaws clamp hard on the chain. ANAKIN yanks hard on the chain, turning the REEK, beginning to ride it.

The NEXU's claws dig deep into the post. The cat-like creature reaches the top of the post and takes a swipe at PADME. She turns and the claw barely catches her shirt ripping it off, leaving superficial claw marks across her back. She hits the creature with her chain and it backs off down the pole. Then, PADME jumps off the post into the air. She swings around on the chain and whacks the beast hard on the head with both her feet. It tumbles back onto the sand.

In the archducal box:

				NUTE GUNRAY
			Foul!! She can't do that... shoot
			her or something!

In the arena, OBI-WAN runs out from behind the fallen ORRAY and throws the spear at the ACKLAY, hitting it in the neck. It lets out a terrible SCREECH and turns on him. The NEXU springs up and makes to leap up at PADME again. She finally manages to work the chain loose. ANAKIN comes charging up on the REEK.

				ANAKIN
			You okay?

				PADME
				(nods, gasping)
			Sure! Well, sort of.

				ANAKIN
			Jump!!!

The NEXU springs. PADME leaps from the top of the post to land on the REEK in front of ANAKIN. He hauls her upright. The REEK charges away, around the arena. The NEXU bounds after it. The REEK passes the wounded ACKLAY. The NEXU smells the blood and turns aside to attack the ACKLAY. The TWO MONSTERS fight. The crowd GROANS and BOOS.

In the archducal box, NUTE GUNRAY turns angrily to COUNT DOOKU.

				NUTE GUNRAY
			This isn't how it's supposed to
			be! Jango, finish her off.

COUNT DOOKU motions for the bounty hunter to ptay put. BOBA FETT is enjoying the spectacle.

				COUNT DOOKU
				(smiling enigmatically)
			Patiece, Viceroy... she will die.
			Maybe this is the way it's
			supposed to end.

OBI-WAN runs and jumps on the back of the REEK behind ANAKIN. Across the arena, the NEXU, having chewed up the ACKLAY, starts to advance toward them.

INT. COCKPIT, NABOO STARSHIP - DAY
ARTOO BEEPS

				C-3PO
			Yes, it has been rather a long
			time. Do you suppose something's
			happened to them?

ARTOO BEEPS and WHISTLES.

				C-3PO
				(continuing)
			Danger? Oh no, I shouldn't think
			so. It looks a very dull planet
			to me. They should be back
			shortly. Just stop worrying, Artoo.

EXT. GEONOSIS, EXECUTION ARENA - DAY
In the archducal box, amid the uproar, COUNT DOOKU feels a tap on his shoulder. He turns to see MACE WINDU standing behind him. COUNT DOOKU masks his surprise elegantly as he surveys the arena and sees JEDI KNIGHTS standing at every entrance and exit.

				COUNT DOOKU
			Master Windu, how pleasant of you
			to join us. You're just in time
			for the moment of truth. I would
			think these two new boys of yours
			could use a little more training.

				MACE WINDU
			Sorry to disappoint you, Dooku.
			This party's over.

MACE WINDU signals, and at stategic places around the arena there are sudden flashes of light as about ONE HUNDRED JEDI switch on their lightsabers. The crowd is suddenly silent. COUNT DOOKU'S lips curl in slight amusement.

				COUNT DOOKU
				(to Mace Windu)
			Brave, but stupid, my old Jedi
			friend. You're impossibly
			outnumbered.

				MACE WINDU
			I don't think so. One Jedi has to
			be worth a hundred Geonosians.

COUNT DOOKU looks around the great theater. His smile grows.

				COUNT DOOKU
			It wasn't the Geonosians I was
			thinking about. How well do you
			think one Jedi will hold up
			against a thousand battle droids?

COUNT DOOKU signals. THOUSANDS OF DROIDS start to pour into all parts of the arena.

MACE WINDU draws his lightsaber, JANGO FETT draws his guns and fires at MACE WINDU, who deflects the shots. JANGO FETT and MACE WINDU jump into the arena, where they fight. BOBA FETT wacthes his Dad and the Jedi Master fight. The battle beginss. GEONOSIANS fly away everywhere. DROIDS fire at JEDI, who deflect the bolts and cult down the DROIDS. The GEONOSIAN TROOPS fire ray guns that are more difficult for the JEDI to deflect.

The REEK and the NEXU are spooked by the battle. The REEK bucks the riders off its back and stampedes around the arena, trampling DROIDS and JEDI that have moved into its path. PADME picks up a discarded pistol and joins the fight. SEVERAL JEDI run to the center of the arena and toss lightsabers to OBI-WAN and ANAKIN.

Among the crowd, JEDI cut down swaths of GEONOSIANS and DROIDS. On the sand, JEDI fight, attacking DROIDS. OBI0WAN and ANAKIN swing their lightsabers, cutting DROIDS in half. PADME blasts away at DROIDS and GEONOSIANS.

INT. COCKPIT, NABOO STARSHIP
ARTOO whistles.

				C-3PO
			I don't hear anything.
				(Artoo beeps)
			You're scaring me! Stop imagining
			things!

EXT. GEONOSIS, EXECUTION ARENA - DAY
Among the tiers, JEDI are slowly being driven back. They have killed heaps of GEONOSIANS and have kncoked out piles of DROIDS, but sheer numbers are telling. Individual JEDI are being cut down or blasted/ The rest are retreating into the arena.

ANAKIN and PADME are back-to-back, fighting DROIDS and flying GEONOSIANS. MACE WINDU fights fiercely with JANGO FETT. Finally, the bounty hunter falls. His helmet goes flying, bouncing down the steps, tumbling and rolling, kicked here and there by random feet. The bounty hunter's body falls to the ground.

MACE WINDU runs to the center of the arena and fights back-to-back with OBI-WAN, as they swipe and mangle DROIDS.

				OBI-WAN
			Someone's got to - shut down -
			these droids.

				MACE WINDU
			Don't worry! It's being - taken
			care of!

EXT. GEONOSIS, FEDERATION STARSHIP - DAY
KI-ADI-MUNDI leads a raiding party of about TWENTY JEDI through the lines of parked Battle Starships. They cut a swath through masses of DROIDS until they arrive at the Command Starship. Some JEDI fall. The rest cut their way up the ramps and into the Command Ship.

INT. COMMAND FEDERATION STARSHIP, CORRIDORS - DAY
KI-ADI-MUNDI and teh surviving JEDI fight their way through the corridors of the Command Ship, deflecting laser bolts, slicing DROIDS.

INT. COMMAND FEDERATION STARSHIP, CONTROL BRIDGE - DAY
THEY burst onto the bridge and chop down the COMMAND DROIDS. The NEIMOIDIANS flee in all directions. KE-ADI-MUNDI leans over the control panel. He locates the illuminated master switch and punches down on it. It goes dark. Instantly, all the DROIDS on the Starship and all the DROIDS in the arena FREEZE!

There is a moment of stunned silence, then the JEDI CHEER. One the bridge, PLO KOON claps KI-ADI-MUNDI on the back.

				PLO KOON
			We've done it! Now we have a
			chance!

Suddenly, there is a harsh BEEPING SOUND. All the DROIDS on the Starship and all the DROIDS in the arena start fighting again! KI-ADI-MUNDI stares in disbelief and dismay.

				KI-ADI-MUNDI
			The system's off but they're still
			active. That's a new feature. They
			are independent of the control
			system.

EXT. GEONOSIS, EXECUTION ARENA - DAY
MACE WINDU, OBI-WAN, ANAKIN, PADME and an exhausted group of about TWENTY JEDI stand in the center of the arena surrounded by a ring of BATTLE DROIDS. The bloodied sand around them is strewn with the bodies of DEAD GEONOSIANS, SHATTERED DROIDS and JEDI.

At the foot of some steps, BOBA FETT finds his father's battered helmet. He picks it up.

KI-ADI-MUNDI and the SURVIVORS from the raiding party are herded into the arena by SUPERDROIDS. From the encircling tiers above, THOUSANDS OF BATTLE DROIDS level their weapons menacingly.

In the archducal box, COUNT DOOKU lifts his hand. The DROIDS lower their weapons. The COUNT calls out to the JEDI.

				COUNT DOOKU
			Master Windu!

Silence.

				COUNT DOOKU
				(continuing)
			You have fought gallantly. Worthy
			of recognition in the history
			archives of the Jedi Order. Now
			it is finished.
				(pauses briefly)
			Surrender - and your lives will be 
			spared.

				MACE WINDU
			We will not be hostages for you to
			barter with Dooku.

				COUNT DOOKU
			Then, I'm sorry, old friend. You
			will have to be destroyed.

The DROIDS raise their weapons. ANAKIN and PADME clasps hands tightly. COUNT DOOKU raises his hand to give the order to fire. PADME looks up suddenlt and whispers to ANAKIN.

				PADME
			Look!

Above, six Gunships are descending fast through the open area in the arena ceiling. They land in a cluster around the handful of JEDI. CLONE TROOPERS spill out and start firing at the DROIDS. There is a hellstorm of laserfire that bounces off the laser shields created by the Gunships. YODA appears at the door of one of the Gunships.

				YODA
			Come on - hurry! Hurry!

The SURVIVING JEDI dash to the Gunships and scramble in. MACE WINDU hangs on tight as the Gunship, firing all its weapons, rises out of the arena up and over the topmost rim.

EXT. GEONOSIS, TERRAIN OUTSIDE EXECUTION ARENA - DAY
The massed lines of parked Federation Starships and the DROIDS surrounding the arena, are themselves surrounded by thousands of Republic Starships, disgorging TENS OF THOUSANDS OF CLONE TROOPERS. Beyond, more Republic Starships are landing and spewing out troops.

INT. GUNSHIP NUMBER ONE - DAY
MACE WINDU stares at the incredible sight.

				YODA
			More battalions to the left.
			Encircle them we must, then
			divide.

The CLONE TROOPERS open fire with artillery. EXPLOSIONS wreck the parked Battle Starships. CLONE TROOPERS advance, firing at the massed DROIDS. FIGHTER DROIDS fly overhead, exchanging fire with the Gunships and JEDI fighters.

INT. COCKPIT, NABOO STARSHIP - DAY
THREEPIO and ARTOO see flashes outside of the ship, exploding everywhere.

				C-3PO
			I'm sure I heard something, this
			time. Didn't you? It's probably
			just a celebration

ARTOO lets out an EXHAUSTED BLEEP.

EXT. BATTLEFIELD, GEONOSIS LANDSCAPE - DAY
Gunship #2 skims the battlefield, firing down, deflecting answering fire from the droids.

INT. GUNSHIP NUMBER TWO - DAY
OBI-WAN, ANAKIN and PADME are at the open sides of the Gunship. CLONES fire down at the DROIDS below.

The Gunship slows, circling over a droid gun-emplacement. It blasts it, but suddenly the Gunship is rocked by a near miss. It lurches violently.

				OBI-WAN
			Hold on! Look over there...

Through the other side of the Gunship, they see a Geonosian Speeder racing past. In the open cockpit is the unmistakable figure of COUNT DOOKU.

				ANAKIN
			It's Dooku, go after him!

The PILOT starts to comply, but... there is a HUGE BLASTS, the ship lurches on its side, and PADME tumbles out.

				ANAKIN
				(continuing)
			Padme!!!

ANAKIN stares down in horror as PADME hits thr ground below.

				ANAKIN
				(continuing; to pilot)
			Put the ship down! Down!

				OBI-WAN
			No! Forget her. We have to go
			after Dooku.

				ANAKIN
			No we're not!! Land this ship!

				OBI-WAN
			Don't let your personal feelings
			get in the way. We've got a job to
			do.

Below, PADME hauls herself to her feet and waves for them to go after DOOKU.

				ANAKIN
			I don't care!.. Go back.

				OBI-WAN
			Anakin! She's all right! Look.

ANAKIN stares out to see PADME rescued by CLONE TROOPERS.

				OBI-WAN
				(continuing)
			Follow that speeder!

On the ground, PADME looks up at Gunship #2 as it speeds away after Count Dooku. OBI-WAN and ANAKIN follow the speeder to a Geonosian tower. The speeder decsends rapidly; the Gunship follows.

Count Dooku's speeder parks outside the tower; the Gunship parks next to it. OBI-WAN and ANAKIN leap down and run inside the tower.

INT. GEONOSIS, SECRET HANGER TOWER - LATE DAY
COUNT DOOKU throws switches on a control panel. His Interstellar Sail Ship is guarded by a SQUAD OF SUPER BATTLE DROIDS. The doors of the exit-port slide open.

				DROID CAPTAIN
			Your Excellency!

COUNT DOOKU turns as OBI-WAN and ANAKIN run in through the hanger doors. They draw their lightsabers. The DROIDS raise their weapons.

				COUNT DOOKU
			That won't be necessary, Captain.
			Stand down. And leave them to me.

The DROIDS lower their weapons and back off to the walls. COUNT DOOKU looks at OBI-WAN and ANAKIN with slight amusement.

				OBI-WAN
				(to Anakin)
			We move in together - you slowly
			on the...

				ANAKIN
			I'm taking him now!

				OBI-WAN
			Anakin, no!

				ANAKIN
			You'll pay for all the Jedi you've
			killed today, Dooku.

ANAKIN charges across the open space at COUNT DOOKU, who smiles faintly, watching him come. ANAKIN raises his lightsaber. At the last moment, COUNT DOOKU thrusts out an arm, and ANAKIN is lifted up, hurled across the room, and slammed into the opposite wall. He slumps to the foot of the wall, semi-conscious. COUNT DOOKU moves toward OBI-WAN

				COUNT DOOKU
			Kenobi, isn't it? As you can see,
			my Jedi powers are far beyond
			yours. Now, back down.

				OBI-WAN
			I don't think so.

OBI-WAN lifts his lightsaber. COUNT DOOKU smiles.

				COUNT DOOKU
			Ah, but if I must.

COUNT DOOKU draws his lightsaber. He and OBI-WAN start to circle each other.

				COUNT DOOKU
				(continuing)
			I have spent the last ten years
			learning to use the power of the
			Dark Side. It gives me infinitely
			greater power.

				OBI-WAN
			You will have to prove it.

OBI-WAN comes in fast, swinging at COUNT DOOKU'S head. DOOKU parries the cut easily. As they fight, it quickly becomes clear that DOOKU is the complete swordsman - elegant, graceful, classical - a master of the old style.

				COUNT DOOKU
			Grand Master Kenobi, you
			disappoint me. Yoda holds you in
			such high esteem.

COUNT DOOKU parried another cut.

				COUNT DOOKU
				(continuing)
			Surely you can do better...?
				(parries)
			No, I'm surprised. Has Jedi
			swordsmanship degenerated so
			quickly, or are you trying to make
			fun of me?
				(cuts)
			Which is it?

COUNT DOOKU thrusts. OBI-WAN steps back quickly, panting for breath.

				COUNT DOOKU
				(continuing)
			come, come, Master Kenobi. Put me
			out of my misery.

OBI-WAN takes a deep breath, gets a fresh grip on his lightsaber and comes in again. For a moment, he drives COUNT DOOKU back. Then Dooku's superior skill begins to tell again, and he forces OBI-WAN to retreat.

COUNT DOOKU increases the tempo of his attack. OBI-WAN is pushed to the limit to defend himself. DOOKU presses. His lightsaber flashes.

OBI-WAN is wounded in the shoulder, then the thigh. He stumbles back against the wall, trips, and falls. His lightsaber goes skittering across the floor.

COUNT DOOKU raises his lightsaber. OBI-WAN looks up helplessly. Dooku's lightsaber flashes down and CLASHES against - Anakin's lightsaber! COUNT DOOKU and ANAKIN stare eyeball to eyeball.

				COUNT DOOKU
				(continuing)
			That's brave of you, boy - but
			foolish. I would have thought
			you'd have learnt your lesson.

				ANAKIN
			I'm a slow learner.

And ANAKIN charges at COUNT DOOKU. The force of his attack catches the Count slightly off balance. Anakin's lightsaber flashes. COUNT DOOKU draws back, putting a hand to his arm. He takes the hand away and looks at the smear of blood whee Anakin has nicked him.

				COUNT DOOKU
			You have unusual powers, young
			Padawan. But not enought to save
			you this time.

				ANAKIN
			Don't bet on it!

				OBI-WAN
			Anakin!

OBI-WAN uses the Force to catch his lightsaber and he tosses it to ANAKIN. With TWO LIGHTSABERS, ANAKIN attacks. COUNT DOOKU parries and ripostes. It is no contest. ANAKIN is driven back against the wall. He loses one lightsaber. Finally COUNT DOOKU, in one flashing move, sends Anakin's arm, cut at the elbow, flying still gripping his lightsaber. ANAKIN drops to the ground in agony. COUNT DOOKU draws himself up to deliver the coup de grace.

Suddenly, the great doors slide open. The DROIDS turn fast, raising their weapons. Through the thick smoke, emerges the heroic figure of YODA. He stops on the smoke-filled threashold, FOUR DROIDS lined up on either side of him, guns pointed.

Before the DROIDS can get off a shot, YODA raises his hand, and the DROIDS are flung against the far walls and crash to the floor in heaps of smoking metal.

Silence. COUNT DOOKU steps away from ANAKIN to face the Jedi Grand Master. His lightsaber whirls in a formal salute.

				COUNT DOOKU
			Master Yoda. At last we shall
			know who is the most powerful.

YODA draws a miniature lightsaber out of his cane. He salutes formally.

				YODA
			Count Dooku. No interest in
			contests, do I have.

COUNT DOOKU charges across the space at YODA. He rains down blows upon the tiny figure. YODA doesn't budge an inch. For the first part of the contest, he parries every cut and thrust that Dooku aims. Nothing the great swordsman tries gets through. His energy drains. His strokes become feebler, slower.

YODA attacks! He flies forward. COUNT DOOKU is forced to retreat. Wprds are insufficient to describe the range and skill of Yoda's speed and swordplay. His lightsaber his a humming blur of light.

Count Dooku's lightsaber is sent cartwheeling from his hand. He staggers back, gasping and spent, against the control panel. YODA jumps onto DOOKU'S shoulders, and is about to drive the lightsaber into the top of the Count's head.

				YODA
				(continuing)
			The end for you, Count, this is.

				COUNT DOOKU
			...Not yet...

COUNT DOOKU raises his arms and knocks YODA off his shoulders and then, with all his might, he uses the Force to pull on one of the cranes in the hanger. It comes crashing down on OBI-WAN and ANAKIN. But in the blink of and eye, YODA is under the crane, holding it up, using the Force. YODA closes his eyes and concentrates.

ANAKIN is unconscious, and OBI0WAN tries toget out from under the crane. The fallen crane trembles and starts to life. Behind it, the sound of the Sail Ship's engines are heard starting up.

YODA concentrates harder. Slowly, the crane rises. The SOUND OF THE ENGINES increases. YODA exerts every scrap of his powers. The crane lifts clear of ANAKIN and is thrown to the ground. DOOKU'S Sail Ship takes off. OBI-WAN and ANAKIN struggle to the exhausted YODA, but it's too late. The Sail Ship rises into the air and flies away. PADM� and a CLONE CAPTAIN with about TEN TROOPERS appear in the doorway.

				PADM�
			Anakin!

PADM� runs too him and throws her arms around him. ANAKIN is barely able to stand up. The CLONE CAPTAIN marches up to YODA, stops, and salutes smartly.

				CLONE CAPTAIN
			Resistance is at an end, General.
			What are your orders ?

YODA looks at him and sighs.

EXT. CORUSCANT, OLD TOWN - DAWN
COUNT DOOKU'S Interstellar Sail Ship glides through a deserted, burned-out part of Coruscant. COUNT DOOKU manoeuvres the ship into one of the empty buildings and lands.

INT. CORUSCANT, SECRET LANDING PLATFORM - DAWN
The ramp lowers. COUNT DOOKU emerges and walks to where the hooded figure of DARTH SIDIOUS stands waiting. COUNT DOOKU bows.

				COUNT DOOKU
			The Force is with us, my Master.

				DARTH SIDIOUS
			Welcome home, Lord Tyranus. You have
			done well.

				COUNT DOOKU
			I bring you good news, my Lord.
			The war has begun.

				DARTH SIDIOUS
			Excellent. 
			 	(smiling)
			Everything is going as planned.

EXT. CORUSCANT, JEDI TEMPLE - SUNSET
The beautiful temple basks in the red glow of the setting sun.

INT. JEDI TEMPLE, COUNCIL CHAMBER - SUNSET

				MACE WINDU
			Where is your apprentice?

				OBI-WAN
			On his way back to Naboo. He is
			escorting Senator Amidala home.

They are standing, looking out through the tall windows at the great plaza below. YODA sits in his chair.

				OBI-WAN
				(continuing)
			I must admit without the clones,
			it would not have been a victory.

				YODA
			Victory? Victory, you say?

OBI-WAN turns and looks at the sad little Jedi sitting in the Council Chamber. Apart from KI-ADI-MUNDI and PLO KOON, who is wounded, the Chamber is empty.

				YODA
				(continuing)
			Not victory, a defeat, it was...
			Master Obi-Wan. Begun, the Clone
			War has!

EXT. NABOO LAKE RETREAT, LODGE, GARDEN - LATE DAY
In a rose-covered arbor overlooking the sparkling late, ANAKIN and PADME stand before a NABOO HOLY MAN.

THREEPIO and ARTOO stand by, watching, as the HOLY MAN blesses the happy couple and, amid gently falling rose petals, ANAKIN and PADME kiss.

EXT. CORUSCANT, MILITARY STAGING AREA, BALCONY - LATE DAY
PALPATINE, JAR JAR, BAIL ORGANA and the OTHER SENATORS, with TWO ROYAL GUARDS, stand looking down at the square below.

TENS OF THOUSANDS OF CLONE TROOPS are drawn up in a strict formation or move forwards in near files to climb the ramps of the Military Assault Ships.

On the balcony, PALPATINE'S expression is deeply sad. Everyone watches comberly as, in the square, loaded Assault Ships take off. Other land immediately in their place. The sky above is thick with transports. CLONE TROOPS march and board the Ships.

The Great Clone War has begun...

FADE OUT:

THE END