STAR WARS EPISODE 3: REVENGE OF THE SITH SCRIPT

George Lucas


1 EXT. SPACE

A long time ago in a galaxy far, far away.

A vast sea of stars serves as the backdrop for the Main Title, followed by a rollup, which crawls into infinity.

War! The Republic is crumbling under attacks by the ruthless Sith Lord, Count Dooku. There are heroes on both sides. Evil is everywhere.

In a stunning move, the fiendish droid leader, General Grievous, has swept into the Republic capital and kidnapped Chancellor Palpatine, leader of the Galactic Senate.

As the Separatist Droid Army attempts to flee the besieged capital with their valuable hostage, two Jedi Knights lead a desperate mission to rescue the captive Chancellor. . . .

PAN DOWN to reveal a REPUBLIC ATTACK CRUISER. Continue to PAN with the Cruiser as TWO JEDI STARFIGHTERS enter and head toward an enemy Battle Cruiser. TRUCK with the Jedi Fighters as they maneuver in unison, dodging flack and enemy laser fire. R2-D2 is on Anakin's ship. R4-P17 is on Obi-Wan's ship. A giant space battle is revealed as the tiny Jedi ships continue their assault in a synchronous ballet.

2 INT. OBI-WAN'S STARFIGHTER COCKPIT-SPACE

OBI-WAN bounces through the flack with a frown. His ship rocks violently.

3 INT. ANAKINS STARFIGHTER COCKPIT-SPACE

ANAKIN smiles as he blasts a TRADE FEDERATION DROID DROP FIGHTER.

ANAKIN: There isn't a droid made that can out fly you, Master, and no other way to get to the Chancellor . . .

OBI-WAN: Look out, four droids inbound . . .

4 EXT. CORUSCANT-SPACE BATTLE

The TWO JEDI FIGHTERS swerve in unison as FOUR TRADE FEDERATION DROID DROP FIGHTERS attack. After several clever moves by the Jedi, two of the FEDERATION DROID DROP FIGHTERS collide with each other in a ball of flame.

5 INT. OBI-WAN'S STARFIGHTER COCKPIT-SPACE

OBI-WAN struggles to maintain control of his ship.

OBI-WAN: We've got to split them up.

ANAKIN: Break left, fly through the guns on that tower.

OBI-WAN flies to the left of a huge tower on a REPUBLIC CRUISER. The TWO DROID DROP FIGHTERS follow.

OBI-WAN: Easy for you to say . . . why am I always the bait?

ANAKIN: Don't worry. I'm coming around behind you.

OBI-WAN deftly maneuvers around a large Starship's superstructure, but the TWO DROID FIGHTERS stay on his tail, BLASTING him with intense laser fire.

OBI-WAN: Anakin, they're all over me!

ANAKIN: Dead ahead! Closing . . . lock onto him, Artoo . . .

ARTOO BEEPS his reply as ANAKIN swoops in for the kill. ANAKIN BLASTS one of the DROID DROP FIGHTERS. It EXPLODES.

ANAKIN: (continuing, laughs) We got him, Artoo!

ANAKIN BLASTS away at the second DROID DROP FIGHTER as ARTOO BEEPS an angry warning.

ANAKIN: I copy, Artoo.

OBI-WAN: I'm going down on the deck.

ANAKIN: Good idea ... I need some room to maneuver.

OBI-WAN dives toward the surface of one of the larger TRADE FEDERATION BATTLESHIPS and is forced to fly through a maelstrom of laser flack. He skims the surface, followed by the DROID DROP FIGHTER, which is followed by ANAKIN.

ANAKIN: (continuing) Cut right. Do you hear me?! Cut right. Don't let him get a handle on you. Come on, Artoo, lock on! Lock on!

ARTOO BEEPS. The crosshairs merge on the DROID DROP FIGHTER.

OBI-WAN: Hurry up! I don't like this!

OBI-WAN flies through a narrow gap between two towers on a Battleship. The DROID DROP FIGHTER hits one of Obi-Wan's wings with a laser blast, and parts of the ship go flying around Obi-Wan's Astro Droid, ARFOUR.

OBI-WAN: (continuing) Ouch!

R-4 BEEPS a blue streak.

OBI-WAN: (continuing) Don't even try to fix it, Arfour. I've shut it down.

ANAKIN: We're locked on ... we've got him . . .

ANAKIN drops in behind the DROID DROP FIGHTER and blows him apart. ARTOO SQUEALS with delight.

ANAKIN: (continuing) Yeah! We got him . . . good going, Artoo.

OBI-WAN: Next time you're the bait . . . Now let's find the Command Ship and get on with it ...

R-4 BEEPS a blue streak.

ANAKIN: Lock onto them, Artoo. Master, General Grievous's ship is directly ahead.

ARTOO BEEPS a reply, and it reads out in Anakin's cockpit.

ANAKIN: (continuing) The one crawling with vulture droids.

6 INT. OBI-WAN'S STARFIGHTER COCKPIT-SPACE

OBI-WAN: I see it. Oh, this is going to be easy.

Ahead is a TRADE FEDERATION CRUISER with batlike DROID VULTURE FIGHTERS stalking around on the hull. The VULTURE FIGHTERS transform into flight configuration, lift off the CRUISER, and attack the JEDI STARFIGHTERS.

ANAKIN: Come on, Master.

OBI-WAN: Not this time. There's too much at stake. We need help. Odd Ball, do you copy?

ODD BALL: (OS) Copy, Red Leader.

OBI-WAN: Mark my position and form your squad up behind me . . .

7 INT. ODD BALL'S FIGHTER COCKPIT-SPACE

ODD BALL: We're on your tail, General Kenobi. Set S-foils in attack position.

The protective ray shield lowers on the main hangar of the TRADE FEDERATION CRUISER, and six new DROID TRI-FIGHTERS emerge and join the DROID VULTURE FIGHTERS heading toward the Jedi. The JEDI STARFIGHTERS extend the stability foils on the ends of their wings.

8 INT. ANAKIN'S FIGHTER COCKPIT-SPACE

ANAKIN: This is where the fun begins. Ten Vulture Droids straight ahead, coming down the left side.

ARTOO BEEPS a worried message.

OBI-WAN: Add five Tri-fighters on the right . . .

ANAKIN: I'm going head to head. See you.

OBI-WAN: Take it easy, Anakin.

Four Clone Fighters move into formation behind the Jedi.

ODD BALL: I'm on your right, Red Leader.

ANAKIN: Incoming!!

ARTOO SQUEALS as five DROID TRI-FIGHTERS pass by at high speed on the right.

OBI-WAN: Five more on the right!

Four more VULTURE DROID FIGHTERS pass at high speed from the left. All hell breaks loose. OBI-WAN and ANAKIN continue to fly in unison, backing up each other. ARTOO SQUEALS.

ANAKIN: Here we go.

The Jedi ships split up and make a quick loop around the DROID TRI-FIGHTERS, ending up behind them. BLASTING away. The DROID TRI-FIGHTERS EXPLODE.

OBI-WAN: I'm going high and right.

ANAKIN: Hang on. There are four more of them.

OBI-WAN: Stay with me . . . swing back and right . . . help me engage. Back off ... Let them pass between us.

ANAKIN: I'm coming around. I'm coming around on your tail.

OBI-WAN: All right, engage . . . and hurry. These droids are all over me like a rash.

In one incredible move, ANAKIN swings in behind the DROID TRI-FIGHTERS, blowing them away one by one until there is only one left. ARTOO CHIRPS.

ARTOO lets out a HOWL as ANAKIN accelerates past the last DROID TRI-FIGHTER, slams on his brakes, flips the Fighter around, and BLASTS the Fighter from the front. ARTOO BEEPS frantically as they fly through the debris of the destroyed ships. ANAKIN looks behind him.

ANAKIN: How many back there. Artoo? (Artoo beeps) Three . . . (continuing) Four . . . that's not good.

OBI-WAN: Anakin, you have four on your tail.

ANAKIN: I know. I know!

OBI-WAN: Four more closing from your left.

ANAKIN: I know. I know!

OBI-WAN: Break right and go high.

ANAKIN: I'm going low and left.

Obi-Wan shakes his head.

OBI-WAN: (to himself) He still has much to learn.

ANAKIN swoops low and skims across a TRADE FEDERATION BATTLESHIP, dodging flack as ARTOO bounces along, trying to get out a sentence.

ANAKIN: Hang on, Artoo. Obi-Wan, do you copy? I'm going to pull them through the needle . . .

OBI-WAN: Too dangerous. First Jedi rule: "Survive."

ANAKIN: Sorry, no choice. Come down here and thin them out a little.

OBI-WAN drops in behind the DROID VULTURE FIGHTERS chasing Anakin. ARFOUR BEEPS to OBI-WAN.

OBI-WAN: Just keep me steady . . . hold on ... not yet. . . now break left.

OBI-WAN fires as he swings across the back of the VULTURE DROIDS, BLASTING four of them away. ANAKIN heads for a trench along the surface of one of the Trade Federation Battleships. He flies into the trench, which ends in a conning tower with a small slit between two main struts.

OBI-WAN: (continuing) You'll never get through there, Anakin. It's too tight.

ARTOO BEEPS nervously.

ANAKIN: Easy, Artoo . . . we've done this before.

OBI-WAN: Use the Force, think yourself through, the ship will follow.

ARTOO SQUEALS in a panic. On the view screen Artoo's squeal reads out, "WE'RE NOT GOING TO MAKE IT."

ANAKIN: Wrong thought, Artoo.

ANAKIN slips through the narrow gap. The trailing VULTURE DROID FIGHTERS CRASH.

ANAKIN: (continuing) I'm through.

OBI-WAN continues to fire on the VULTURE DROID FIGHTERS, driving them into the EXPLOSION.
A CLONE fighter is hit and explodes, spewing debris. The CLONE PILOT spins off into space.
Finally, OBI-WAN peels off and swings around, pulling up alongside ANAKIN. CLONE FIGHT SQUAD SEVEN battles the DROIDS.

ODD BALL: There are too many of them.

CLONE PILOT 2: I'm on your wing. Break left. Break left. They're all over me. Get them off my . . .

ANAKIN: I'm going to go help them out!

OBI-WAN: No, no! They are doing their job so we can do ours. Head for the Command Ship!

Another CLONE fighter is hit, bursts into flames, and spins off into space. A VULTURE DROID FIGHTER raises its head to locate its target and fires missiles at them.

ANAKIN: Missiles! Pull up!

ANAKIN and OBI-WAN break right and left, and the missiles follow them. ANAKIN does a barrel roll spin, causing the missiles following him to collide and EXPLODE. Two missiles continue to chase OBI-WAN. He banks sharply to the right, then to the left, causing one of the missiles to overshoot.

OBI-WAN: They overshot us . . .

The second missile streaks next to Obi-Wan�s Fighter and EXPLODES. Obi-Wan's ship rocks, and R-4, SCREAMS as the Starfighter rips through the explosion. Debris flies all around them.

ANAKIN: They're coming around!

OBI-WAN: All right, Arfour. No, no. Nothing too fancy.

ANAKIN: Surge all power units. Artoo! Stand by the reverse thrusters.

ANAKIN spins his starfighter. The missiles spin and collide.

ANAKIN: We got 'em. Artoo!

Two missiles continue to track Obi-Wan.

OBI-WAN: Flying is for droids.

Suddenly, OBI-WAN shudders, and his ship starts to plummet toward the surface of the Trade Federation Cruiser. The trailing missiles fly into what looks like debris, and detonate. Five silver balls fly out of the debris and attach themselves to the ship. The balls pop open, revealing SMALL BUZZDROIDS that begin to crawl across the surface like spiders.

OBI-WAN: (continuing) I'm hit! Anakin?

ANAKIN: I see them . . . Buzz Droids.

The BUZZ DROIDS crawl across Obi-Wan's ship and start to tear it apart. SPARKS ERUPT where the BUZZ DROIDS break into the wiring. One of the BUZZ DROIDS goes after ARFOUR.

OBI-WAN: Arfour, be careful. You have one . . .

ARFOUR's head gets ripped off and flies away.

OBI-WAN: Oh dear. They're shutting down all the controls.

ANAKIN: Move to the right so I can get a clear shot at them.

OBI-WAN: The mission. Get to the Command Ship. Get the Chancellor! I'm running out of tricks here.

ANAKIN moves into position just off Obi-Wan's left side and angles his ship so his guns are pointing at the DROIDS crawling over Obi-Wan�s Starfighter. ANAKIN fires and vaporizes the TWO BUZZ DROIDS, along with the left wing of Obi-Wan's ship.

OBI-WAN: (continuing) In the name of ...

ANAKIN: Steady . . . steady . . .

OBI-WAN: Anakin, hold your fire . . . hold your fire. You're not helping here.

ANAKIN: I agree, bad idea. Swing right . . . ease over . . . steady . . .

OBI-WAN: Wait . . . wait . . . I can't see a thing! My cockpit's fogging. They're all over me, Anakin.

ANAKIN: Move to the right.

OBI-WAN: Hold on, Anakin. You're going to get us both killed! Get out of here. There's nothing more you can do.

ANAKIN: I'm not leaving without you, Master.

ANAKIN moves his ship next to OBI-WAN's and tries to physically knock the BUZZ DROIDS off. There are five left. He manages to get one off, but badly dents OBI-WAN's ship in the process. One of the BUZZ DROIDS tears apiece off of the front of Obi-Wan's ship. Flames burst out, and more smoke billows out, obscuring the Jedi's view.

ANAKIN knocks off three of the BUZZ DROIDS and the fourth crawls out onto Anakin's ship and starts attacking ARTOO. ARTOO fights the BUZZ DROID.

OBI-WAN: Blast it ... I can't see . . . my controls are gone.

ANAKIN: Get 'em, Artoo. Watch out!

OBI-WAN: Artoo, hit the buzz droid's center eye.

ARTOO extends an arm and aims a stream of electricity at the swerving BUZZ DROID. The BUZZ DROID is hit squarely in the eye and falls off the ship.

ANAKIN: Yeah, you got him!

OBI-WAN: Great, Artoo.

ANAKIN: Stay on my wing . . . the General's Command Ship is dead ahead. Easy . . . pull up ... Head for the hangar.

OBI-WAN: Have you noticed the shields are still up?

ANAKIN: Oh?!? Sorry, Master.

ANAKIN streaks ahead of OBI-WAN's disintegrating Jedi Fighter and blasts the shield generator. It SPARKS and EXPLODES.

OBI-WAN: Oh, I have a bad feeling about this.

9 INT. MAIN HANGAR-TRADE FEDERATION CRUISER

The shield door drops away, and OBI-WAN crashes on the deck of the hangar bay, engulfed in a FANTAIL OF SPARKS. A set of blast doors starts SLAMMING shut across the hangar opening, as material is sucked into space.

ANAKIN maneuvers around the oncoming junk and flies into the hangar just as the blast doors SLAM shut.
OBI-WAN ignites his light saber and cuts his way out of the cockpit. He jumps dear just as his ship EXPLODES. BATTLE DROIDS rush at him from all directions.

ANAKIN jumps out of his ship and cuts his way through the BATTLE DROIDS to where OBI-WAN is fighting. ARTOO pops out of the ship and follows ANAKIN.

OBI-WAN: Artoo, locate the Chancellor.

ANAKIN: Tap into the ship's computers.

They cut down the last of the droids and follow ARTOO over to a computer wall socket. The two JEDI fight off FOUR MORE DROIDS as ARTOO tries to find the Chancellor. Finally, a HOLOGRAM of the Trade Federation ship appears.

OBI-WAN: The Chancellor's signal is coming from right there. The observation platform at the top of that spire.

ANAKIN: I sense Count Dooku . . .

OBI-WAN: I sense a trap.

ANAKIN: Next move?

OBI-WAN: Spring the trap.

The JEDI start to leave; ARTOO follows. The JEDI stop and turn to ARTOO.

ANAKIN: Artoo, go back. I need you to stay with the ship.

OBI-WAN: Here, take this, and wait for orders.

OBI-WAN tosses the comlink to ARTOO.

10 INT. BRIDGE-TRADE FEDERATION CRUISER

GENERAL GRIEVOUS enters the bridge of the TRADE FEDERATION cruiser followed by his TWO BODYGUARDS. He walks to the front of the bridge and stands in front of the NEIMOIDIAN CAPTAIN.

GENERAL GRIEVOUS: What's the situation, Captain?

CAPTAIN: TWO Jedi have landed in the main hangar bay.

GENERAL GRIEVOUS: Just as Count Dooku predicted.

11 INT. HANGAR-TRADE FEDERATION CRUISER

ANAKIN and OBI-WAN head for the elevator. A door opens in the hallway and two of GENERAL GRIEVOUS's BODYGUARDS confront the JEDI.

BODYGUARD I: General Kenobi, Anakin Skywalker. We've been waiting for you.

OBI-WAN: We are here to relieve you of Chancellor Palpatine, not join him.

As a dozen more droids join the group, the JEDI ignite their lightsabers and stand back-to-back.

OBI-WAN: Anakin. . .

ANAKIN: Ready.

ANAKIN and OBI-WAN use their lightsabers and cut a large circle in the floor.

12 INT. GENERATOR ROOM-TRADE FEDERATION CRUISER

The TWO JEDI cut their way down several floors into a large generator room. Huge EXPLOSIONS outside the ship have caused several large pipes overhead to break, and fluid is spewing everywhere. The Jedi get up and turn off their light sabers. ANAKIN dips his hand into the fluid and sniffs it.

OBI-WAN: . . . fuel. The slightest charge from our sabers will send this ship into oblivion. That's why they've stopped shooting.

ANAKIN: Well then, we're safe for the time being.

OBI-WAN: Your idea of safe is not the same as mine.

They run, EXPLOSIONS rattle the ship, and pipes continue to burst around them, spilling more fuel into the hallway. At the far end, SIX SUPER BATTLE DROIDS drop into the fuel. The SOUNDS OF SHIELD DOORS CLOSING AND LOCKING ECHO throughout the hallway. They pass several large power generators, which are topped with SPARKING excess power dischargers.

ANAKIN: They're sealing this section off.

OBI-WAN: Six droids coming our way!

The last of the DOORS CAN BE HEARD CLOSING in the distance.

ANAKIN: Keep moving. There must be vents . . . This way.

They move along a wall. ANAKIN climbs up the side to a small vent. The fuel gets closer to the SPARKING dischargers.

OBI-WAN: We'll never get through that. It's too small!

They move toward a second vent. OBI-WAN is swimming in the fuel as it reaches to within a couple yards of the ceiling. ANAKIN feels along the ceiling and finds another smaller vent. He closes his eyes and tries to sense an opening, then he moves on. OBI-WAN is forced into hand-to-hand combat with one of the SUPER BATTLE DROIDS. It pulls the Jedi under the fuel. Just before he is about to drown, OBI-WAN disables the SUPER BATTLE DROID by pushing him into an exhaust pipe.

The fuel is up to the Jedi's chins. ANAKIN finds a very, very small metal grate, then pounds on it until the tiny grate breaks loose.

ANAKIN: I found our escape vent.

OBI-WAN: Anakin, this is no time for jokes. We're in serious trouble here.

ANAKIN: Only in your mind. My Master. Look, no structure. . . .

ANAKIN grabs the side of the tiny hole and gives it a big yank, ripping a large panel loose revealing a "man-sized" work shaft. They scramble through it as the DROIDS swim closer.

13 INT. VENT SHAFT-TRADE FEDERATION CRUISER

The TWO JEDI pull themselves through the narrow vent shaft until they reach a small hatch in the side of the tube.

ANAKIN: Here's a way out.

As the SUPER BATTLE DROIDS reach the opening in the ceiling and the fuel gets to within a few feet of the power generator sparks, the JEDI work the keyboard on the pressure lock, opening the latch.

14 INT. SMALL PASSAGEWAY-TRADE FEDERATION CRUISER

The TWO JEDI climb into a small passageway and slam the hatch shut. They make their way through the ever-shrinking shaft until they reach the end.

15 INT. HALLWAY-TRADE FEDERATION CRUISER

A hatch opens in one of the main hallways of the Trade Federation Cruiser, and the JEDI squeeze out, SLAMMING the hatch. Behind them, ANAKIN seals the hatch with his laser sword.

OBI-WAN: That won't hold when the fuel hits those power dischargers.

ANAKIN: The blast will break the hull. This side's pressurized.

OBI-WAN: You still have much to learn, Anakin.

16 INT. VENT SHAFT-TRADE FEDERATION CRUISER

The SUPER BATTLE DROIDS climb up the vent shaft. SUPER BATTLE DROID R77 and SEVERAL OTHER DROIDS wait in the generator room as the fuel continues to rise toward the power discharger.

SUPER BATTLE DROID R77: I have a bad feeling about this.

17 INT. GENERATOR ROOM-TRADE FEDERATION CRUISER

The fuel hits the SPARKING power discharger, and there is a HUGE EXPLOSION.

18 EXT. TRADE FEDERATION CRUISER-BATTLE

A GREAT EXPLOSION and a flaming gas cloud spray out of the side of the Federation Cruiser.

19 INT. HALLWAY-TRADE FEDERATION CRUISER

A large bulge appears in the wall around the sealed hatch as the EXPLOSION hits. OBI-WAN jumps back, then stands amazed.

OBI-WAN: All right, you win. I have much to learn. Let's go!

ANAKIN grins at OBI-WAN, and they run down the hallway.

20 INT. WIDE HALLWAY-TRADE FEDERATION CRUISER

The two JEDI wait for an elevator to arrive. They turn around and see they are face to face with THREE DESTROYER DROIDS. The DROIDS start blasting away. Anakin deflects the bolts. OBI-WAN frantically pushes the elevator button several more times.

ANAKIN: Destroyers!!

Finally the door opens, and they rush inside under a hail of laser bolts. The elevator door slides shut. The JEDI turn to see BATTLE DROIDS standing behind them.

BATTLE DROID: Drop your weapons! I said drop 'em.

The JEDI activate their light sabers and destroy all the BATTLE DROIDS.

21 INT HANGAR-TRADE FEDERATION CRUISER

R2-D2 notices two SUPER BATTLE DROIDS entering the hangar. He moves and hides behind a Jedi Starfighter.

22 INT. ELEVATOR-TRADE FEDERATION CRUISER

The elevator begins to move and screeches to a stop.

OBI-WAN: Did you press the stop button?

ANAKIN: No, did you?

OBI-WAN: No!

ANAKIN: Well, there's more than one way out of here.

ANAKIN ignites his laser sword.

OBI-WAN: We don't want to get out, we want to get moving. Artoo . . . Artoo. Do you copy? Activate elevator . . . (looks at control panel) . . . 31174 . . .

ANAKIN cuts a hole in the elevator ceiling.

23 INT MAIN HANGAR-TRADE FEDERATION CRUISER

TWO SUPER BATTLE DROIDS are inspecting the Jedi starfighters. They overhear Obi-Wan's voice over the comlink and are distracted.

SUPER BATTLE DROID 1: What's that?

SUPER BATTLE DROID 2: Get back to work. It's nothing.

24 INT. ELEVATOR-TRADE FEDERATION CRUISER

OBI-WAN: Artoo?

ANAKIN climbs through the hole in the ceiling of the elevator.

OBI-WAN: (continuing) Always on the move.

OBI-WAN continues to talk on the comlink. Artoo quietly beeps a reply.

25 INT MAIN HANGAR-TRADE FEDERATION CRUISER

ARTOO tries to muffle the comlink as the TWO SUPER BATTLE DROIDS try to figure out where the voices are coming from. ARTOO extends an arm and plugs into a computer interface.

OBI-WAN: (OS) Artoo, switch on the comlink. Artoo, do you hear me? Artoo, we gave you a job to do! Artoo.

26 INT. ELEVATOR SHAFT-TRADE FEDERATION CRUISER

Suddenly, the elevator plummets down the shaft. ANAKIN quickly jumps and grabs onto the hallway entry door. He watches as the elevator recedes down the shaft and disappears. ANAKIN struggles to keep his grip on the closed door as SPARKING wires rain down on him.

27 INT. ELEVATOR-TRADE FEDERATION CRUISER

The elevator starts to descend rapidly.

OBI-WAN: Stop, stop! Artoo, we need to be going up.

28 INT. ELEVATOR SHAFT-TRADE FEDERATION CRUISER

Anakin struggles to hang on to the narrow edge of the elevator shaft. The door to the elevator shaft is pried open, and TWO BATTLE DROIDS appear in the doorway and look down at ANAKIN. They point their guns at him.

DROID 1: Hands up, Jedi! Don't move.

DROID 2: Roger, roger.

29 INT. MAIN HANGAR-TRADE FEDERATION CRUISER

The TWO SUPER BATTLE DROIDS overhear OBI-WAN's comlink messages to ARTOO.

SUPER BATTLE DROID 1: There it is again.

OBI-WAN: (OS) Artoo, do you copy? Artoo, do you hear me? Artoo, we need to be going up, not down.

30 INT. ELEVATOR-TRADE FEDERATION CRUISER

The elevator races down as OBI-WAN holds on.

OBI-WAN: Stop. Artoo! We need to go up! Stop, stop!

The elevator stops with a jolt. OBI-WAN falls to the floor.

31 INT. MAIN HANGAR-TRADE FEDERATION CRUISER

The TWO SUPER BATTLE DROIDS see ARTOO and walk toward the little droid.

SUPER BATTLE DROID 1: Hey you!

ARTOO plugs into the interface again and the elevator shoots up.

32 INT. ELEVATOR-TRADE FEDERATION CRUISER

OBI-WAN stands up after having fallen in the elevator.

OBI-WAN: Now, that's better . . .

33 INT. MAIN HANGAR-TRADE FEDERATION CRUISER

ARTOO is held up by TWO SUPER BATTLE DROIDS, who chuckle as the little Astro Droid curses and swings at them.

SUPER BATTLE DROID 1: You stupid little astro droid!

34 INT. ELEVATOR SHAFT-TRADE FEDERATION CRUISER

ANAKIN looks down and sees the elevator heading toward him at a high rate of speed. He looks at the BATTLE DROIDS leaning over him with their guns pointed at him. He calculates for a moment, then gives himself a push and flips himself up into the elevator shaft.

Before ANAKIN can arc into a descent down the shaft, the elevator races up through the shaft, cutting the DROIDS in two. ANAKIN lands on the elevator and quickly drops back through the hole in the ceiling. OBI-WAN is startled and ignites his lightsaber.

OBI-WAN: Oh, it's you . . .

35 INT. MAIN HANGAR-TRADE FEDERATION CRUISER

ARTOO activates his oil hose and sprays the SUPER BATTLE DROIDS. The SUPER BATTLE DROIDS slip on the oil.

36 INT. ELEVATOR SHAFT-TRADE FEDERATION CRUISER

ANAKIN: What was that all about?

OBI-WAN: Well, Artoo has been . . .

ANAKIN: No loose wire jokes . . . He's doing the best he can.

OBI-WAN: Did I say anything?

ANAKIN: He's trying!

OBI-WAN: I didn't say anything!

37 INT. MAIN HANGAR-TRADE FEDERATION CRUISER

ARTOO ignites his arm rockets and shoots out of their grip, spraying them both with oil and setting them on fire. The SUPER BATTLE DROIDS slip and slide until they fall, smoldering. ARTOO rolls away.

38 INT. GENERAL'S QUARTER'S-TRADE FEDERATION CRUISER

The elevator door opens and the TWO JEDI carefully make their way into the main room of the General's Quarters.
At the far end sits SUPREME CHANCELLOR PALPATINE. ANAKIN and OBI-WAN move toward the CHANCELLOR.
As they get closer to PALPATINE, they see a very distressed look on the Chancellor's face.

OBI-WAN: (bows) Chancellor.

ANAKIN: Are you all right?

PALPATINE: (quietly) Count Dooku.

PALPATINE makes a small gesture with his hand. OBI-WAN and ANAKIN turn around. The elevator DOORS CAN BE HEARD OPENING AND CLOSING as COUNT DOOKU strides into the room. He is above the Jedi, standing on a balcony, with two SUPER BATTLE DROIDS. The Jedi turn to see him. He looks down on the Jedi.

OBI-WAN: (quietly to Anakin) This time we will do it together.

ANAKIN: I was about to say that.

COUNT DOOKU jumps down to the main level.

PALPATINE: Get help! You're no match for him. He's a Sith Lord.

OBI-WAN: Chancellor Palpatine, Sith Lords are our specialty.

OBI-WAN and ANAKIN throw off their cloaks and ignite their lightsabers.

COUNT DOOKU: Your swords, please, Master Jedi. We don't want to make a mess of things in front of the Chancellor.

OBI-WAN and ANAKIN move toward DOOKU.

OBI-WAN: You won't get away this time, Dooku.

OBI-WAN and ANAKIN charge COUNT DOOKU. A great sword fight ensues.

COUNT DOOKU: I've been looking forward to this.

ANAKIN: My powers have doubled since the last time we met, Count.

COUNT DOOKU: Good. Twice the pride, double the fall.

DOOKU lunges at the JEDI and they fall back . . .

COUNT DOOKU: (continuing) Your moves are clumsy, Kenobi . . . too predictable. You'll have to do better.

As the battle proceeds, OBI-WAN and COUNT DOOKU are tired. ANAKIN is stronger as he becomes angry. ANAKIN continues to drive the attack on DOOKU. COUNT DOOKU throws OBI-WAN back using the Force.
ANAKIN and COUNT DOOKU move up the stairs. As they reach the upper landing of the General's Quarters, ANAKIN leaps over COUNT DOOKU. OBI-WAN reaches the top of the stairs, destroying TWO SUPER BATTLE DROIDS. COUNT DOOKU holds OBI-WAN in the air using the Force as he turns and kicks ANAKIN out of frame. OBI-WAN is choking.
ANAKIN hits the archway.
DOOKU sends OBI-WAN flying. The Jedi tumbles to the lower level unconscious. COUNT DOOKU spins around again and, using the Force, causes a section of the balcony to drop onto OBI-WAN. ANAKIN spins and kicks COUNT DOOKU, sending him over the balcony. ANAKIN Jumps, following him down to the main floor. COUNT DOOKU and ANAKIN continue the fight.

COUNT DOOKU: (continuing) I sense great fear in you, Skywalker. You have hate, you have anger, but you don�t use them.

Anakin regains his composure and attacks COUNT DOOKU as the Dark Lord continues his spin to meet him head on. Their fighting becomes even more intense.
Anakin attacks COUNT DOOKU with a new ferociousness.

39 INT. GENERAL'S QUARTERS-TRADE FEDERATION CRUISER

Anakin and Dooku continue their fight. It is intense! Finally, in one last energized charge, ANAKIN cuts off COUNT DOOKU's hands. The Jedi catches the lightsaber as it drops from the severed Sith Lord's hand. COUNT DOOKU stumbles to the floor as ANAKIN puts the two lightsabers to his neck. PALPATINE is grinning as he watches COUNT DOOKU's defeat.

PALPATINE: Good, Anakin, good. I knew you could do it. Kill him. Kill him now!

ANAKIN: I shouldn't . . .

PALPATINE: Do it!!

ANAKIN cuts off COUNT DOOKU's head. A huge EXPLOSION somewhere deep in the ship rattles everything.

ANAKIN: ... I couldn't stop myself.

PALPATINE: You did well, Anakin. He was too dangerous to be kept alive.

ANAKIN drops COUNT DOOKU's lightsaber, moving to PALPATINE.

ANAKIN: Yes, but he was an unarmed prisoner.

ANAKIN raises his hands toward PALPATINE, who is strapped in the Admiral's Chair. The Chancellor's restraints pop loose.

ANAKIN: (continuing) I shouldn't have done that, Chancellor. It's not the Jedi way.

PALPATINE stands up, rubbing his wrists.

PALPATINE: It is only natural. He cut off your arm, and you wanted revenge. It wasn't the first time, Anakin. Remember what you told me about your mother and the Sand People. Now, we must leave before more security droids arrive.

The ship begins to list to one side. ANAKIN rushes over to OBI-WAN, lifts the control console from on top of him, and pulls him free. He kneels down and checks out his unconscious friend. PALPATINE heads for the elevators.

PALPATINE: (continuing) Anakin, there is no time. We must get off the ship before it's too late.

ANAKIN: He seems to be all right. No broken bones, breathing's all right.

PALPATINE: Leave him, or we'll never make it.

ANAKIN: His fate will be the same as ours.

ANAKIN picks up OBI-WAN, slings him over his shoulder, and heads for the elevators.

40 INT. BRIDGE-TRADE FEDERATION CRUISER

GENERAL GRIEVOUS: Prepare for attack.

PILOT: All batteries fire! Fire!

41 INT. BATTLESTATIONS-REPUBLIC CRUISER

Clone gunners fire on the Trade Federation cruiser and take fire in return. Gun emplacements are destroyed. Clone troopers go flying.

42 INT. ELEVATOR LOBBY-GENERAL'S QUARTERS-TRADE FEDERATION CRUISER

ANAKIN carries OBI-WAN to the elevator doors and hits the button. PALPATINE joins him.

ANAKIN: The elevator's not working, (into his comlink) Artoo . . .

ARTOO BEEPS a response to ANAKIN.

ANAKIN: (continuing) . . . Activate Elevator 3224.

Suddenly the ship shifts to its side as the elevator doors open. PALPATINE is thrown to the ground. ANAKIN jumps to the door frame of the elevator. ANAKIN looks into the elevator shaft.

ANAKIN: (continuing) Artoo ... do you copy? Artoo, come in!

43 INT. BRIDGE-TRADE FEDERATION CRUISER

Windows are blown out, droids and equipment are sucked into space.

PILOT: Reverse stabilizers.

44 INT. MAIN HANGAR-TRADE FEDERATION CRUISER

As the ship rolls, spacecraft and equipment CRASH from one side of the ship to the other.
Several objects break through the metal blast doors, causing objects to be sucked into space. ARTOO starts to slide toward one of the small holes.

45 INT. ELEVATOR LOBBY-GENERAL'S QUARTERS-TRADE FEDERATION CRUISER

As the elevator shaft rotates, it has become a long hallway.
ANAKIN clings to the doorframe with OBI-WAN on his shoulder, as the Chancellor struggles to join him.

46 INT. MAIN HANGAR-TRADE FEDERATION CRUISER

ARTOO continues to skid and slide toward open space. He swerves around boxes and wrecked fighters. One of the BATTLE DROIDS stumbles and is consumed by the electronic shield in a zap. ARTOO BEEPS a reply as he dodges the laser blasts of the BATTLE DROIDS. One bolt hits very near him, and he SCREAMS in terror.

47 INT. BRIDGE-TRADE FEDERATION CRUISER

PILOT: Magnetize! Magnetize!

48 INT. MAIN HANGAR-TRADE FEDERATION CRUISER

ARTOO is about to be overtaken by a starfighter sliding behind him. He falls into a heap of broken battle droid parts and the fighter bounces over him.

49 EXT. SPACE-CORUSCANT

The TRADE FEDERATION CRUISER heads straight down toward the planet.

50 INT. ELEVATOR LOBBY-GENERAL'S QUARTERS-TRADE FEDERATION CRUISER

ANAKIN jumps into the horizontal elevator shaft with OBI-WAN still on his shoulder.

ANAKIN: We can't wait. Come on, we have to be fast.

PALPATINE climbs into the elevator shaft also. They start running. The ship begins to roll again, and the Jedi and the Chancellor are forced to jump from one side of the elevator to the other.

51 INT. BRIDGE-TRADE FEDERATION CRUISER

GENERAL GRIEVOUS: Fire the emergency booster engines.

PILOT: Leveling out, sir.

52 INT. ELEVATOR SHAFT ON SIDE-TRADE FEDERATION CRUISER

ANAKIN still carrying OBI-WAN on his back, and PALPATINE run down the elevator shaft as it starts to move upright. ANAKIN cuts a control box on one of the doors, but before the doors can open, the ship moves to an angle, causing ANAKIN and PALPATINE to start sliding down the shaft. ANAKIN grabs some wires in the control box with one hand. PALPATINE grabs onto the Jedi's leg. As the ship rights itself, they are left hanging in the bottomless elevator shaft.

53 INT. ELEVATOR SHAFT, VERTICAL-TRADE FEDERATION CRUISER

ANAKIN, OBI-WAN, and PALPATINE hang precariously on the side of the bottomless elevator shaft. OBI-WAN regains consciousness and tries to look around.

ANAKIN: Easy. . . . We're in a bit of a situation.

OBI-WAN: Did I miss something?

OBI-WAN looks down and sees PALPATINE and the bottomless pit. They hear ARTOO BEEPING on Obi-Wan's comlink. The ship begins to roll, causing the vertical shaft to move into a forty-five-degree angle. They hear the elevator brakes release and look up to see the elevator heading toward them.

ANAKINN: Hold on.

OBI-WAN: What is that?

OBI-WAN and ANAKIN look up to watch the elevator approach them at high speed, then OBI-WAN turns to ANAKIN.

OBI-WAN: (continuing) Oops.

ANAKIN: Artoo, Artoo, shut down the elevator!

OBI-WAN: Too late! Jump!

They fall about three hundred feet before the tilt of the ship catches up with them, and they hit the side of the shaft and slide at great speed just ahead of the elevator. The shaft continues to rotate until it is completely horizontal.
ANAKIN and OBI-WAN take out and throw grappling hooks. The hooks catch and they continue to fall. All the doors in the elevator shaft open up, and the group swings through the open door into a hallway. The elevator roars by.

54 INT. ELEVATOR LOBBY-TRADE FEDERATION CRUISER

ANAKIN, OBI-WAN, and PALPATINE fly through the elevator door and land.

OBI-WAN: Let's see if we can find something in the hangar bay that's still flyable. Come on.

ANAKIN: Artoo, get down here. Artoo, do you copy?

55 INT. MAIN HANGAR-TRADE FEDERATION CRUISER

As the Federation Cruiser continues to rotate, ARTOO SQUEALS and pokes a periscope out of a pile of broken BATTLE DROID PARTS. He looks around then rockets up out of the debris.

56 INT. HALLWAY TO HANGAR BAY-TRADE FEDERATION CRUISER

OBI-WAN and ANAKIN lead PALPATINE down a hallway toward the hangar bay.

57 INT. DOORWAY TO HANGAR BAY-TRADE FEDERATION CRUISER

It is extremely windy as bits and pieces are continually sucked into space. The hangar bay doors are closed, but great stresses are being exerted as the ship twists, re-entering the atmosphere of Coruscant. They stop in a doorway leading into the hangar bay.

OBI-WAN: None of those ships will get us anywhere.

ANAKIN: I agree.

PALPATINE: What are we going to do?

ANAKIN: I don't know.

OBI-WAN: Don't look at me. I don't know.

ANAKIN and PALPATINE both look to OBI-WAN. He shrugs his shoulders. Anakin's Fighter has been sucked out of the hangar bay and is totaled. Suddenly, the ship turns on its side.

ANAKIN: Here, Chancellor, lock this around your waist, and hold on.

OBI-WAN: We'll head toward the bridge and see if we can find an escape pod.

ANAKIN hands PALPATINE the end of a cable that is attached to his utility belt. PALPATINE attaches it around his waist. ANAKIN and OBI-WAN throw their utility cables to some pipes in the ceiling and swing to a second set of pipes.

58 INT. MAIN HANGAR-TRADE FEDERATION CRUISER

OBI-WAN grabs onto the pipes that run along what was the ceiling and is now the wall. As he moves out into the hangar, TWO SUPER BATTLE DROIDS start firing at him. The Jedi ignites his lightsaber and deflects the bolts back at the DROIDS, blowing them up. ANAKIN and PALPATINE follow OBI-WAN along the pipes running along the ceiling of the hangar. PALPATINE struggles against the escaping air of the pressurized hangar. PALPATINE loses his grip as a pipe breaks, causing a rush of steam, but ANAKIN manages to maintain his grasp on the pipe as the CHANCELLOR dangles on the other end of the utility cable. They are surrounded by SPARKS and EXPLOSIONS as the ship twists and tries to break apart. ANAKIN moves out of the steam and struggles to pull PALPATINE back to safety. ANAKIN is almost pulled loose in the buffeting winds. The ceiling behind them buckles, causing pipes to break, creating geysers of steam. Some bits of pipe go hurling into the blast doors and out into space. They make it through a hangar doorway and close it behind them.

59 INT. HANGAR DOORWAY-TRADE FEDERATION CRUISER

OBI-WAN, ANAKIN and PALPATINE are out of breath.

ANAKIN/OBI-WAN: Well, that was close.

They laugh.

60 INT. BRIDGE-TRADE FEDERATION CRUISER

BODYGUARD: General, we found the Jedi. They're in hallway 328.

GENERAL GRIEVOUS: Activate ray shields.

61 INT. HALLWAY-TRADE FEDERATION CRUISER

They run down the hallway. Suddenly, ray shields drop around them, putting them in an electronic box in the middle of the hallway.

ANAKIN: Ray shields!

OBI-WAN takes a deep breath to express his total disappointment.

OBI-WAN: Wait a minute, how'd this happen! We're smarter than this.

ANAKIN: Apparently not, Master. This is the oldest trap in the book . . . Well ... I was distracted.

OBI-WAN: Oh, so all of a sudden it's my fault.

ANAKIN: You're the Master. I'm just a hero.

OBI-WAN: I'm open to suggestions here.

PALPATINE: Why don't we let them take us to General Grievous. Perhaps with Count Dooku's demise, we can negotiate our release.

The Jedi look at each other in disbelief.

ANAKIN: I say . . . patience.

OBI-WAN: Patience! That's your plan, is it?

ANAKIN: Yes, Artoo will be along in a few moments and he'll release the ray shields . . .

ARTOO comes skidding across the hallway and bashes into the opposite wall. He takes a moment to compose himself.

ANAKIN: (continuing) See! No problem.

Suddenly several doorways open, revealing TWO DESTROYER DROIDS. SIXTEEN SUPER BATTLE DROIDS emerge from behind the DESTROYER DROIDS.
ARTOO turns and zaps one of the SUPER BATTLE DROIDS who then kicks ARTOO over.

SUPER BATTLE DROID: Don't move, dummy. Ouch! Zap this.

OBI-WAN: Do you have a plan B?

62 EXT. BRIDGE-TRADE FEDERATION CRUISER

OBI-WAN, ANAKIN PALPATINE, and ARTOO are captured by GENERAL GRIEVOUS. They stand before the ALIEN DROID GENERAL.

GENERAL GRIEVOUS: Oh yes. General Kenobi, the Negotiator. We've been waiting for you. That wasn't much of a rescue.

A BATTLE DROID walks to GENERAL GRIEVOUS and hands him the JEDI'S lightsabers.

OBI-WAN: That depends upon your point of view. Hah!

GENERAL GRIEVOUS: And Anakin Skywalker ... I was expecting someone with your reputation to be a little older.

ANAKIN: General Grievous . . . Supreme Commander of the Droid Armies. You're shorter than I expected.

GENERAL GRIEVOUS: Ahhhh, Jedi scum . . .

OBI-WAN: Anakin, try not to upset him. We have a job to do.

GENERAL GRIEVOUS: Your lightsabers will make a fine addition to my collection.

OBI-WAN: Not this time. And this time you won't escape.

ANAKIN: Artoo.

ARTOO creates a distraction by extending all his arms, shooting out electrical pulses, and bouncing around.
OBI-WAN, hands restrained with electrobonds, spins around, reaches out and, using the Force, yanks his lightsaber out of the General's hand, ignites it, and cuts his bonds. He continues to spin around and cuts Anakin free.

GENERAL GRIEVOUS: Crush them! Make them suffer!

ANAKIN uses the Force to yank his lightsaber out of the General's hand.

The DROIDS that surround them begin to FIRE. OBI-WAN and ANAKIN jump into the line of fire. The bridge degenerates into chaos. OBI-WAN and ANAKIN are locked in a pitched battle between electro staffs and laser swords with GENERAL GRIEVOUS's TWO BODYGUARDS.

CHANCELLOR PALPATINE is taken away by two BATTLE DROIDS. GENERAL GRIEVOUS walks around the bridge directing the BATTLE DROIDS.

GENERAL GRIEVOUS: Stay and watch your stations.

OBI-WAN fights one of General Grievous's BODYGUARDS. The BODYGUARD carries an electrified staff about five feet long. When the laser sword hits it, electrical bolts fly everywhere and surround the laser sword. OBI-WAN is unable to cut the staff. The Jedi gets whacked pretty good a couple of times and is knocked halfway across the bridge.
OBI-WAN pulls himself together and attacks again, cutting off the DROID BODYGUARD'S head. The DROID BODYGUARD keeps attacking. ANAKIN struggles to defend himself against the other manic DROID BODYGUARD. He cuts the DROID BODYGUARD in half. TWO BATTLE DROIDS try to take the CHANCELLOR away.
ANAKIN follows them down the hallway and cuts them down, rescuing the Chancellor.
OBI-WAN finishes off the headless BODYGUARD. It crumbles to the floor in pieces.
ALARMS SOUND as the giant spacecraft begins to list and fall out of orbit. A PILOT yells at GENERAL GRIEVOUS.

PILOT: Sir, we are falling out of orbit. All aft control cells are dead.

GENERAL GRIEVOUS: Stay on course . . . Don't bother with them. Keep the ship in orbit.

OBI-WAN and ANAKIN destroy the remaining DROIDS. GENERAL GRIEVOUS retrieves one of the BODYGUARD'S staffs and faces OBI-WAN. ANAKIN leaps over a console and lands behind GENERAL GRIEVOUS.

GENERAL GRIEVOUS: You lose, General Kenobi.

One of the PILOTS stands next to the General.

PILOT: The ship is breaking up!

GENERAL GRIEVOUS: We've run out of time.

OBI-WAN tries to get at GENERAL GRIEVOUS. ANAKIN runs at the General from the opposing side. GENERAL GRIEVOUS turns and throws his electrified staff at the window. It breaks, causing chaos as everything that is not nailed down is sucked into space. GENERAL GRIEVOUS is the first one sucked out into space. He fires a cable from his arm that attaches to the ship. He swings in and lands firmly on the side of the ship.
OBI-WAN, ANAKIN, and PALPATINE hold on for dear life. A blast shield closes around where the window used to be.

63 INT. BRIDGE-TRADE FEDERATION CRUISER

OBI-WAN continues to fight the BATTLE DROIDS. The DROIDS have backed him into a corner. OBI-WAN hides behind a control panel as the DROIDS blast away at him. He jumps up and over the DROIDS, cutting most of them down before he lands. He destroys the DROIDS and joins ANAKIN.
ANAKIN and OBI-WAN cut through the rest of the DROIDS as if they were made of butter. PALPATINE stands in shock as he watches the carnage. Droid parts are firing everywhere. OBI-WAN and ANAKIN stand back to back and cut down the last of the DROIDS just as there is a huge shudder, followed by more alarms. SPARKS begin to fly outside the windows.

PALPATINE: The hull is burning up!

64 EXT. HULL-TRADE FEDERATION CRUISER-SPACE

GENERAL GRIEVOUS detaches his cable and crawls along the exterior hull of the Federation Cruiser, using his magnetized hands and feet. He reaches a row of escape pods and enters an airlock.

65 INT. POD BAY-TRADE FEDERATION CRUISER-SPACE

GENERAL GRIEVOUS enters the escape pod bay through the hatch. The Droid General goes to a control panel and opens an escape pod.

GENERAL GRIEVOUS: Time to abandon ship.

GENERAL GRIEVOUS pulls a row of switches, and one by one the escape pods are jettisoned.

66 INT. ESCAPE POD-SPACE

He gets in one, the hatch closes, and the escape pod blasts away from the damaged Cruiser.

67 INT. BRIDGE-TRADE FEDERATION CRUISER

OBI-WAN and ANAKIN go over to the navigator's chair.

ANAKIN: All the escape pods have been launched.

OBI-WAN: Grievous. Can you fly a cruiser like this?

ANAKIN: You mean, do I know how to land what's left of this thing?

ANAKIN sits in the pilot's chair and sees on a screen the back half of the ship break away. There is a great jolt, and the ship tilts forward.

OBI-WAN: Well?

ANAKIN: Under the circumstances, I'd say the ability to pilot this thing is irrelevant. Strap yourselves in.

OBI-WAN and PALPATINE strap themselves into chairs. ANAKIN struggles with the controls of the ship. The ship starts to glow, and pieces break off. ARTOO moves in on Palpatine 's controls and assists in flying the cruiser.

OBI-WAN: Steady . . . Attitude . . . eighteen degrees.

ARTOO beeps.

ANAKIN: Pressure rising. We've got to slow this wreck down. Open all hatches, extend all flaps, and drag fins.

OBI-WAN: Temp steady. Hatches open, flaps extended, drag fins . . .

A large part of the ship breaks away.

ANAKIN: We lost something.

OBI-WAN: Not to worry, we're still flying half the ship.

ANAKIN: Now we're really picking up speed . . . I'm going to shift a few degrees and see if I can slow us down.

OBI-WAN: Careful . . . we're heating up-twelve thousand . . . thirteen thousand . . .

ANAKIN: What's our speed?

OBI-WAN: Eight plus sixty-forty. Eight plus sixty-twenty. Eight plus sixty. Temp ten thousand, nine thousand . . . we're in the atmosphere . . .

ANAKIN points to one of the controls. ARTOO beeps madly.

ANAKIN: Grab that . . . Keep us level.

OBI-WAN: Steady. Steady.

ANAKIN: Easy, Artoo. Hang on, this may get a little rough. We lost our heat shields.

OBI-WAN: Five thousand. Three thousand . . . two thousand. Fireships on the left and the right.

FlRESHIP PILOT: We'll take you in.

OBI-WAN: Copy that. Landing strip's straight ahead.

ANAKIN: We're coming in too hot.

OBI-WAN: Easy-easy.

The ship leaves a contrail as it streaks across the Coruscant skyline. PALPATINE and OBI-WAN hold on for dear life as the ship shakes and rattles toward an industrial landing platform.

68 EXT. CORUSCANT-INDUSTRIAL LANDING PLATFORM-AFTERNOON

A large landing platform in the industrial part of the city is surrounded by Emergency Fire Speeders. The smoking ship approaches as five Fireships spray it with foam. The ship finally makes a rather hard landing.

OBI-WAN: Another happy landing.

69 EXT. CORUSCANT-SENATE OFFICE BUILDING-LANDING PLATFORM-LATE AFTERNOON

The small Jedi Shuttle carrying PALPATINE and the JEDI arrives at the landing platform. There are a DOZEN SENATORS, including BAIL ORGANA, JAR JAR BINKS, and C-3PO, waiting for them. PALPATINE, R2-D2, and ANAKIN get out. OBI-WAN and MACE stay in the doorway of the Jedi Shuttle.

ANAKIN: (to Obi-Wan) Are you coming, Master?

OBI-WAN: Oh no. I'm not brave enough for politics. I have to report to the Council. Besides, someone needs to be the poster boy.

ANAKIN: Hold on, this whole operation was your idea. You planned it. You led the rescue operation. You have to be the one to take the bows this time.

OBI-WAN: Sorry, old friend. Let us not forget that you rescued me from the Buzz Droids. And you killed Count Dooku. And you rescued the Chancellor, carrying me unconscious on your back, and you managed to land that bucket of bolts safely . . .

ANAKIN: All because of your training, Master. You deserve all those speeches of your greatness.

OBI-WAN: . . . the endless speeches . . . Anakin, let's be fair. Today, you are the hero and you deserve your glorious day with the politicians.

ANAKIN: All right. But you owe me . . . and not for saving your skin for the tenth time . . .

OBI-WAN: Ninth time . . . that business on Cato Nemoidia doesn't count. I'll see you at the briefing.

ANAKIN smiles and walks away from OBI-WAN.
The CHANCELLOR and his entourage approach MACE.

MACE WlNDU: Chancellor Palpatine, what a welcome sight! Are you all right?

PALPATINE: Yes, thanks to your two Jedi Knights. They killed Count Dooku, but General Grievous has escaped once again.

MACE WlNDU: General Grievous will run and hide as he always does. He is a coward.

PALPATINE: That maybe true, but with Count Dooku dead, he is the leader of the Droid Army, and I assure you, the Senate will vote to continue the war as long as Grievous is alive.

MACE WlNDU: Then the Jedi Council will make finding Grievous our highest priority.

BAIL, ANAKIN, and the crowd walk away from the platform toward the Senate Building Grand Hallway.

BAIL ORGANA: Skywalker, the Republic cannot praise you enough.

ANAKIN and BAIL ORGANA, walking in the hallway.

ANAKIN: Thank you, Senator Organa. The kidnapping was a bold move by the Separatists, but it was a mistake that Obi-Wan and I were able to take advantage of.

ARTOO and THREEPIO follow behind the crowd.

C-3PO: It couldn't possibly be as bad as all that.

ARTOO beeps.

C-3PO: (continuing) Well, there, I agree with you. In fact, I could do with a tune-up myself.

70 INT. CORUSCANT-SENATE OFFICE BUILDING-MAIN HALLWAY-LATE AFTERNOON

ANAKIN is at the back of the crowd of SENATORS, talking with BAIL ORGANA. R2-D2 and C-3PO scoot along ahead of them.

BAIL ORGANA: The end of Count Dooku will surely bring an end to this war, and an end to the Chancellor's draconian security measures.

ANAKIN: I wish that were so, but the fighting is going to continue until General Grievous is spare parts . . . The Chancellor is very clear about that.

Behind a row of large columns, a SHADOWY FIGURE follows the JEDI and the SENATOR. ANAKIN senses the figure.

BAIL ORGANA: I'll do everything I can with the Senate.

ANAKIN: Excuse me.

BAIL ORGANA: Certainly.

ANAKIN stops, and BAIL goes off after PALPATINE and the others. ANAKIN goes behind one of the giant columns to meet up with the SHADOWY FIGURE, who is revealed to be SENATOR PADME AMDALA. They embrace and kiss.

PADME: Oh, Anakin! Thank goodness, you're back.

ANAKIN: I missed you, Padme. I've missed you so.

PADME: There were whispers . . . that you'd been killed. I've been living with unbearable dread.

ANAKIN: I'm back, I'm all right. It feels like we've been apart for a lifetime. And it might have been ... If the Chancellor hadn't been kidnapped. I don't think they would have ever brought us back from the Outer Rim sieges.

ANAKIN starts to give her another kiss. She steps back.

PADME: Wait, not here . . .

He grabs her again.

ANAKIN: Yes, here! I'm tired of all this deception. I don't care if they know we're married.

PADME: Anakin, don't say things like that. You're important to the Republic ... to ending this war. I love you more than anything, but I won't let you give up your life as a Jedi for me . . .

ANAKIN: I've given my life to the Jedi order, but I'd only give up my life, for you.

PADME: (playfully) I wouldn't like that. I wouldn't like that one bit. Patience, my handsome Jedi . . . Come to me later.

ANAKIN embraces her, then looks at her.

ANAKIN: Are you all right? You're trembling. What's going on?

PADME: I'm just excited to see you.

ANAKIN: That's not it. I sense more . . . what is it?

PADME: Nothing . . . nothing . . .

ANAKIN: You're frightened. (a little angry) Tell me what's going on!

PADME begins to cry.

PADME: You've been gone five months . . . it's been very hard for me. I've never felt so alone. There's . . .

ANAKIN: . . . Is there someone else?

PADME: (peeved, angry) No! Why do you think that? Your jealousy upsets me so much, Anakin. I do nothing to betray you, yet you still don't trust me. Nothing has changed.

ANAKIN: (sheepish) I'm afraid of losing you, Padme . . . that's all.

PADME: I will never stop loving you, Anakin. My only fear is losing you.

ANAKIN: It's just that I've never seen you like this . . .

PADME: Something wonderful has happened.

They look at each other for a long moment.

PADME: (continuing) I'm . . . Annie, I'm pregnant.

ANAKIN is stunned. He thinks through all of the ramifications of this. He takes her in his arms.

ANAKIN: That's . . . that's wonderful.

PADME: What are we going to do?

ANAKIN: We're not going to worry about anything right now, all right? This is a happy moment. The happiest moment of my life.

71 EXT. UTAPAU-LANDING PLATFORM-DAY

A small NEIMOIDIAN SHUTTLE lands. BATTLE DROIDS surround the ramp as GENERAL GRIEVOUS descends onto the platform. SUPER BATTLE DROID G21 approaches.

SUPER BATTLE DROID G21: The planet is secure, sir. The population is under control.

GENERAL GRIEVOUS: Good. Where is the Separatist Council?

SUPER BATTLE DROID G21: This way, sir ...

GENERAL GRIEVOUS takes the elevator to an upper level. He enters a conference room and presses a series of buttons on the table, and bows.

72 INT. UTAPAU-CONFERENCE ROOM-GRAND CHAMBER-DAY

A hologram of Darth Sidious appears.

GENERAL GRIEVOUS: Yes, Lord Sidious.

DARTH SlDIOUS: General Grievous, I suggest you move the Separatist leaders to Mustafar.

GENERAL GRIEVOUS: It will be done, My Lord.

DARTH SlDIOUS: The end of the war is near, General, and I promise you, victory is assured.

The hologram of Sidious talks to GRIEVOUS about the death of Count Dooku.

GENERAL GRIEVOUS: But the loss of Count Dooku?

DARTH SlDIOUS: His death was a necessary loss, which will ensure our victory. Soon I will have a new apprentice . . . one far younger and more powerful than Lord Tyranus.

73 INT. CORUSCANT-PADME'S APARTMENT-TWILIGHT

PADME stands in the balcony brushing her hair. ANAKIN leans against the wall, watching her lovingly.

ANAKIN: . . . every second I was thinking of you. Protecting the endless, nameless Outer Rim settlements became a torture . . . the battles were easy, the longing became unbearable . . . I've never been so happy as I am at this moment.

PADME: Annie, I want to have our baby back home on Naboo. We could go to the lake country where no one would know . . . where we would be safe. I could go early-and fix up the baby's room. I know the perfect spot, right by the gardens.

ANAKIN: You are so beautiful!

PADME: It's only because I'm so in love . . .

ANAKIN: No, it's because I'm so in love with you.

PADME: So love has blinded you?

ANAKIN: Well, that's not exactly what I meant . . .

PADME: But it's probably true!

They laugh.

ANAKIN: I haven't laughed in so long . . .

PADME: Neither have I.

74 INT. POLIS MASSA-MEDICAL CENTER-DREAM

The view is strangely distorted and disorienting. PADME is on a table in an alien medical chamber. She is giving birth and is screaming.

PADME: Anakin, help me! Help, Anakin! Anakin, I love you. I love you.

She screams and dies.

75 INT. CORUSCANT-PADME'S APARTMENT-BEDROOM-NIGHT

ANAKIN awakens in a panic. He is covered in sweat. He looks over in the bed and sees PADME sound asleep next to him. ANAKIN gets out from under the sheets and sits on the side of the bed. He is breathing heavily. He puts his head in his hands and weeps. He regains his composure and leaves the room down a set of stairs. PADME awakens, realizes Anakin is gone.

PADME: Anakin??

She gets out of bed and goes downstairs to look for him.

76 EXT. CORUSCANT-PADME'S APARTMENT-VERANDA-NIGHT

ANAKIN walks down a flight of stairs onto a large veranda. The vast city planet of Coruscant, smoldering from the battle, is spread out before him. He is distraught.
PADME descends the stairs and joins ANAKIN on the veranda. She takes his hand. He doesn't look at her.

PADME: What's bothering you?

ANAKIN: Nothing . . .

ANAKIN touches the japor snippet around PADME'S neck, that Anakin gave her when he was a small boy.

ANAKIN: (continuing) I remember when I gave this to you.

PADME: Anakin, how long is it going to take for us to be honest with each other?

ANAKIN: It was a dream.

PADME: Bad?

ANAKIN: Like the ones I used to have about my mother just before she died.

PADME: And?

ANAKIN: It was about you.

They look at each other. A moment of concern passes between them.

PADME: Tell me.

ANAKIN: It was only a dream.

PADME gives him a long, worried look. ANAKIN takes a deep breath.

ANAKIN: (continuing) You die in childbirth . . .

PADME: And the baby?

ANAKIN: I don't know.

PADME: It was only a dream.

ANAKIN takes PADME in his arms.

ANAKIN: . . . I won't let this one become real, Padme.

They embrace, then part.

PADME: Anakin, this baby will change our lives. I doubt the Queen will continue to allow me to serve in the Senate, and if the Council discovers you are the father, you will be expelled from the Jedi Order.

ANAKIN: I know �.

PADME: Anakin, do you think Obi-Wan might be able to help us?

ANAKIN: (suspicious) Have you told him anything?

PADME: No, but he's your mentor, your best friend . . . he must suspect something.

ANAKIN: He's been a father to me, but he's still on the Council. Don't tell him anything!

PADME: I won't, Anakin.

ANAKIN: I don't need his help . . . Our baby is a blessing, not a problem.

77 INT. CORUSCANT-JEDI TEMPLE-YODAS QUARTERS-DAY

YODA and ANAKIN sit in Yoda 's room, deep in thought.

YODA: Premonitions . . . premonitions . . . Hmmmm . . . these visions you have . . .

ANAKIN: They are of pain, suffering, death . . .

YODA: Yourself you speak of, or someone you know?

ANAKIN: Someone . . .

YODA: . . . close to you?

ANAKIN: Yes.

YODA: Careful you must be when sensing the future, Anakin. The fear of loss is a path to the dark side.

ANAKIN: I won't let these visions come true, Master Yoda.

YODA: Death is a natural part of life. Rejoice for those around you who transform into the Force. Mourn them, do not. Miss them, do not. Attachment leads to jealousy. The shadow of greed, that is.

ANAKIN: What must I do, Master Yoda?

YODA: Train yourself to let go of everything you fear to lose.

78 INT. CORUSCANT-JEDI TEMPLE-HALLWAY-DAY

ANAKIN hurries down a temple hallway, heading toward a Jedi Briefing Room. SEVERAL JEDI are exiting.

79 INT. CORUSCANT-JEDI TEMPLE-BRIEFING ROOM-DAY

ANAKIN rushes into the Briefing Room. By the time he reaches the Chamber, the last of the Jedi are leaving. Only OBI-WAN remains at the front of the lecture hall. He is shutting off some holograms and electronic charts and maps.

OBI-WAN: You missed the report on the Outer Rim sieges.

ANAKIN: I'm sorry, I was held up. I have no excuse.

OBI-WAN: In short, they are going very well. Saleucami has fallen, and Master Vos has moved his troops to Boz Pity.

ANAKIN: What's wrong then?

OBI-WAN: The Senate is expected to vote more executive powers to the Chancellor today.

ANAKIN: Well, that can only mean less deliberating and more action. Is that bad? It will make it easier for us to end this war.

OBI-WAN: Anakin, be careful of your friend Palpatine.

ANAKIN: Be careful of what?

OBI-WAN: He has requested your presence.

ANAKIN: What for?

OBI-WAN: He would not say.

ANAKIN: He didn't inform the Jedi Council? That's unusual, isn't it?

OBI-WAN: All of this is unusual, and it's making me feel uneasy. You're probably aware that relations between the Council and the Chancellor are stressed.

ANAKIN: I know the Council has grown wary of the Chancellor's power, mine also for that matter. Aren't we all working together to save the Republic? Why all this distrust?

OBI-WAN: The Force grows dark, Anakin, and we are all affected by it. Be wary of your feelings.

80 INT. CORUSCANT-CHANCELLOR'S OFFICE-DAY

ANAKIN stands with PALPATINE at his window overlooking the vastness of Coruscant. Several buildings have been destroyed. A brown haze hangs over the landscape.

PALPATINE: Anakin, this afternoon the Senate is going to call on me to take direct control of the Jedi Council.

ANAKIN: The Jedi will no longer report to the Senate?

PALPATINE: They will report to me . . . personally. The Senate is too unfocused to conduct a war. This will bring a quick end to things.

ANAKIN: I agree, but the Jedi Council may not see it that way.

PALPATINE: There are times when we must all endure adjustments to the constitution in the name of security.

ANAKIN: With all due respect, sir, the Council is in no mood for more constitutional amendments.

PALPATINE: Thank you, my friend, but in this case I have no choice . . . this war must be won.

ANAKIN: Everyone will agree on that.

PALPATINE: Anakin, I've known you since you were a small boy. I have advised you over the years when I could ... I am very proud of your accomplishments. You have won many battles the Jedi Council thought were lost . . . and you saved my life. I hope you trust me, Anakin.

ANAKIN: Of course.

PALPATINE: I need your help, son.

ANAKIN: What do you mean?

PALPATINE: I fear the Jedi. The Council keeps pushing for more control. They're shrouded in secrecy and obsessed with maintaining their autonomy . . . ideals. I find simply incomprehensible in a democracy.

ANAKIN: I can assure you that the Jedi are dedicated to the values of the Republic, sir.

PALPATINE: Nevertheless, their actions will speak more loudly than their words. I'm depending on you.

ANAKIN: For what? I don't understand.

PALPATINE: To be the eyes, ears, and voice of the Republic . . .

ANAKIN thinks about this.

PALPATINE: (continuing) Anakin . . . I'm appointing you to be my personal representative on the Jedi Council.

ANAKIN: Me? A Master? I am overwhelmed, sir, but the Council elects its own members. They will never accept this.

PALPATINE: I think they will . . . they need you more than you know.

81 INT. CORUSCANT-BAIL ORGANA'S OFFICE-DAY

PADME, BAIL ORGANA, and SENATORS MON MOTHMA, FANG ZAR, TERR TANEEL, and GIDDEAN DANU sit in Senator Organa 's office.

BAIL ORGANA: Now that he has control of the Jedi Council, the Chancellor has appointed Governors to oversee all star systems in the Republic.

FANG ZAR: When did this happen?

BAIL ORGANA: The decree was posted this morning.

PADME: Do you think he will dismantle the Senate?

MON MOTHMA: Why bother? As a practical matter, the Senate no longer exists.

GIDDEAN DANU: The constitution is in shreds. Amendment after amendment . . . executive directives, sometimes a dozen in one day.

BAIL ORGANA: We can't let a thousand years of democracy disappear without a fight.

EVERYONE looks at each other, a little worried at the implications of what was just said.

TERR TANEEL: What are you suggesting?

BAIL ORGANA: I apologize. I didn't mean to sound like a Separatist.

MON MOTHMA: We are not Separatists trying to leave the Republic. We are loyalists, trying to preserve democracy in the Republic.

BAIL ORGANA: It has become increasingly clear to many of us that the Chancellor has become an enemy of democracy.

PADME: I can't believe it has come to this! Chancellor Palpatine is one of my oldest advisors. He served as my Ambassador when I was Queen.

GlDDEAN DANU: Senator, I fear you underestimate the amount of corruption that has taken hold in the Senate.

MON MOTHMA: The Chancellor has played the Senators well. They know where the power lies, and they will do whatever it takes to share in it. Palpatine has become a dictator and we have helped him to do it.

BAIL ORGANA: We can't sit around debating any longer, we have decided to do what we can to stop it. Senator Mon Mothma and I are putting together an organization . . .

PADME: Say no more. Senator Organa. I understand. At this point, it's better to leave some things unsaid.

BAIL ORGANA: Yes. I agree and we must not discuss this with anyone, without everyone in this group agreeing.

MON MOTHMA: That means those closest to you . . . even family ... no one can be told.

They ALL nod their heads. PADME considers this for a moment.

PADME: Agreed.

82 INT. CORUSCANT-JEDI TEMPLE-HALLWAY OUTSIDE COUNCIL CHAMBERS-DAY

ANAKIN stands pensively in front of the Jedi Council Chambers. The door opens.

83 INT. CORUSCANT-JEDI TEMPLE-COUNCIL CHAMBERS-DAY

ANAKIN enters and stands in the middle of the room. He is surrounded by the Jedi Council MACE WINDU, EETH KOTH OBI-WAN, YODA, the HOLOGRAMS of PLO KOON and KI-ADI-MUNDI.

MACE: Anakin Skywalker, we have approved your appointment to the Council as the Chancellor's personal representative.

ANAKIN: I will do my best to uphold the principles of the Jedi Order.

YODA: Allow this appointment lightly, the Council does not. Disturbing is this move by Chancellor Palpatine.

ANAKIN: I understand.

MACE: You are on this Council, but we do not grant you the rank of Master.

Anakin reacts with anger.

ANAKIN: What? ! How can you do this?? This is outrageous, it's unfair . . . I'm more powerful than any of you. How can you be on the Council and not be a Master?

MACE: Take a seat, young Skywalker.

ANAKIN: Forgive me, Master.

ANAKIN goes and sits in one of the empty chairs. Everyone is embarrassed. KI-ADI-MUNDI WHO APPEARS AS A HOLOGRAM, speaks.

Kl-ADI-MUNDI: We have surveyed all systems in the Republic, and have found no sign of General Grievous.

YODA: Hiding in the Outer Rim, Grievous is. The outlying systems, you must sweep.

OBI-WAN: It may take some time . . . we do not have many ships to spare.

MACE: We cannot take ships from the front line.

OBI-WAN: And yet, it would be fatal for us to allow the droid armies to regroup.

YODA: Master Kenobi, our spies contact, you must, and then wait.

Kl-ADI-MUNDI: What about the droid attack on the Wookiees?

MACE: It is critical we send an attack group there, immediately!

OBI-WAN: He's right, that is a system we cannot afford to lose. It's the main navigation route for the southwestern quadrant.

ANAKIN: I know that system well. It would take us little time to drive the droids off that planet.

MACE: Skywalker, your assignment is here with the Chancellor, and Kenobi must find General Grievous.

YODA: Go, I will. Good relations with the Wookiees, I have.

MACE: It is settled then. Yoda will take a battalion of clones to reinforce the Wookiees on Kashyyyk. May the Force be with us all.

ANAKIN is disappointed.

84 INT. CORUSCANT-JEDI TEMPLE-MASSIVE MAIN HALLWAY AND ALCOVE-LATE AFTERNOON

ANAKIN and OBI-WAN walk through one of the massive Jedi Temple hallways. ANAKIN is furious.

ANAKIN: What kind of nonsense is this, put me on the Council and not make me a Master!?? That's never been done in the history of the Jedi. It's insulting!

OBI-WAN: Calm down, Anakin. You have been given a great honor. To be on the Council at your age . . . It's never happened before. Listen to me, Anakin. The fact of the matter is you're too close to the Chancellor. The Council doesn't like it when he interferes in Jedi affairs.

ANAKIN: I swear to you, I didn't ask to be put on the Council . . .

OBI-WAN: But it's what you wanted! Your friendship with Chancellor Palpatine seems to have paid off.

ANAKIN: That has nothing to do with this.

OBI-WAN: Anakin, regardless of how it happened, you find yourself in a delicate situation.

ANAKIN: You mean divided loyalties.

OBI-WAN: I warned you there was tension between the Council and the Chancellor. I was very clear. Why didn't you listen? You walked right into it.

ANAKIN: The Council is upset I'm the youngest to ever serve.

OBI-WAN: No, it is not. Anakin, I worry when you speak of jealousy and pride. Those are not Jedi thoughts. They're dangerous, dark thoughts.

ANAKIN: Master, you of all people should have confidence in my abilities. I know where my loyalties lie.

OBI-WAN: I hope so . . .

ANAKIN: I sense there's more to this talk than you're saying.

OBI-WAN: Anakin, the only reason the Council has approved your appointment is because the Chancellor trusts you.

ANAKIN: And?

OBI-WAN: Anakin, look, I am on your side. I didn't want to see you put in this situation.

ANAKIN: What situation?

OBI-WAN: (takes a deep breath) The Council wants you to report on all of the Chancellor's dealings. They want to know what he's up to.

ANAKIN: They want me to spy on the Chancellor? That's treason!

OBI-WAN: We are at war, Anakin. The Jedi Council is sworn to uphold the principles of the Republic, even if the Chancellor does not.

ANAKIN: Why didn't the Council give me this assignment when we were in session?

OBI-WAN: This assignment is not to be on record. The Council asked me to approach you on this personally.

ANAKIN: The Chancellor is not a bad man, Obi-Wan. He befriended me. He's watched out for me ever since I arrived here.

OBI-WAN: That is why you must help us, Anakin. Our allegiance is to the Senate, not to its leader who has managed to stay in office long after his term has expired.

ANAKIN: Master, the Senate demanded that he stay longer.

OBI-WAN: Yes, but use your feelings, Anakin. Something is out of place.

ANAKIN: You're asking me to do something against the Jedi Code. Against the Republic. Against a mentor . . . and a friend. That's what's out of place here. Why are you asking this of me?

OBI-WAN: The Council is asking you.

85 EXT. CORUSCANT-CLONE LANDING PLATFORM-DAY

A JEDI GUNSHIP heads for the huge Clone landing platform.

86 INT. CORUSCANT-JEDI GUNSHIP-DAY

YODA, MACE, and OBI-WAN ride in the GUNSHIP as it heads for the Clone landing platform. Mace and Obi-Wan are sitting.

OBI-WAN : Anakin did not take to his assignment with much enthusiasm.

YODA: Too much under the sway of the Chancellor, he is. Much anger there is in him. Too much pride in his powers.

MACE: It's very dangerous, putting them together. I don't think the boy can handle it. I don't trust him.

OBI-WAN: He'll be all right. I trust him with my life.

MACE:I wish I did.

OBI-WAN: With all due respect, Master, is he not the Chosen One? Is he not to destroy the Sith and bring balance to the Force?

MACE: So the prophecy says.

YODA: A prophecy . . . that misread could have been.

OBI-WAN: He will not let me down. He never has.

YODA: I hope right you are. And now destroy the Droid armies on Kashyyyk, I will. May the Force be with you.

The GUNSHIP lands and the ramp lowers. YODA exits the GUNSHIP. MACE and OBI-WAN stand and give him a brief bow then take off in the GUNSHIP.

87 EXT. CORUSCANT-PADME'S APARTMENT-VERANDA-SUNSET

Padme's Speeder pulls up to the landing platform. CAPTAIN TYPHO escorts PADME onto the veranda, where TWO HANDMAIDENS (ELLE and MOTEE) are waiting. PADME turns to CAPTAIN TYPHO.

PADME: Thank you, Captain.

CAPTAIN TYPHO: Rest well. My Lady.

CAPTAIN TYPHO gets back into the Speeder, and it disappears into the cityscape. The HANDMAIDENS, Motee and Elle, approach PADME as the SHADOW OF A FIGURE moves in the background. C-3PO is standing nearby.

PADME: I'll be up in a while.

MOTEE: Yes, my lady.

C-3PO stands, confused, as the HANDMAIDENS turn and exit.

C-3PO: Is there anything I might do for you, my lady?

PADME: Yes, make sure all the security droids are working. Thank you, Threepio.

The golden droid turns and exits.

PADME stands and watches the sunset. The SHADOWY FIGURE moves toward her. She senses something.

ANAKIN: Beautiful, isn't it?

PADME jumps and turns around.

PADME: You startled me.

He sits next to her on the bench.

ANAKIN: How are you feeling?

PADME: He keeps kicking.

ANAKIN: He?! Why do you think it's a boy?

PADME: (laughs) My motherly intuition.

She puts his hand on her belly.

ANAKIN: Whoa! With a kick that strong, it's got to be a girl.

They laugh.

PADME: I heard about your appointment. Anakin. I'm so proud of you.

ANAKIN: I may be on the Council, but . . . they refused to accept me as a Jedi Master.

PADME: Patience. In time, they will recognize your skills.

ANAKIN: They still treat me as if I were a Padawan learner. . . they fear my power, that's the problem.

PADME: Anakin . . .

ANAKIN: Sometimes, I wonder what's happening to the Jedi Order . . . I think this war is destroying the principles of the Republic.

PADME: Have you ever considered that we may be on the wrong side?

ANAKIN: (suspicious) What do you mean?

PADME: What if the democracy we thought we were serving no longer exists, and the Republic has become the very evil we have been fighting to destroy?

ANAKIN: I don't believe that. And you're sounding like a Separatist!

PADME: Anakin, this war represents a failure to listen . . . Now, you're closer to the Chancellor than anyone. Please, please ask him to stop the fighting and let diplomacy resume.

ANAKIN: (growing angry) Don't ask me to do that, Padme. Make a motion in the Senate, where that kind of a request belongs. I'm not your errand boy. I'm not anyone's errand boy!

PADME: What is it?

ANAKIN: Nothing.

PADME: Don't do this . . . don't shut me out. Let me help you.

ANAKIN: You can't help me . . . I'm trying to help you.

They look in each other's eyes.

ANAKIN: (continuing) I sense . . . there are things you are not telling me.

PADME is startled at this.

PADME: I sense there are things you are not telling me.

PADME smiles. ANAKIN is a little embarrassed.

PADME: (continuing) Hold me . . . like you did by the lake on Naboo, so long ago . . . when there was nothing but our love ... No politics, no plotting ... no war.

88 INT. CORUSCANT-GALAXIES OPERA HOUSE-NIGHT

ANAKIN lands his speeder and exits.
ANAKIN runs up the stairs at the Galaxies Opera House.
ANAKIN runs through the hallway and enters Palpatine's box, where the CHANCELLOR is sitting with Mas Amedda and Sly-Moore, watching the Man Calamari Ballet doing "Squid Lake."

ANAKIN: You wanted to see me, Chancellor.

PALPATINE: Yes, Anakin! Come closer. I have good news. Our Clone Intelligence Units have discovered the location of General Grievous. He is hiding in the Utapau system.

ANAKIN: At last, we'll be able to capture that monster and end this war.

PALPATINE: I would worry about the collective wisdom of the Council if they didn't select you for this assignment. You are the best choice by far � but, they can't always be trusted to do the right thing.

ANAKIN: They try.

PALPATINE: Sit down, (to his aides) Leave us.

ANAKIN sits next to PALPATINE. The Chancellor leans over to him.

PALPATINE: (continuing) Anakin, you know I'm not able to rely on the Jedi Council. If they haven't included you in their plot, they soon will.

ANAKIN: I'm not sure I understand.

PALPATINE: You must sense what I have come to suspect . . . the Jedi Council want control of the Republic . . . they're planning to betray me.

ANAKIN: I don't think . . .

PALPATINE: Anakin, search your feelings. You know, don't you?

ANAKIN: I know they don't trust you . . .

PALPATINE: Or the Senate . . . or the Republic . . . or democracy for that matter.

ANAKIN: I have to admit my trust in them has been shaken.

PALPATINE: Why? They asked you to do something that made you feel dishonest, didn't they?

ANAKIN doesn't say anything. He simply looks down.

PALPATINE: (continuing) They asked you to spy on me, didn't they?

ANAKIN: I don't know ... I don't know what to say.

PALPATINE: Remember back to your early teachings. Anakin. "All those who gain power are afraid to lose it." Even the Jedi.

ANAKIN: The Jedi use their power for good.

PALPATINE: Good is a point of view, Anakin. And the Jedi point of view is not the only valid one. The Dark Lords of the Sith believe in security and justice also, yet they are considered by the Jedi to be. . .

ANAKIN: . . . evil.

PALPATINE: . . . from a Jedi's point of view. The Sith and the Jedi are similar in almost every way, including their quest for greater power. The difference between the two is the Sith are not afraid of the dark side of the Force. That is why they are more powerful.

ANAKIN: The Sith rely on their passion for their strength. They think inward, only about themselves.

PALPATINE: And the Jedi don't?

ANAKIN: The Jedi are selfless . . . they only care about others.

PALPATINE smiles.

PALPATINE: Or so you've been trained to believe. Why is it, then, that they have asked you to do something you feel is wrong?

ANAKIN: I'm not sure it's wrong.

PALPATINE: Have they asked you to betray the Jedi code? The Constitution? A friendship? Your own values? Think. Consider their motives. Keep your mind clear of assumptions. The fear of losing power is a weakness of both the Jedi and the Sith.

ANAKIN is deep in thought.

PALPATINE: (continuing) Did you ever hear the tragedy of Darth Plagueis "the wise"?

ANAKIN: No.

PALPATINE: I thought not. It's not a story the Jedi would tell you. It's a Sith legend. Darth Plagueis was a Dark Lord of the Sith, so powerful and so wise he could use the Force to influence the midi-chlorians to create life ... He had such a knowledge of the dark side that he could even keep the ones he cared about from dying.

ANAKIN: He could actually save people from death?

PALPATINE: The dark side of the Force is a pathway to many abilities some consider to be unnatural.

ANAKIN: What happened to him?

PALPATINE: He became so powerful . . . the only thing he was afraid of was losing his power, which eventually, of course, he did. Unfortunately, he taught his apprentice everything he knew, then his apprentice killed him in his sleep. (smiles) Plagueis never saw it coming. It's ironic he could save others from death, but not himself.

ANAKIN: Is it possible to learn this power?

PALPATINE: Not from a Jedi.

89 EXT. KASHYYYK-DAY

A WOOKIEE CATAMARAN flanked by WOOKIEE HELICOPTERS approaches the tree housing the HOLOGRAM AREA.

90 INT. KASHYYYK-HOLOGRAM AREA-DAY

YODA and various JEDI speak via hologram. The discussion includes OBI-WAN, MACE, AGEN KOLAR, YODA- KI-ADI-MUNDI and PLO KOON.

Kl-ADI-MUNDI: (holo) Palpatine thinks General Grievous is on Utapau. We have had no reports of this from our agents.

MACE: (holo) How could the Chancellor have come by this information and we know nothing about it? We have had contact with Baron Papanoida and he said no one was there.

ANAKIN: A partial message was intercepted in a diplomatic packet from the Chairman of Utapau.

YODA: Act on this, we must. The capture of General Grievous will end this war. Quickly and decisively we should proceed.

OBI-WAN: Does everyone agree?

All the JEDI concur.

ANAKIN: The Chancellor has requested that I lead the campaign.

They all look at ANAKIN a bit disturbed.

MACE: (a little peeved) The Council will make up its own mind who is to go, not the Chancellor.

Kl-ADI-MUNDI: Yes, this decision is ours to make.

ANAKIN is embarrassed and becomes sullen.

YODA: A Master is needed, with more experience.

MACE: Given our resources, I recommend we send only one Jedi . . . Master Kenobi.

ANAKIN: He was not so successful the last time he met Grievous.

OBI-WAN throws ANAKIN a dirty look.

ANAKIN: (continuing) No offense, my Master, but I'm only stating a fact.

OBI-WAN: Oh no, you're quite right, but I do have the most experience with his ways of combat.

YODA: Obi-Wan, my choice is.

Kl-ADI-MUNDI: I concur. Master Kenobi should go.

YODA: I agree.

All the JEDI concur.

MACE: Very well. Council is adjourned.

ANAKIN is angry.

MACE: (continuing) Obi-Wan, prepare two clone brigades as quickly as you can. If this report is true, there's no telling how many battle droids he may have with him.

91 INT. KASHYYYK-HOLOGRAM AREA-DAY

YODA gets out of his chair and walks to the edge of the platform.

CLONE COMMANDER GREE: The droids have started up their main power generators.

YODA: Then now the time is, Commander.

CLONE COMMANDER GREE: Yes, sir.

The battle begins.

92 EXT. KASHYYYK-BEACH HEAD-DAY

A WOOKIEE CHIEFTAIN lets out a roar as the Wookiee army rushes to face the DROID ARMY. CORPORATE ALLIANCE TANK DROIDS race across the water against the WOOKIEES and CLONE TROOPERS on the beach. DROID GUNSHIPS provide air support, while a SPIDER DROID emerges from the watery depths. A brave WOOKIEE places an explosive on a SEPARATIST TANK and jumps off just before the TANK EXPLODES. From the Hologram Area, Yoda observes the ongoing battle.

93 EXT. CORUSCANT-PADME'S APARTMENT-EARLY MORNING

Padme's apartment building is surrounded by the smog-shrouded city of Coruscant.

94 INT. CORUSCANT-PADME'S APARTMENT-LIVING ROOM-EARLY MORNING

PADME and OBI-WAN sit on one of the couches.

OBI-WAN: Has Anakin been to see you?

PADME: Several times . . . I was so happy to hear he was accepted on the Jedi Council.

OBI-WAN: I know ... he deserves it. He is impatient, strong willed, very opinionated, but truly gifted.

They laugh.

PADME: You're not just here to say hello. Something is wrong, isn't it?

OBI-WAN: You should be a Jedi, Padme.

PADME: You're not very good at hiding your feelings.

OBI-WAN: It's Anakin . . . He's becoming moody and detached. He's been put in a difficult position as the Chancellor's representative . . . but I think it's more than that. I was hoping he may have talked to you.

PADME: Why would he talk to me about his work?

OBI-WAN studies her.

OBI-WAN: Neither of you is very good at hiding your feelings either.

PADME: Don't give me that look.

OBI-WAN: I know how he feels about you.

PADME: (nervous) What did he say?

OBI-WAN: Nothing. He didn't have to.

PADME is a little flustered. She stands and Obi-Wan follows. She walks to the balcony.

PADME: I don't know what you're talking about.

OBI-WAN: I know you both too well. I can see you two are in love. Padme, I'm worried about him.

PADME looks down and doesn't answer.

OBI-WAN: (continuing) I fear your relationship has confused him. He's changed considerably since we returned . . .

They stand on the balcony and look off at the early morning city. OBI-WAN starts to leave. PADME stays looking off into the distant city.

OBI-WAN: (continuing) Padme, I'm not telling the Council about any of this. I ... I hope I didn't upset you. We're all friends, I care about both of you . . .

PADME: Thank you, Obi-Wan.

OBI-WAN: Please do what you can to help him.

95 INT. CORUSCANT-PADME'S APARTMENT-DAY

PADME, MON MOTHMA, and five other Senators (BANA BREEMU, FANG ZAR. CHI EEKWAY, GIDDEAN DANU, BAIL ORGANA) sit in Padme's living room. C-3PO serves drinks to the guests.

PADME: We cannot let this turn into another war.

BAIL ORGANA: Absolutely, that is the last thing we want.

MON MOTHMA: We are hoping to form an alliance in the Senate to stop the Chancellor from further subverting the constitution, that's all.

PADME: I know a Jedi I feel it would be wise to consult.

BANA BREEMU: That would be dangerous.

MON MOTHMA: We don't know where the Jedi stand in all this.

PADME: I only wish to discuss this with one . . . one I trust.

GiDDEAN DANU: Going against the Chancellor without the support of the Jedi is risky.

PADME: The Jedi aren't any happier with the situation than we are . . .

CHI EEKWAY: Patience, Senator.

FANG ZAR: We have so many Senators on our side, surely that will pursuade the Chancellor.

BANA BREEMU: When you present the "petition of the two thousand" to the Chancellor, things may change.

BAIL ORGANA: Let us see what we can accomplish in the Senate, before we include the Jedi.

PADME takes a deep breath in frustration and disappointment.

96 EXT. CORUSCANT-CLONE LANDING PLATFORM-DAY

ANAKIN and OBI-WAN walk onto a landing platform overlooking a docking bay where THOUSANDS OF CLONE TROOPS and armored weapons, tanks, etc., are being loaded onto a massive REPUBLIC ASSAULT SHIP.

ANAKIN: You're going to need me on this one, Master.

OBI-WAN: Oh, I agree. However it may turn out just to be a wild bantha chase.

OBI-WAN starts to turn and leave.

ANAKIN: Master!

OBI-WAN stops and ANAKIN walks over to him.

ANAKIN: (continuing) Master, I've disappointed you. I have not been very appreciative of your training . . . I have been arrogant and I apologize . . . I've just been so frustrated with the Council. Your friendship means everything to me.

OBI-WAN: You are strong and wise, Anakin, and I am very proud of you. I have trained you since you were a small boy. I have taught you everything I know. And you have become a far greater Jedi than I could ever hope to be, and you have saved my life more times than I can remember. But be patient, Anakin. It won't be long before the Council makes you a Jedi Master.

OBI-WAN starts down the ramp, then turns back.

OBI-WAN: (continuing) Don't worry. I have enough clones with me to take three systems the size of Utapau. I think I'll be able to handle the situation . . . even without your help.

ANAKIN: Well, there's always a first time.

OBI-WAN laughs.

They talk for a few more minutes before ANAKIN watches OBI-WAN depart.

ANAKIN: Obi-Wan, may the Force be with you.

OBI-WAN: Good-bye, old friend. May the Force be with you.

OBI-WAN heads down a ramp toward the waiting Republic cruiser.

97 EXT. CORUSCANT-CLONE LANDING PLATFORM-DAY

The Republic cruiser lifts off and heads for space.

98 INT. REPUBLIC BATTLE CRUISER-HANGAR-SPACE

CLONE TROOPERS stand at attention in rows on the floor of the hangar deck, waiting to board landing craft. OBI-WAN stands next to his BLUE JEDI FIGHTER- talking to SEVERAL CLONE COMMANDERS with their helmets off. A hologram of the planet Utapau is projected by R4-G9 into the middle of the hangar.

CLONE COMMANDER CODY: Fortunately, most of the cities are concentrated on this small continent here . . . on the far side.

OBI-WAN: I'll keep them distracted until you get there. Just don't take too long.

CLONE COMMANDER CODY: Come on, boss, when have I ever let you down?

They laugh.

OBI-WAN: (laughing) Cato Nemoidia . . . for starters.

OBI-WAN climbs into his Jedi Fighter.

CLONE COMMANDER CODY: That was Anakin who was late. I believe.

OBI-WAN: Very well, the burden is on me not to destroy all the droids before you get there.

CLONE COMMANDER CODY: I'm counting on you.

99 EXT. JEDI FIGHTER-SPACE

OBI-WAN blasts the BLUE JEDI FIGHTER out of the Republic Battle Cruiser and into the hyperspace ring. He heads for the planet Utapau.

100 EXT. CORUSCANT-CITYSCAPE-CHANCELLOR'S TRANSPORT-DAY

The Chancellor's Transport races through the city and heads for the Senate Office Building landing platform. Waiting on the landing platform is a LONE JEDI. The Transport lands, and CHANCELLOR PALPATINE emerges with FOUR ROYAL GUARDS and MAS AMEDDA. The FOUR ROYAL GUARDS move off in another direction as PALPATINE greets ANAKIN, who has been waiting for him.

PALPATINE: Well, Anakin, did you see your friend off?

ANAKIN: He will soon have Grievous's head.

PALPATINE: We can only hope the Council didn't make a mistake.

ANAKIN: The Council was very sure in its decision.

They exit the landing platform.

101 INT. CORUSCANT-SENATE OFFICE BUILDING-MAIN HALLWAY-DAY

They enter the main hallway of the Senate Office Building. They pass SEVERAL SENATORS, including REPRESENTATIVE JAR JAR BINKS from Naboo.

JAR JAR: Helloo Annie. Good en to see yousa . . .

The Gungan waves to Anakin.

ANAKIN: Hi, Jar Jar.

JAR JAR: Oopsin da Chancellor!! So sorry, Your Highness, sir.

Anakin turns back to the Chancellor.

PALPATINE: There are rumors in the Senate about Master Kenobi. Many believe he is not fit for this assignment.

ANAKIN: Not fit? Why would anyone think that?

PALPATINE: They say his mind has become fogged by the influence of a certain female Senator.

ANAKIN: That's ridiculous. Who?!?

PALPATINE: (slyly) No one knows who she is ... only that she is a Senator.

ANAKIN: That's impossible. I would know.

PALPATINE: Sometimes the closest are the ones who cannot see.

ANAKIN becomes worried.

PALPATINE: (continuing) Idle Senate gossip is rarely true and never accurate. I'm sure your Master will do fine.

102 INT. POLIS MASSA-MEDICAL CENTER-DREAM

PADME calls out in pain. OBI-WAN is near her and softly speaks to her.

OBI-WAN: Save your energy.

PADME: I can't!

OBI-WAN: Don't give up, Padme. Don't give up . . .

103 INT. CORUSCANT-PADME'S APARTMENT-LANDING ROOM-DAY

ANAKIN is in the living room, working. He sits on the couch where Obi-Wan was sitting. PADME enters and crosses behind him.

ANAKIN: I sense someone familiar . . . Obi-Wan's been here, hasn't he?

PADME: He came by this morning.

ANAKIN: What did he want?

PADME looks at him for a moment. ANAKIN seems tense.

PADME: He's worried about you.

ANAKIN: You told him about us, didn't you?

She continues to walk to the bedroom, he follows.

PADME: He's your best friend, Anakin. He says you're under a lot of stress.

ANAKIN: And he's not?

PADME: You have been moody lately.

ANAKIN: I'm not moody . . .

PADME: Anakin! Don't do this again.

ANAKIN: I don't know ... I feel . . . lost.

PADME: Lost? What do you mean? You're always so sure of yourself. I don't understand.

ANAKIN: Obi-Wan and the Council don't trust me.

PADME: They trust you with their lives. Obi-Wan loves you as a son.

ANAKIN: Something's happening . . . I'm not the Jedi I should be. I am one of the most powerful Jedi, but I'm not satisfied ... I want more, and I know I shouldn't.

PADME: You expect too much of yourself.

They stop in front of the window in the bedroom. ANAKIN puts his hand on her belly.

ANAKIN: I have found a way to save you.

PADME: Save me?

ANAKIN: From my nightmares.

PADME: Is that what's bothering you?

ANAKIN: I won't lose you, Padme.

PADME: I'm not going to die in childbirth, Annie. I promise you.

ANAKIN: No, I promise you! I am becoming so powerful with my new knowledge of the Force, I will be able to keep you from dying.

PADME looks ANAKIN in the eye.

PADME: You don't need more power, Anakin. I believe you can protect me against anything, just as you are.

They embrace and kiss.

104 EXT. UTAPAU-SPACE

OBI-WAN blasts out of the BLUE JEDI FIGHTER's hyperspace ring and heads for the planet Utapau. The BLUE FIGHTER skims over the planet's surface, flat except for a few giant sinkholes.

105 INT. UTAPAU-LANDING PLATFORM-DAY

OBI-WAN lands his ship on a Platform projecting out of the side of a giant sinkhole. All is quiet. A local administrator, TION MEDON, comes out to greet the ship. OBI-WAN climbs out of his Fighter as a SHORT GROUND CREW looks over his ship. On a ledge above the landing platform, GRIEVOUS's BODYGUARDS watch as OBI-WAN talks to TION MEDON.

TlON MEDON: Greetings, young Jedi. What brings you to our remote sanctuary?

OBI-WAN: Unfortunately, the war.

TlON MEDON: There is no war here unless you've brought it with you.

OBI-WAN: With your kind permission, I should like some fuel and to use your city as a base as I search nearby systems for General Grievous.

A GROUND CREW rushes out and refuels Obi-Wan�s Fighter. TION MEDON leans close to OBI-WAN and speaks quietly.

TlON MEDON: He is here! We are being held hostage. They are watching us.

OBI-WAN: I understand.

TlON MEDON: The tenth level . . . thousands of Battle Droids . . .

OBI-WAN: Tell your people to take shelter. If you have warriors, now is the time.

OBI-WAN starts back toward his Starfighter as TION MEDON leaves the Landing Platform. GRIEVOUS's BODYGUARDS retreat from the overhead platform. OBI-WAN climbs back into his BLUE JEDI FIGHTER. His Astro Unit (R4-G9) turns to him:

OBI-WAN: (continuing) Geenine, take the Fighter back to the ship. I'm staying here. Tell Cody I've made contact.

The little Astro Droid BEEPS a reply.

106 EXT. UTAPAU-OBSERVATION DECK-DAY

On a high balcony, TION MEDON looks down on the landing platform. A few steps behind him stands one of GENERAL GRIEVOUS's BODYGUARDS. They watch the canopy lower.

TlON MEDON: I told you, all he wanted was fuel.

BODYGUARD: What was his name?

TlON MEDON: He didn't say.

They watch as the BLUE JEDI FIGHTER takes off.

107 INT. UTAPAU-LANDING PLATFORM-HALLWAY-DAY

OBI-WAN also watches his ship take off. He is hiding in the hallway. He quietly moves farther into the city.

108 EXT. UTAPAU STAIRWAY-SINKHOLE RIM-DAY

OBI-WAN quickly rushes up a stairway cut into the side of the sinkhole. It's hard to see him. In an alcove, he carefully surveys the city, then quickly moves on.

109 INT. UTAPAU-CITY-DRAGON CORRAL-DAY

OBI-WAN makes his way through the city, looking up at the tenth level with electro-binoculars from his utility belt. He tries to figure out how he is going to get up there. He hears strange bellowing cries and he investigates.
He comes across a corral filled with about half a dozen DRAGON-LIKE LIZARDS. SEVERAL WRANGLERS are standing around.
OBI-WAN walks up to the WRANGLERS and uses the Force with his slight hand movements.

OBI-WAN: I need transportation.

WRANGLER: (subtitled, in native tongue) You need transportation.

OBI-WAN: Get it for me.

WRANGLER: (subtitled, in native tongue) I will get it for you.

One of the WRANGLERS turns to the others and chatters away in his strange tongue. OBI-WAN walks along the line of DRAGON/LIZARDS, checking out each one. He looks at their teeth, legs, etc. Finally he pats one on the neck.

OBI-WAN: This one.

The WRANGLER brings the chosen one over to him.

WRANGLER: Boga. She answers to Boga.

OBI-WAN: Good girl, Boga.

OBI-WAN swings onto the back of the LIZARD. The beast rears up and scurries outside to the edge of the sinkhole.

110 EXT. UTAPAU-SINKHOLE WALL-LIZARD-DAY

The LIZARD BOGA rears up on her hind legs again, then climbs the wall of the sheer cliff and starts moving up toward the tenth level. The city appears to be deserted. OBI-WAN is alert to any movement.

111 INT. UTAPAU-CONFERENCE ROOM-GRAND CHAMBER-DAY

GENERAL GRIEVOUS stands before the COUNCIL OF SEPARATISTS, including NUTE GUNRAY, RUNE HAAKO. POGGLE THE LESSER, SHU MAI, SAN HILL PO NUDO, WAT TAMBOR, and PASSEL ARGENTE. OBI-WAN hides above the assembly and watches intently.

GENERAL GRIEVOUS: It won't be long before the armies of the Republic track us here. I am sending you to the Mustafar system in the Outer Rim. It is a volcanic planet which generates a great deal of scanning interference. You will be safe there.

NUTE GUNRAY: Safe? Chancellor Palpatine managed to escape your grip, General, without Count Dooku. I have doubts about your ability to keep us safe.

GENERAL GRIEVOUS: Be thankful, Viceroy, you have not found yourself in my grip . . . Your ship is waiting.

OBI-WAN is deep in thought.

112 INT. UTAPAU-TENTH LEVEL-CONTROL CENTER-DAY

The JEDI removes his cloak and jumps down behind the GENERAL.

OBI-WAN: Hello, there!

GENERAL GRIEVOUS: General Kenobi, you are a bold one. I find your behavior bewildering . . . Surely you realize you're doomed, (to droids) Kill him!

About a HUNDRED BATTLE DROIDS surround OBI-WAN, GENERAL GRIEVOUS, and his BODYGUARDS. OBI-WAN looks around, then walks right up to GENERAL GRIEVOUS.
They stare at each other for a moment.

GENERAL GRIEVOUS: Enough of this.

The BODYGUARDS raise their power staffs to knock OBI-WAN away, but OBI-WAN ducks as the deadly staffs whistle over his head. The Jedi's lightsaber ignites, and OBI-WAN deftly cuts one BODYGUARD in two. His staff flies into the air and is caught by GENERAL GRIEVOUS. The other THREE BODYGUARDS attack OBI-WAN with an intense fury.
OBI-WAN uses the Force to release apiece of equipment from the ceiling. It drops on the BODYGUARDS, smashing them. OBI-WAN walks toward GRIEVOUS, slashing the last BODYGUARD to pieces. BATTLE DROIDS move toward OBI-WAN.

GENERAL GRIEVOUS: Back away. I will deal with this Jedi slime myself.

OBI-WAN: Your move.

GENERAL GRIEVOUS: You fool. I have been trained in your Jedi arts by Count Dooku himself. Attack, Kenobi.

His arms separate and grab all four lightsabers on his belt. His four arms create a flashing display of swordsmanship.

OBI-WAN: You forget I trained the Jedi that defeated Count Dooku!

OBI-WAN is hard-pressed to defend himself against the deadly onslaught. They fight across the control room as the BATTLE DROID SHARPSHOOTERS try to pick off the Jedi. OBI-WAN mounts a ferocious counterattack and cuts off one of GRIEVOUS's hands. A loud EXPLOSION is heard echoing throughout the sinkhole. GENERAL GRIEVOUS and OBI-WAN glance to the entrance of the control center and see CLONE TROOPS in the distance, attacking DROIDS in the sinkhole. On the far wall of the sinkhole, CLONES can be seen rappelling onto balconies.

OBI-WAN: I may not defeat your droids, but my troops certainly will.

GENERAL GRIEVOUS: Army or not, you must realize you are doomed.

OBI-WAN: I don't think so.

TWENTY CLONES suddenly rappel into the entrance of the control center, ray guns blazing. Chaos. Laser bolts fly everywhere as the DROIDS return fire. OBI-WAN attacks GENERAL GRIEVOUS, who defends himself rigorously with one of his bodyguard's electro-staffs. OBI-WAN uses the Force to hurl GENERAL GRIEVOUS backwards. He falls onto a lower platform and OBI-WAN jumps down after him.

113 INT. UTAPAU-TENTH LEVEL-CONTROL CENTER-DAY

More CLONES rappel into the control center and blast away at the remaining DROIDS.
The JEDI cuts down several DROIDS as he races to the entrance of the control center. OBI-WAN spots GENERAL GRIEVOUS racing toward one of the landing platforms in the midst of the battle. GENERAL GRIEVOUS jumps onto a WHEEL SCOOTER and takes off down the wall of the sinkhole. OBI-WAN whistles for his LIZARD BOGA, who runs to him. OBI-WAN jumps on.

114 EXT. UTAPAU-CLIFF AND LANDING PLATFORM-DAY

The chase begins. Obi-Wan drops his lightsaber while riding Boga.

115 EXT. CORUSCANT-SENATE OFFICE BUILDING-SUNSET

The sun is setting as the lights come on in the massive Senate Office Building. The sky is red.

116 INT. CORUSCANT-CHANCELLOR'S OFFICE-SUNSET

PALPATINE listens to a delegation from the Senate, which includes PADME and five other Senators: NEE ALAVAR, FANG ZAR, MALEDEE, SWEITT CONCORKILL, and MON CALAMARI. ANAKIN stands to one side of PALPATINE.

PALPATINE: I understand your reservations completely, Senator, and I assure you the appointment of Governors will in no way compete with the duties of the Senate.

PADME: May I take it then, that there will be no further amendments to the Constitution?

PALPATINE: I want this terrible conflict to end as much as you do, My Lady, and when it does I guarantee an immediate return to democracy . . .

PADME: You are pursuing a diplomatic solution to the war, then.

PALPATINE: You must trust me to do the right things, Senator. That is why I am here.

FANGZAR: But surely . . .

The Chancellor turns on FANG ZAR.

PALPATINE: I have said I will do what is right, that should be enough for your . . . committee.

PADME: On behalf of the "delegation of two thousand," I thank you, Chancellor.

PALPATINE: I thank you for bringing this to my attention, Senator.

PADME gives ANAKIN a frustrated look, then turns and exits with the other FIVE SENATORS. PALPATINE turns to ANAKIN.

PALPATINE: (continuing) Their sincerity is to be admired, although I sense there is more to their request than they are telling us.

ANAKIN: What do you mean?

PALPATINE: They are not to be trusted.

ANAKIN: Surely Senator Amidala can be trusted . . .

PALPATINE: These are unstable times for the Republic, Anakin. Some see instability as an opportunity. Senator Amidala is hiding something. I can see it in her eyes.

ANAKIN: I'm sure you're mistaken.

PALPATINE: I'm surprised your Jedi insights are not more sensitive to such things.

ANAKIN: I simply don't sense betrayal in Senator Amidala.

PALPATINE studies ANAKIN carefully and gives him a skeptical look.

PALPATINE: Yes, you do, but you don't seem to want to admit it. There is much conflict in you, Anakin.

117 INT. CORUSCANT-JEDI WAR ROOM-EARLY EVENING

KI-ADI-MUNDI, ANAKIN, YODA, MACE, CLONE COMMANDER CODY, and AAYLA SECURA talk via holograms.

CLONE COMMANDER CODY: Master Windu, may I interrupt? General Kenobi has made contact with General Grievous, and we
have begun our attack.

MACE WlNDU: Thank you, Commander. Anakin, deliver this report to the Chancellor. His reaction will give us a clue to his
intentions.

ANAKIN: Yes, Master.

ANAKIN leaves the room. COMMANDER CODY's hologram disappears.

MACE WINDU: I sense a plot to destroy the Jedi. The dark side of the Force surrounds the Chancellor.

Kl-ADI-MUNDI: If he does not give up his emergency powers after the destruction of Grievous, then he should be removed from
office.

MACE WiNDU: That could be a dangerous move ... the Jedi Council would have to take control of the Senate in order to secure a peaceful transition . . .

Kl-ADI-MUNDI: . . . and replace the Congress with Senators who are not filled with greed and corruption.

YODA: To a dark place this line of thought will carry us. Hmmmmm. . . . great care we must take.

118 INT. CORUSCANT-CHANCELLOR'S OFFICE-EARLY EVENING

ANAKIN brings news to PALPATINE.

ANAKIN: Chancellor, we have just received a report from Master Kenobi. He has engaged General Grievous.

PALPATINE: We can only hope that Master Kenobi is up to the challenge.

ANAKIN: I should be there with him.

PALPATINE: It is upsetting to me to see that the Council doesn't seem to fully appreciate your talents. Don't you wonder why they won't make you a Jedi Master?

ANAKIN: I wish I knew. More and more I get the feeling that I am being excluded from the Council. I know there are things about the Force that they are not telling me.

PALPATINE: They don't trust you, Anakin. They see your future. They know your power will be too strong to control. Anakin, you must break through the fog of lies the Jedi have created around you. Let me help you to know the subtleties of the Force.

They walk into the hallway.

ANAKIN: How do you know the ways of the Force?

PALPATINE: My mentor taught me everything about the Force . . . even the nature of the dark side.

They stop.

ANAKIN: You know the dark side?!?

PALPATINE: Anakin, if one is to understand the great mystery, one must study all its aspects, not just the dogmatic, narrow view of the Jedi. If you wish to become a complete and wise leader, you must embrace a larger view of the Force. Be careful of the Jedi, Anakin. (pausing) They fear you. In time they will destroy you. Let me train you.

ANAKIN: I won't be a pawn in your political game. The Jedi are my family.

PALPATINE: Only through me can you achieve a power greater than any Jedi. Learn to know the dark side of the Force, Anakin, and you will be able to save your wife from certain death.

ANAKIN: What did you say?

PALPATINE: Use my knowledge, I beg you . . .

ANAKIN: You're a Sith Lord!

ANAKIN ignites his lightsaber.

PALPATINE: I know what has been troubling you . . . Listen to me. Don't continue to be a pawn of the Jedi Council! Ever since I've known you, you've been searching for a life greater than that of an ordinary Jedi . . . a life of significance, of conscience.

ANAKIN: You're wrong!

PALPATINE: Are you going to kill me?

ANAKIN: I would certainly like to.

PALPATINE: I know you would. I can feel your anger. It gives you focus, makes you stronger.

ANAKIN raises his lightsaber to PALPATINE's throat. There is a tense moment, then ANAKIN relaxes, and then turns off his lightsaber.

ANAKIN: I am going to turn you over to the Jedi Council.

PALPATINE: Of course you should. But you're not sure of their intentions, are you? What if I am right and they are plotting to take over the Republic?

ANAKIN: I will quickly discover the truth of all this.

PALPATINE: You have great wisdom, Anakin. Know the power of the dark side. The power to save Padme.

ANAKIN stares at him for a moment.
PALPATINE turns and moves to his office.

PALPATINE: (continuing) I am not going anywhere. You have time to decide my fate. Perhaps you'll reconsider and help me rule the galaxy for the good of all . . .

PALPATINE sits behind his desk.

119 EXT. UTAPAU-CLIFF AND LANDING PLATFORM-DAY

OBI-WAN gives the LIZARD a swift kick with the heel of his boot, and they take off down the vertical side of the sheer cliff. As GENERAL GRIEVOUS reaches the landing platform where his shuttle is waiting. OBI-WAN drops onto the top of the starship with his LIZARD. GENERAL GRIEVOUS spins his scooter around and takes off up the vertical cliff face with OBI-WAN and his LIZARD in hot pursuit. The sinkhole is engulfed in a great battle between CLONES and DROIDS. The PEOPLE OF UTAPAU cower in whatever shelter they can find.

120 EXT. UTAPAU-MAIN CITY PLAZA-DAY

A LARGE GROUP OF UTAPAUAN TROOPS on LIZARDS attack the DROID ARMY.

OBI-WAN and GENERAL GRIEVOUS race through the city at breakneck speed. Passing through battle zones, narrowly escaping EXPLOSIONS, laser bolts, and TROOPS from both sides.

GENERAL GRIEVOUS lays the Scooter down as he goes around sharp turns. Obi-Wan's LIZARD breathes hard as she tries to keep up. They destroy droids, equipment, and clone troops as the JEDI and the GENERAL cut a swath of destruction through the city.

121 EXT. UTAPAU-WINDMILLS-DAY

GENERAL GRIEVOUS works his way out onto the rim of the sinkhole, passing some wind blades. The evil Droid General releases the brakes on the lethal blades, and they begin to spin, cutting off Obi-Wan's access to the General. Obi-Wan's LIZARD pulls up short in front of the blades. GENERAL GRIEVOUS laughs and talks into a comlink.

GENERAL GRIEVOUS: Prepare to move out of orbit. I will be up in a few moments.

OBI-WAN sizes up the situation, looking for a way to get to GENERAL GRIEVOUS.

The GENERAL accelerates off the edge, activating his claws, drops, and clings to another nearby grouping of windmills. Obi-Wan's LIZARD attempts to jump to follow and barely makes it, almost falling into the precipice below.

122 INT. UTAPAU-CITY TUNNEL SYSTEM-DAY

GENERAL GRIEVOUS roars through the stone block tunnel system, riding up on the curved walls as he goes around corners or passes oncoming traffic. OBI-WAN races after the Droid, his LIZARD moving onto the ceiling as they pass traffic. OBI-WAN catches up with GENERAL GRIEVOUS, and they charge through the tunnel, side by side. OBI-WAN grabs the Droid's electronic staff.

123 EXT. UTAPAU-SECRET LANDING PLATFORM-DAY

Extending from the wall of a small sinkhole is a secret landing platform with a small Federation Fighter sitting in the middle of it. OBI-WAN and GENERAL GRIEVOUS race out of the tunnel system and onto the landing platform.

OBI-WAN yanks on the staff, then jumps off his LIZARD onto the General's scooter, knocking both warriors to the ground. GENERAL GRIEVOUS pulls out a laser pistol and fires at OBI-WAN. The Jedi reaches out his hand, grabs the General's electro-staff and spins the staff, blocking the laser bolts.

OBI-WAN charges GENERAL GRIEVOUS, swinging the staff and hitting the Droid in the stomach, knocking the gun away. GENERAL GRIEVOUS is hit by the staff, and the Force bends his forearm. He pulls OBI-WAN close to him, and they engage in a furious fight. The electro-staff is knocked away. The two engage in hand-to-hand combat. OBI-WAN struggles to avoid the deadly blows of the brutal, unstoppable Droid.

GENERAL GRIEVOUS's stomachplate is loose. OBI-WAN grabs it and rips it off, revealing the alien life form's guts encased in a bag in the Droid's chest. GENERAL GRIEVOUS grabs OBI-WAN, hoists him over his head, and tosses him across the platform. OBI-WAN dangles off the edge of the platform. He clutches the rim, trying to hold on. The DROID then grabs the staff and charges OBI-WAN. At the last second, OBI-WAN reaches out his hand and uses the Force to retrieve the Droid's laser pistol.

The JEDI fires several blasts in the stomach area of the alien Droid, and he EXPLODES from the inside out. The smoldering Droid falls to the ground. OBI-WAN has killed GENERAL GRIEVOUS. He pulls himself up onto the platform and walks by the destroyed carcass.

OBI-WAN: So uncivilized . . .

OBI-WAN brushes himself off. He throws the pistol onto the platform, picks up the electro-staff, and jumps on BOGA. The trusty beast rears up and takes off into the tunnel system.

124 INT. JEDI GUNSHIP-LANDING PLATFORM-EARLY EVENING

MACE and the JEDI (AGEN KOLAR, KIT FISTO, AND SAESEE TIIN) are preparing to board a JEDI GUNSHIP to the CHANCELLOR's office. ANAKIN enters the hangar.

ANAKIN: Master Windu, I must talk to you.

MACE WiNDU: What is it, Skywalker? We are in a hurry. We have just received word that Obi-Wan has destroyed General Grievous. We are on our way to make sure the Chancellor returns emergency powers back to the Senate.

ANAKIN: He won't give up his power. I've just learned a terrible truth. I think Chancellor Palpatine is a Sith Lord.

MACE WINDU: A Sith Lord?

ANAKIN: Yes. The one we have been looking for.

MACE WiNDU: How do you know this?

ANAKIN: He knows the ways of the Force. He has been trained to use the dark side.

MACE WiNDU: Are you sure?

ANAKIN: Absolutely.

MACE WiNDU: Then our worst fears have been realized. We must move quickly if the Jedi Order is to survive.

ANAKIN: Master, the Chancellor is very powerful. You will need my help if you are going to arrest him.

MACE WiNDU: For your own good, stay out of this affair. I sense a great deal of confusion in you, young Skywalker. There is much fear that clouds your judgment.

ANAKIN: I must go, Master.

MACE WiNDU: No. If what you told me is true, you will have gained my trust, but for now remain here.

ANAKIN: Yes, Master.

MACE WiNDU: Wait for us in the Council Chamber until we return.

ANAKIN: Yes, Master.

ANAKIN watches as the JEDI leave in their ship.

125 INT. CORUSCANT-JEDI COUNCIL/PADME'S APARTMENT-EARLY EVENING

(INTERCUT)

PADME is alone in her apartment, thinking of Anakin. ANAKIN sits alone in the Jedi Council Chamber thinking of PADME.

PALPATINE: (V.O.) You do know, don't you, if the Jedi destroy me, any chance of saving her will be lost.

PADME: I truly, deeply love you. Before I die. I want you to know.

C-3PO: My Lady, are you. . . . Are you all right?

ANAKIN: I can't do this ... I can't let her die.

ANAKIN rushes out of the Council Chamber and to his speeder. The hangar door opens and he lifts off.

126 EXT. CORUSCANT-SENATE OFFICE BUILDING-LANDING PLATFORM-EARLY EVENING

The sky is still blue as a JEDI GUNSHIP lands on the Senate Office Building landing platform.
FOUR JEDI exit the SHUTTLE and enter the Senate Office Building. MACE WINDU, AGEN KOLAR, KIT FISTO, and SAESEE TIIN, like gunfighters out of the Old West, walk through the massive hallway, four across.

127 INT. CORUSCANT-LOBBY TO CHANCELLOR'S OFFICE-EARLY EVENING

The FOUR JEDI enter the lobby, raising their arms, and send the Chancellor's aide, DAR WAC, flying against the wall, along with TWO REPUBLIC GUARDS. They storm into the Chancellor's office.

128 INT. CORUSCANT-CHANCELLOR�S OFFICE-EARLY EVENING

MACE arrives with THREE JEDI to arrest PALPATINE.

PALPATINE: Master Windu. I take it General Grievous has been destroyed then. I must say, you're here sooner than expected.

MACE WINDU: In the name of the Galactic Senate of the Republic, you are under arrest, Chancellor.

MACE WINDU and the other JEDI ignite their lightsabers.

PALPATINE: Are you threatening me, Master Jedi?

MACE: The Senate will decide your fate.

PALPATINE: (burst of anger) I am the Senate!

MACE: Not yet!

PALPATINE stands, a laser sword appears out of his cloak sleeve, and he spins toward the JEDI.

PALPATINE: It's treason, then.

A close shot of PALPATINE as the fight begins. Close shots of THREE JEDI getting cut down by PALPATINE. PALPATINE and MACE continue to fight.

Jedi Master MACE WINDU and the Sith Lord fight their way down the hallway and into the main office area. PALPATINE is able to use the Force to slam MACE against the wall, but he recovers before the Chancellor can cut him down.

ANAKIN lands his speeder, jumps out, and runs down a long corridor toward the Chancellor's office.

In the heat of battle, MACE cuts the window behind the Chancellor's desk, and it crashes away. MACE is forced out onto the ledge, which is twenty stories up. They fight over the precipice. ANAKIN arrives to see PALPATINE and MACE fighting.

They stop as MACE forces PALPATINE to drop his sword. PALPATINE and MACE start yelling at each other.

MACE WINDU: You are under arrest, My Lord.

PALPATINE: Anakin! I told you it would come to this. I was right. The Jedi are taking over.

MACE WlNDU: You old fool. The oppression of the Sith will never return. Your plot to regain control of the Republic is over . . . you have lost . . .

PALPATINE: No! No! You will die!

PALPATINE raises his hands, and lightning bolts shoot out. They are blocked by MACE's lightsaber. PALPATINE is pushed back against the window sill.

PALPATINE: He is a traitor, Anakin.

MACE WlNDU: He's the traitor. Stop him!

PALPATINE: Come to your senses, boy. The Jedi are in revolt. They will betray you, just as they betrayed me.

MACE WlNDU: Aarrrrggghhhhh . . .

PALPATINE: You are not one of them, Anakin. Don't let him kill me.

MACE WlNDU: Aarrrrggghhhhh . . .

PALPATINE: I am your pathway to power. I have the power to save the one you love. You must choose. You must stop him.

MACE WlNDU: Don't listen to him, Anakin.

PALPATINE: Help me! Don't let him kill me. I can't hold on any longer. Ahhhhhhh . . . ahhhhhhh . . . ahhhhhhh . . .

MACE pushes PALPATINE out to the edge of the ledge. As the Jedi moves closer, the bolts from Palpatine's hands begin to arch back on him. The Chancellor's face begins to twist and distort. His eyes become yellow as he struggles to intensify his powers.

PALPATINE: I can't ... I give up. Help me. I am weak ... I am too weak. Don't kill me. I give up. I'm dying. I can't hold on any longer.

MACE WlNDU: You Sith disease. I am going to end this once and for all.

ANAKIN: You can't kill him, Master. He must stand trial.

MACE WlNDU: He has too much control of the Senate and the Courts. He is too dangerous to be kept alive.

PALPATINE: I'm too weak. Don't kill me. Please.

ANAKIN: It is not the Jedi way . . .

MACE raises his sword to kill the CHANCELLOR.

ANAKIN: (continuing) He must live . . .

PALPATINE: Please don't, please don't . . .

ANAKIN: I need him . . .

PALPATINE: Please don't . . .

ANAKIN: NO!!!

Just as MACE is about to slash PALPATINE, ANAKIN steps in and cuts off the Jedi's hand holding the lightsaber.

As MACE stares at ANAKIN in shock, PALPATINE springs to life.
The full force of Palpatine's powerful Bolts blasts MACE. He attempts to deflect them with his one good hand, but the force is too great. As blue rays engulf his body, he is flung out the window and falls twenty stories to his death. No more screams. No more moans. PALPATINE lowers his arm.

PALPATINE: Power! Unlimited power!

His face has changed into a horrible mask of evil. ANAKIN looks on in horror. PALPATINE cackles.

ANAKIN: What have I done?

ANAKIN sits.

PALPATINE: You are fulfilling your destin, Anakin. Become my apprentice. Learn to use the dark side of the Force.

ANAKIN: I will do whatever you ask.

PALPATINE: Good.

ANAKIN: Just help me save Padme's life. I can't live without her. I won't let her die. I want the power to stop death.

PALPATINE: To cheat death is a power only one has achieved, but if we work together, I know we can discover the secret.

ANAKIN kneels before PALPATINE.

ANAKIN: I pledge myself to your teachings. To the ways of the Sith.

PALPATINE: Good. Good. The Force is strong with you. A powerful Sith you will become. Henceforth, you shall be known as Darth . . . Vader.

ANAKIN: Thank you. my Master.

PALPATINE: Rise, Darth Vader.

Palpatine moves over to his desk.

129 EXT. KASHYYYK-MEETING HALL-DAY

YODA winces, closes his eyes, and holds his head. He feels a disturbance in the Force.

130 INT. CORUSCANT-CHANCELLOR'S OFFICE-EVENING

PALPATINE is putting on his dark cloak: he is now fully DARTH SIDIOUS.

PALPATINE: Because the Council did not trust you, my young apprentice, I believe you are the only Jedi with no knowledge of this plot. When the Jedi learn what has transpired here, they will kill us, along with all the Senators.

ANAKIN: I agree. The Jedi's next move will be against the Senate.

PALPATINE: Every single Jedi, including your friend Obi-Wan Kenobi, is now an enemy of the Republic. You understand that, don't you?

ANAKIN: I understand, Master.

PALPATINE: We must move quickly. The Jedi are relentless; if they are not all destroyed, it will be civil war without end. First, I want you to go to the Jedi Temple. We will catch them off balance. Do what must be done, Lord Vader. Do not hesitate. Show no mercy. Only then will you be strong enough with the dark side to save Padme.

ANAKIN: What about the other Jedi spread across the galaxy?

PALPATINE: Their betrayal will be dealt with. After you have killed all the Jedi in the Temple, go to the Mustafar system. Wipe out Viceroy Gunray and the other Separatist leaders. Once more, the Sith will rule the galaxy, and we shall have peace.

131 INT. CORUSCANT-JEDI TEMPLE ENTRY-NIGHT

ANAKIN goes to the Jedi Temple with a battalion of Clone Troopers.

132 EXT. UTAPAU-TENTH LEVEL-LANDIXG PLATFORM-DAY

The battle between the CLONES and the DROIDS rages throughout the sinkhole. OBI-WAN rides up to CLONE COMMANDER CODY.

OBI-WAN: Commander, contact your troops. Tell them to move to the higher levels.

CLONE COMMANDER CODY: Very good, sir.

CLONE COMMANDER CODY starts to move away, then remembers something and returns to OBI-WAN.

CLONE COMMANDER CODY: (continuing) Oh, by the way, I think you'll be needing this.

He hands OBI-WAN his lightsaber, and the LIZARD rears up.

OBI-WAN: Thank you, Cody, (smiling) Now let's get a move on. We've got a battle to win here.

CLONE COMMANDER CODY: Yes, sir!

OBI-WAN and the LIZARD ride off down the wall of the giant sinkhole.
The battle rages throughout the city. CLONE COMMANDER CODY (2224,) takes out his comlink and listens to the HOLOGRAM OF DARTH SIDIOUS as, far below, OBI-WAN can been seen battling DROIDS on a landing platform.

DARTH SlDIOUS: Commander Cody, the time has come. Execute Order Sixty-Six.

CLONE COMMANDER CODY: It will be done, My Lord.

The HOLOGRAM disappears, and CLONE COMMANDER CODY gestures to a nearby Clone Trooper.

CLONE COMMANDER CODY: Blast him!

The battle rages all around OBI-WAN. DROIDS and CLONES are everywhere. OBI-WAN is riding on a LIZARD, cutting down DROIDS as he races across the battlefield. Suddenly a volley of laser blasts from behind him knocks him and his LIZARD off the wall of the sinkhole. He looks around just in time to see his CLONE TROOPS are firing on him.
OBI-WAN falls hundreds of feet to the bottom of the water-filled sinkhole.

133 EXT. MYGEETO-DAWN

The sky slowly awakens on the crystal world of Mygeeto. A battle rages. Clone troops battle the droid armies across a long bridge. KI-ADI-MUNDi uses his light saber to deflect enemy fire. CLONE COMMANDER BACARA (1138) exits a Gunship near the entrance to the city. He rallies his TROOPS to attack the city, then gets a message on his comlink. He stops and moves to one side as a HOLOGRAM OF DARTH SIDIOUS appears on the comlink in the palm of his hand. He moves further into the shadows.

DARTH SlDIOUS: Commander 1138 . . .

CLONE COMMANDER BACARA: Yes, sir.

DARTH SlDIOUS: The time has come. Execute Order Sixty-Six.

CLONE COMMANDER BACARA: It will be done, My Lord.

DARTH SIDIOUS fades, and the CLONE COMMANDER snaps the comlink closed and looks to the main plaza of the city, where KI-ADI-MUNDI is leading the charge. The clones stop. KI-ADI-MUNDI turns around and is blasted by clone fire. He's killed before he can defend himself.

134 EXT. FELUCIA-FOREST-DAY

A column of CLONE WALKERS marches across the forest floor. The STRANGE CALLS of the alien forest creatures of FELUCIA suddenly stop. The Jedi AAYLA SECURA and her CLONE TROOPS brace for an ambush.

AAYLA: Steady. . . . steady . . .

They all look around for signs of the enemy. CLONE COMMANDER BLY moves up behind the Jedi.

AAYLA: (continuing) Bly, do you think they're Droids?

BLY: No.

BLY blasts AAYLA in the back. The OTHER CLONES fire on her as she hits the ground.

Another Jedi, BARRISS OFFEE, is cutting down a patrol of DROIDS when a CLONE WALKING TANK and SEVEN CLONE TROOPERS round a corner and blast the Jedi away.

135 EXT. KASHYYYK-MEETING HALL-DAY

YODA drops his gimer stick, clutches his chest, and rests against a wall.

136 EXT. KASHYYYK-EDGE OF VILIAGE-DAY

The battle appears to be over. WOOKIEES stack destroyed Droids while CLONES assess the damage to their equipment. A Jedi, LUMINARA UNDULI, talks with EIGHT CLONE OFFICERS standing in a circle around her. Suddenly they reveal their hidden pistols and blast her before she can react.

The Jedi QUINLAN VOS is riding on top of a CLONE TURBO TANK. The main cannon of a second tank slowly swings to point right at him and a COUPLE OF CLONES.
The cannon fires, and QUINLAN VOS and the CLONES disappear in a huge EXPLOSION.

137 INT. CATO NEIMOIDIA-COCKPIT CLONE FIGHTER-DAY

The CLONE PILOT watches a hologram of DARTH SIDIOUS.

DARTH SIDIOUS: Execute Order Sixty-Six.

CLONE PILOT: It will be done, My Lord.

138 INT. CATO NEIMOIDIA-JEDI STARFIGHTER-DAY

PLO KOON heads his ship toward a battle on a landing platform.

PLO KOON: There they are. Land on the nearest platform.

139 EXT. CATO XEIMOIDIA-JEDI STARFIGHTER-DAY

The FOUR CLONE PILOTS with PLO KOON drop back and blast him out of the sky.

140 EXT. SALEUCAMI-FOREST

Three Speeder Bikes race through the forest. A Jedi, STASS ALLIE is in the lead. The TWO CLONES following her drop back and blast her, causing her to crash in a huge EXPLOSION.

141 INT. CORUSCANT-CHANCELLOR'S OFFICE-NIGHT

DARTH SIDIOUS stands alone in his private office, illuminated only from a hologram projector beam from above. A small HOLOGRAM OF COMMANDER GREE stands in front of him.

CLONE COMMANDER GREE: Yes, My Lord.

DABTH SIDIOUS: The time has come. Execute Order Sixty-Six.

142 EXT. KASHYYYK-MEETING HALL BALCONY-DAY

A vista of waterways, high green mesas, and giant tree cities serves as a backdrop for the fierce battle, CLONES AND WOOKIEES against TRADE FEDERATION DROID ARMIES, with treaded tank-like vehicles. CLONE COMMANDER GREE holds his comlink.

CLONE COMMANDER GREE: It will be done, My Lord.

CLONE COMMANDER GREE snaps his comlink shut.

YODA watches from the balcony. The battle rages as CLONES and WOOKIEES attack DROIDS coming across the water on CORPORATE ALLIANCE TANK DROIDS. CHEWBACCA and TARFFUL stand on either side of the Jedi Master as he watches the battle below. CLONE COMMANDER GREE and ONE OFFICER walk onto the balcony toward YODA. YODA stands looking over the battlefield below. When they are close enough, the CLONES reveal their weapons and fire.

But faster than the CLONES can reveal their weapons, YODA ignites his lightsaber, leaps in the air, and beheads both CLONES. CHEWBACCA and TARFFUL fire their weapons as more CLONES enter the hall. The Wookiees call out to YODA to follow them. CHEWBACCA picks YODA up and carries him away.

143 EXT. CORUSCANT-JEDI TEMPLE-NIGHT

A JEDI is surrounded and gunned down by CLONE TROOPERS.

144 INT. CORUSCANT-JEDI TEMPLE-NIGHT

ANAKIN walks through the Jedi Temple, where he finds and kills SHAAK TI.
He exits Shaak Ti's room and enters a hallway, where the battle is taking place.

145 INT. CORUSCANT-JEDI TEMPLE-BATTLE-NIGHT

ANAKIN enters a room full of YOUNGLINGS huddled in a corner.

YOUNGLINGS: Master Skywalker, there are too many of them. What are we going to do?

ANAKIN looks back at them with a stern expression on his face and ignites his lightsaber.

146 INT. CORUSCANT-PADME'S APARTMENT-PRE-DAWN

C-3PO and PADME look out the apartment window.

C-3PO: The Chancellor's office indicated Master Anakin returned to the Jedi Temple. Don't worry, My Lady. I am sure he will be all right.

PADME bursts into tears.

147 EXT. CORUSCANT-CITYSCAPE-PRE-DAWN

The city planet is covered in a hazy glow. A column of black smoke can be seen rising in the distance. BAIL ORGANA's Speeder flies overhead, straight toward the smoke.

148 EXT. CORUSCANT-JEDI TEMPLE-LANDING PLATFORM-PRE-DAWN

The Jedi Temple is on fire. Large plumes of smoke billow toward the sky as BAIL ORGANA lands his Speeder on a Jedi Temple platform. FOUR CLONE TROOPERS stand guard at the entrance to the Temple. They lower their guns as BAIL gets out of his Speeder and walks toward them.

BAIL ORGANA: What's going on here?!?

CLONE SERGEANT: There's been a rebellion. Don't worry, sir, the situation is under control.

The CLONES bar the Senator from entering the Temple.

CLONE SERGEANT: (continuing) I'm sorry, sir. No one is allowed entry.

The CLONES point their guns at BAIL and cock them.

CLONE SERGEANT: (continuing) It's time for you to leave, sir.

BAIL ORGANA: And so it is.

BAIL reluctantly heads hack toward his Speeder. Suddenly, several SHOTS RING OUT. BAIL turns and sees a ten-year-old Jedi, ZETT JUKASSA, fighting the CLONES. Several more CLONES join in the fight, followed by CLONE COMMANDER APPO (1119), who points at BAIL.

CLONE COMMANDER APPO: Get him! Shoot him!

SEVERAL CLONES start firing at BAIL. The Senator jumps for cover behind his Speeder, starting the engines and pulling out his laser
pistol.

The YOUNG JEDI cuts down several CLONES, including APPO, before he is overrun and shot.

The Speeder takes off with BAIL clinging to the side. The CLONES fire at it as it disappears into the cityscape.

149 EXT. CORUSCANT-CITYSCAPE-PRE-DAWN

BAIL ORGANA struggles to pull himself into the Speeder as it races along through the cityscape. Finally, he climbs in, just as the Speeder is about to hit a building. BAIL steers clear of the building and races away.

150 EXT. UTAPAU-UNDERWATER SINKHOLE-DAY

The Jedi dives below the surface amid a barrage of laser fire. He dives deeper under the water, fumbling in his utility belt for a breathing device. He finds it and puts it in his mouth. He swims underwater until the CLONE TROOPS give up and stop filing.

151 EXT. UTAPAU-UNDERWATER CAVES-DAY

OBI-WAN removes the breathing apparatus after coming up from underwater. He starts to climb the rock wall.

OBI-WAN climbs the wall to the second cave just as TWO LITTLE SEEKER DRONES pop out of the water with their searchlights glowing. OBI-WAN presses himself against the wall of the smaller cave as the TWO SEEKER DRONES search the grotto. One of the SEEKERS begins to enter the cave in which OBI-WAN is hiding. OBI-WAN presses further into the wall. The light shines on the opposite wall and moves to the back of the cave, illuminating a huge NOS MONSTER. OBI-WAN holds his breath. The SEEKER is confused for a moment, then the NOS MONSTER lunges at the SMALL DROID and consumes it in one bite.

The NOS MONSTER'S lunge takes him past OBI-WAN, out of the cave, and into the water.

The SECOND SEEKER shines its light on the NOS MONSTER as the evil creature tries to grab the LITTLE DRONE. OBI-WAN slinks off toward the back of the cave. He comes upon a nest of BABY NOS MONSTERS. They SCREECH and make horrible sounds. OBI-WAN jumps over them and continues on his way through the tunnel system.

152 EXT. KASHYYYK-LAKE ON VILLAGE EDGE-DUSK

CLONES in modified one-man AT-ST's and Swamp Speeders flash their searchlights across the gloomy lake. The light of one of the AT-ST's spots something floating in the water. It is what's left of a Wookiee catamaran. The body of a dead Wookiee (TARFFUL) is lying across the stern of the wreckage of the flying boat. There is some movement on the boat. The CLONE SERGEANT on the AT-ST fires a warning shot past the boat.

AT-ST CLONE SERGEANT: Everyone out of there!

A CRAZY LITTLE CREATURE about two feet high pops its head over the rail. The creature is covered with mud. His long hair is frizzed out in all directions.

CREATURE: Wookiee good . . . eat Wookiee. (crazy little laugh)

CLONE SERGEANT: Did you find something?

CREATURE: It's nothing, nothing. (laughs)

CLONE SERGEANT: It's nothing, nothing. All these Wookiees are dead. Move to the east.

CLONE TROOPER: Yes, sir.

Suddenly, CHEWBACCA climbs up behind the AT-ST CLONE, dripping wet, and throws the CLONE SERGEANT into the water. CHEWIE BARKS.

CREATURE: Right you are, Chewbacca. Faster that will be.

TARFFUL jumps up in the boat, and the CREATURE takes off his hair. It is Yoda.

YODA: Stink, this mud does. A moment to bathe, give me.

YODA, covered with mud, jumps into the water. TARFFUL climbs onto the AT-ST with CHEWBACCA. YODA is out of the water and putting his robes back on.

YODA: (continuing) Not far, are we, from the emergency ship. Quickly . . .

YODA whistles and a large ALIEN FLYING INSECT called CAN-CELL appears. YODA jumps on the insect's back and they take off. The WOOKIEES follow on the AT-ST. The CLONES continue to search the swamp.

153 EXT. KASHYYYK-HILLS OVERLOOKING LAKE-DUSK

The AT-ST marches up the hill and stops. The WOOKIEES jump down. YODA lands on CAN-CELL nearby. CHEWBACCA goes to a tree and pulls down one of its branches.
The ground opens up, and a small WOOKIEE ESCAPE POD rises into the field. YODA opens the door of the pod.

YODA: Good-bye. Chewbacca and Tarfful, miss you I will. Good friends you are. For your help, much gratitude and respect, I have.

The Wookiees BARK as the Jedi climbs into the WOOKIEE POD and takes off into the dusk sky.

154 EXT. CORUSCANT-SENATE OFFICE BUILDING-UNDERGROUND STARSHIP LANDING PLATFORM-DAY

BAIL ORGANA walks out of a tunnel onto a huge underground platform with two of his AIDES. He is stopped by TWO ROYAL GUARDS.

ROYAL GUARD: Identification . . .

BAIL ORGANA: Senator Bail Organa of Alderaan.

BAIL and his AIDES hand them their ID cards. The ROYAL GUARDS check them over and give them back, then BAIL and his CREW walk on board his Starship.

155 EXT. CORUSCANT-SENATE OFFICE BUILDING-UNDERGROUND LANDING PLATFORM-DAY

The platform rises to the surface of the Office Building. The ALDERAAN STARCRUISER takes off and disappears into the crisp morning sky.

156 INT ALDERAAN-STARCRUISER-HALLWAY-DAY

BAIL ORGANA is greeted by CAPTAIN ANTILLES and TWO ALDERAAN TROOPERS.

BAIL ORGANA: Were you able to get hold of a Jedi homing beacon?

CAPTAIN ANTILLES: Yes, sir. We've encountered no opposition. The clones are still a bit confused. It appears no one is in command.

BAIL ORGANA: That will change soon. Hopefully we will be able to intercept a few Jedi before they walk into this catastrophe.

157 EXT. UTAPAU-SINKHOLE WALL-LATE DAY

OBI-WAN hides from a group of CLONE TROOPERS.

CLONE CAPTAIN: Did you find Kenobi?

CLONE TROOPER: No one could have survived that fall.

He watches them pass.

CLONE CAPTAIN: Start loading your men on the ship.

CLONE TROOPER: Yes, sir.

OBI-WAN tries to sneak back to the secret platform, down a flight of stairs.

158 EXT. UTAPAU-SECRET LANDING PLATFORM-LATE DAY

OBI-WAN makes his way out of the cave and onto General Grievous's secret landing platform. He runs to the Starfighter and climbs into the one-man ship. The Starfighter takes off and disappears into the sky.

159 EXT. UTAPAU-SPACE

OBI-WAN flies away from the planet Utapau in General Grievous's tiny Starfighter.

160 INT. GENERAL GRIEVOUS'S STARFIGHTER-SPACE

OBI-WAN activates the controls on the Starfighter. He punches in several coordinates and codes. A BEEPING SOUND is heard. It quickly speeds up until it is a steady tone. OBI-WAN speaks into his comlink.

OBI-WAN: Emergency Code Nine Thirteen ... I have no contact on any frequency. Are there any Jedi out there? . . . anywhere . . .

A BURST OF STATIC is heard- and a FUZZY HOLOGRAM image appears.

BAIL: (hologram) . . . Kenobi . . .

OBI-WAN: (continuing) I've locked on. Repeat.

The FUZZY HOLOGRAM image comes into focus, and it is BAIL ORGANA.

BAIL ORGANA: Master Kenobi??

OBI-WAN: Senator Organa! My Clone Troops turned on me ... I need help.

BAIL ORGANA: We have just rescued Master Yoda. It appears this ambush has happened everywhere. We're sending you our coordinates.

161 INT. CORUSCANT-PADME�SAPARTMENT-PRE-DAWN

PADME stands before the window of her living room, watching the plume of smoke from the Jedi Temple. C-3PO enters from the bedroom.

C-3PO: My Lady, there's a Jedi fighter docking on the veranda.

PADME turns and rushes to the bedroom.

162 EXT. CORUSCANT-PADME'S APARTMENT-VERANDA-PRE-DAWN

THREEPIO walks out to ANAKIN's ship and talks with ARTOO. ARTOO beeps.

THREEPIO: Hush! Not so loud!

PADME rushes onto the veranda as ANAKIN exits his GREEN JEDI FIGHTER. They embrace.

PADME: Are you all right? I heard there was an attack on the Jedi Temple . . . you can see the smoke from here.

ANAKIN: I'm fine. I'm fine. I came to see if you and the baby are safe.

PADME: Captain Typho's here, we're safe. What's happening?

C-3PO continues to talk to R2-D2 on the GREEN FIGHTER.

C-3PO: What is going on?

ARTOO SQUEAKS and BEEPS.

C-3PO: (continuing) You can't be anymore confused than I am.

ANAKIN: The situation is not good. The Jedi have tried to overthrow the Republic . . .

PADME: I can't believe that!

ANAKIN: I couldn't either at first, but it's true. I saw Master Windu attempt to assassinate the Chancellor myself.

C-3PO leans over and whispers to ARTOO.

C-3PO: Something important is going on! I heard a rumor they are going to banish all droids.

ARTOO BEEPS rather loudly. C-3PO puts his fingers to his lips.

C-3PO: (continuing) Shhhhhh . . . not so loud.

ARTOO BEEPS quietly.

C-3PO: (continuing) Whatever it is, we'll be the last to know.

PADME: Anakin, what are you going to do?

ANAKIN looks down for a moment and then walks away from Padme.

ANAKIN: I will not betray the Republic . . . my loyalties lie with the Chancellor and with the Senate . . . and with you.

ANAKIN turns and walks back to Padme.

PADME: What about Obi-Wan?

ANAKIN: I don't know . . . Many Jedi have been killed. We can only hope that he's remained loyal to the Chancellor.

PADME: How could this have happened?

ANAKIN: The Republic is unstable, Padme. The Jedi aren't the only ones trying to take advantage of the situation. There are also traitors in the Senate.

PADME stands and reacts ever so slightly.

PADME: What are you saying?

ANAKIN: You need to distance yourself from your friends in the Senate. The Chancellor said they will be dealt with when this conflict is over.

PADME: What if they start an inquisition? I've opposed this war. What will you do if I become a suspect?

ANAKIN: That won't happen. I won't let it.

PADME: Oh, Anakin, I'm afraid.

ANAKIN takes PADME in his arms.

ANAKIN: Have faith, my love. Everything will soon be set right. The Chancellor has given me a very important mission. The Separatists have gathered in the Mustafar system. I'm going there to end this war. Wait for me until I return . . . things will be different, I promise.

They kiss.

ANAKIN: (continuing) Please, wait for me.

PADME: I will.

ANAKIN gets into his Fighter as THREEPIO backs away.

C-3PO: (to Artoo) Well, he is under a lot of stress, Artoo.

ARTOO beeps.

C-3PO: (continuing) Take care, my little friend.

ARTOO BEEPS a good-bye, and the fighter takes off. PADME is left alone on the veranda. She starts to cry. THREEPIO comes up to her.

C-3PO: (continuing) My Lady, is there anything I might do?

PADME: No thank you, Threepio.

G-3PO: A snack, perhaps?

PADME: No.

THREEPIO starts to move off.

C-3PO: I feel so helpless.

163 EXT. ALDERAAN-STARCRUISER-SPACE

OBI-WAN's ship docks with Bail Organa's Starcruiser.

164 INT. ALDERAAN-STARCRUISER-HALLWAY-DAY

The door to the main hallway slides open. OBI-WAN enters and is greeted by YODA and BAIL ORGANA. The three walk down the hallway.

BAIL ORGANA: You made it.

YODA: Master Kenobi, dark times are these. Good to see you. it is.

OBI-WAN: You were attacked by your Clones, also?

YODA: With the help of the Wookiees, barely escape, I did.

OBI-WAN: How many other Jedi managed to survive?

YODA: Heard from no one, have we.

BAIL ORGANA: I saw thousands of troops attack the Jedi Temple. That's why I went looking for Yoda.

OBI-WAN: Have we had any contact from the Temple?

YODA: Received a coded retreat message, we have.

BAIL ORGANA: It requests all Jedi to return to the Temple. It says that the war is over . . .

OBI-WAN: Well, then we must go back! If there are other stragglers, they will fall into the trap and be killed.

BAIL ORGANA: It's too dangerous to return.

YODA: Suggest dismantling the coded signal, do you?

OBI-WAN: Yes, Master. There is too much at stake here, and we need a clearer picture of what has happened.

YODA: I agree. In a dark place we find ourselves ... a little more knowledge might light our way.

165 EXT. MUSTAFAR-LAVA FIELDS-DAY

Workers move across the lava beds, gathering the magma. A column of aliens riding giant MUSTAFAR FLEAS marches forward.

166 INT. MUSTAFAR-MAIN CONTROL CENTER-DAY

A HOLOGRAM of DARTH SIDIOUS is in the center of the room. NUTE GUNRAY and the REST OF THE SEPARATIST COALITION watch SIDIOUS.

NUTE GUNRAY: The plan has gone as you had promised, My Lord.

DARTH SIDIOUS: You have done well, Viceroy. When my new apprentice, Darth Vader, arrives, he will take care of you.

The hologram disappears.

167 INT. CRUISER-COCKPIT

The Republic Cruiser heads toward Coruscant. OBI-WAN, BAIL, YODA, and TWO PILOTS sit in the cockpit.

PILOT: We are receiving a message from the Chancellor's office, sir.

BAIL ORGANA: Send it through.

PILOT: Yes, sir.

The PILOT pushes some buttons. MAS AMEDDA appears on screen.

MAS AMEDDA: Senator Organa . . . the Supreme Chancellor of the Republic requests your presence at a special session of Congress.

BAIL ORGANA: Tell the Chancellor I will be there.

MAS AMEDDA: Very well. He will be expecting you.

MAS AMEDDA's image disappears from the screen.

BAIL ORGANA: It could be a trap.

OBI-WAN: No, I don't think so. The Chancellor will not be able to control the thousands of star systems without keeping the Senate intact.

YODA: If a special session of Congress there is, easier for us to enter the Jedi Temple it will be.

168 EXT. CORUSCANT-SENATE LANDING PLATFORM-LATE DAY

OBI-WAN, BAIL, and YODA land on Coruscant. The elevator door opens, and they step out.

GUARD: Welcome back, Senator. May I see your clearance?

BAIL ORGANA: Certainly.

GUARD: Thank you, you may proceed. We will take custody of the Jedi.

OBI-WAN: It would be better if we stayed with the Senator.

GUARD: It would be better if they stayed with you.

BAIL and his AIDES go into the Senate. YODA and OBI-WAN head for the Jedi Temple.

169 EXT. MUSTAFAR-JEDI STARFIGHTER-SPACE

ANAKIN's Jedi Starfighter heads for the hazy blood-red planet of Mustafar.

170 EXT. MUSTAFAR-LANDING PLATFORM-DAY

ANAKIN flies over the volcanoes of Mustafar and lands his Jedi Starfighter on a complex of Landing Platforms. His cockpit opens as R2-D2 pops from the ship with a happy BEEP.

ANAKIN: Artoo . . . stay with the ship.

ARTOO lets out a sad little BEEP and moves back toward the ship.

171 EXT. MUSTAFAR-LANDING PLATFORM-DAY

ANAKIN, putting on his hood, walks across a walkway upon arriving on Mustafar.

172 INT. MUSTAFAR-MAIN CONTROL CENTER-DAY

ANAKIN appears in the doorway of the control center.

NUTE GUNRAY: Welcome, Lord Vader. We've been expecting you.

Everyone in the room looks to him as he raises his hand toward a control panel, and all the exits close. The confused SEPARATISTS look around in bewilderment.

173 EXT. CORUSCANT-JEDI TEMPLE-LATE DAY

Smoke from the smoldering shell of the Jedi Temple fills the air with a brown haze.

174 INT. CORUSCANT-JEDI TEMPLE-MAIN ENTRANCE-LATE DAY

A DOZEN CLONE TROOPERS stand guard at the entrance of the Jedi Temple. Suddenly there is a flash of a lightsaber, a flurry of confusion, and all of the Clone Troopers are dead on the floor. YODA and OBI-WAN stand in the middle of the carnage.

OBI-WAN: There are several battalions of Clone Troopers on every level. Many are dressed as Jedi.

YODA: Dismantle the coded signal quickly. That group back there, soon discovered will be.

175 EXT. CORUSCANT-SENATE BUILDING-SUNSET

The awesome Senate Building looms over the city. The endless traffic continues to clutter the skyline.

176 INT. CORUSCANT-SENATE CHAMBER-SUNSET

The Chancellor is in the podium in the center of the vast arena giving a speech. MAS AMEDDA stands to the right of SIDIOUS. BAIL ORGANA walks through the hallway of the Main Senate Chamber. He enters the Senate Pod of Naboo and sits next to PADME. JAR JAR, CAPTAIN TYPHO and TWO HANDMAIDENS are in the pod also.

PALPATINE: . . . and the Jedi Rebellion has been foiled.

BAIL ORGANA: I was held up. What's happening?

PADME: The Chancellor has been elaborating on a plot by the Jedi, to overthrow the Senate.

BAIL ORGANA: That's not true!

PADME: He's been presenting evidence all afternoon.

BAIL ORGANA: And the Senate will go along with it, just like they always do.

PALPATINE: The remaining Jedi will be hunted down and defeated. (applause) Any collaborators will suffer the same fate.

(applause)

These have been trying times, but we have passed the test.

177 INT. CORUSCANT-JEDI TEMPLE-HALLWAY-SUNSET

YODA and OBI-WAN make their way through the Temple, avoiding the HUNDREDS OF CLONE TROOPERS. They use the Force to distract the CLONES when they can.
YODA and OBI-WAN walk through the ruins of the Temple until they come across the bodies of some students.

OBI-WAN: Not even the younglings survived.

YODA: Killed not by clones, this Padawan. By a lightsaber, he was.

OBI-WAN: . . .Who?? Who could have done this?

178 INT. MUSTAFAR-MAIN CONTROL CENTER-DAY

ANAKIN ignites his lightsaber, NUTE and the OTHERS panic. The DROIDS at the controls and the GUARDS grab their weapons, but it is too late. They are cut down in a flash. The Separatists bang on the doors, and NUTE and RUNE HAAKO flee under a table.

ANAKIN, stone-faced, moves through the room like the grim reaper. Bodies drop everywhere. SCREAMS are cut short as the head of the Banking Clan dies.

Then POGGLE THE LESSER loses his head; WAT TAMBOR, SHU MAI, and the REST OF THE SEPARATISTS run into the conference room.

179 INT. CORUSCANT-SENATE CHAMBER-SUNSET

PALPATINE: The attempt on my life has left me scarred and deformed, but I assure you my resolve has never been stronger.

Applause.

180 INT. MUSTAFAR-MAIN CONTROL CENTER-DAY

In the hallway, ANAKIN cuts down DROIDS and SEPARATISTS alike. He is unstoppable. ANAKIN turns his head-his eyes are yellow.

181 INT. CORUSCANT-SENATE CHAMBER-SUNSET

PALPATINE continues his speech at the podium.

PALPATINE: The war is over. (applause) The Separatists have been defeated, (applause) and the Jedi rebellion has been foiled. We stand on the threshold of a new beginning.

There is a long period of APPLAUSE.

PADME: Well, this is the moment we discover if he intends to return the Republic to a democracy.

PALPATINE: In order to ensure our security and continuing stability, the Republic will be reorganized into the first Galactic Empire, for a safe and secure society which I assure you will last for ten thousand years.

There is a loud, sustained CHEER from the Senate. BAIL ORGANA and PADME sit, dumbfounded.

PALPATINE: (continuing) An empire that will continue to be ruled by this august body, and a sovereign ruler chosen for life . . .

The Senate CHEERS again. BAIL and PADME are devastated. PADME begins to cry.

PALPATINE: (continuing) An empire ruled by the majority . . . Ruled by a new constitution . . .

The Senate APPLAUDS.

PADME: So this is how liberty dies, with thunderous applause . . .

BAIL ORGANA: We cannot let this happen.

He starts to stand up. PADME stops him.

PADME: Not now! There will be a time.

182 INT. MUSTAFAR-MAIN CONTROL CENTER-CONFERENCE ROOM-DAY

After everyone in the Main Control Room is dead, ANAKIN moves to the small conference room where WAT TAMBOR. SHU MAI, and some OTHER SEPARATISTS are hiding. RUNE HAAKO tries to run but is trapped by a dead-end as ANAKIN advances.

RUNE HAAKO: Stop! Enough, this is not right!

RUNE is cut down. NUTE GUNRAY crawls out from under the table and opens the Main Door, allowing DESTROYER DROIDS to enter. WAT TAMBOR is cut down, along with SHU MAI. DESTROYER DROIDS appear in the doorway and blast away, causing total destruction. When the firing is over, ANAKIN is gone. Blown away? No. ANAKIN drops from the ceiling behind the TWO DROIDS and cuts them to pieces before they know what hit them.

183 INT. MUSTAFAR-MAIN CONTROL CENTER-HALLWAY-DAY

NUTE GUNRAY is the last Separatist leader alive. ANAKIN moves on to find NUTE GUNRAY hiding in an alcove.

NUTE GUNRAY: The war is over. Lord Sidious promised us peace ... we only want . . .

NUTE GUNRAY is cut down in midsentence.

184 INT. CORUSCANT-JEDI TEMPLE-COMPUTER ROOM-NIGHT

OBI-WAN stands in a large computer area as YODA looks on, in the hatchway to the Main Control Center.

OBI-WAN: I've recalibrated the code warning all surviving Jedi to stay away.

YODA: Good . . . For the Clones to discover the recalibration, a long time it will take. To change it back, longer still. Hurry.

185 INT. CORUSCANT-JEDI TEMPLE-CONTROL CENTER-NIGHT

OBI-WAN enters the Main Control Center with YODA and heads for the hologram area.

OBI-WAN: Wait, Master. There is something I must know . . .

YODA: If into the security recordings you go, only pain will you find.

OBI-WAN: I must know the truth, Master.

OBI-WAN moves to a panel and flips some switches. He sees a HOLOGRAM of ANAKIN slaughtering JEDI, including the YOUNG ONES. OBI-WAN and YODA react.

OBI-WAN: (continuing) It can't be . . . It can't be . . .

As ANAKIN surveys the carnage, a DARK-ROBED SITH LORD enters. ANAKIN turns to DARTH SIDIOUS and kneels before him.

ANAKIN: The traitors have been taken care of, Lord Sidious.

DARTH SlDIOUS: Good . . . good . . . You have done well, my new apprentice. Do you feel your power growing?

ANAKIN: Yes, My Master.

DARTH SlDIOUS: Now, Lord Vader, now go and bring peace to the Empire.

OBI-WAN watches in horror. Tears well up in his eyes.

OBI-WAN: I can't watch any more.

OBI-WAN switches off the hologram. The TWO JEDI stand in silence for a few moments.

YODA: Destroy the Sith, we must.

OBI-WAN: Send me to kill the Emperor. I will not kill Anakin.

YODA: To fight this Lord Sidious, strong enough, you are not.

OBI-WAN: He is like my brother ... I cannot do it.

YODA: Twisted by the dark side, young Skywalker has become. The boy you trained, gone he is . . . Consumed by Darth Vader.

OBI-WAN: How could it have come to this?

YODA: To question, no time there is.

OBI-WAN: I do not know where the Emperor has sent him. I don't know where to look.

YODA: Use your feelings, Obi-Wan, and find him, you will. Visit the new Emperor, my task is. May the Force be with you.

OBI-WAN: May the Force be with you, Master Yoda.

186 INT. CORUSCANT-PADME'S APARTMENT-AFTERNOON

A DC0052 Intergalactic Speeder pulls up to the veranda landing of Padme's apartment.

187 EXT. CORUSCANT -PADME'S APARTMENT-VERANDA-AFTERNOON

The cockpit of the sleek yellow Galactic Speeder opens, and a HOODED FIGURE emerges and walks onto the veranda. An ALARM GOES OFF deep in the apartment. The FIGURE stops before a security curtain that protects the veranda. C-3PO enters the veranda and approaches the FIGURE.

C-3PO: Hello, might I help you . . . Oh, it's you, Master Kenobi. Come in, quickly.

The security curtain disappears, and the FIGURE lifts his hood. It is OBI-WAN. The alarm stops sounding.

OBI-WAN: Has Anakin been here . . . ?

C-3PO: Yes . . . right after the attack on the Jedi Temple.

PADME comes down the stairs in a robe. THREEPIO leaves.

PADME: Master Kenobi . . .

She embraces Obi-Wan.

PADME: (continuing) Oh, Obi-Wan, thank goodness . . . you're alive.

OBI-WAN: The Republic has fallen. Padme . . . The Jedi Order is no more . . .

PADME: I know, it's hard to believe everything to which we've dedicated our lives is gone.

OBI-WAN: I believe we have been part of a plot hundreds of years in the making.

PADME: The Senate is still intact, there is some hope.

OBI-WAN: No. Padme . . . It's over . . . The Sith now rule the galaxy as they did before the Republic.

PADME: The Sith!?!

OBI-WAN: I'm here looking for Anakin . . . When was the last time you saw him?

PADME: Yesterday.

OBI-WAN: And do you know where he is now?

PADME: (looks down) No.

OBI-WAN: Padme, I need your help. He's in grave danger.

PADME: From the Sith?

OBI-WAN: From himself . . . Padme, Anakin has turned to the dark side.

PADME: You're wrong! How could you even say that?

OBI-WAN: I have seen a security hologram of him killing younglings.

PADME: Not Anakin! He couldn't!

OBI-WAN: He was deceived by a lie. We all were. It appears that the Chancellor is behind everything, including the war. Palpatine is the Sith Lord we've been looking for. After the death of Count Dooku, Anakin became his new apprentice.

PADME: I don't believe you ... I can't.

OBI-WAN: Padme, I must find him.

PADME: You're going to kill him, aren't you?

OBI-WAN: He has become a very great threat.

As PADME moves to sit down, she reveals her pregnancy.

PADME: I can't . . .

OBI-WAN: Anakin is the father, isn't he?

PADME looks away.

OBI-WAN: (continuing) I'm so sorry.

OBI-WAN turns and leaves as PADME stares transfixed, not knowing what to do. She is worried and tormented. OBI-WAN takes off in the Speeder. She studies the japor snippet that is hanging around her neck.

188 INT. MUSTAFAR-LANDING PLATFORM-DAY

R2-D2 waits forlornly for his Master in front of the Jedi Starfighter.

189 INT. MUSTAFAR-MAIN CONTROL CENTER-DAY

ANAKIN surveys the slaughter with a crazed look in his eyes.

190 INT. MUSTAFAR-CONTROL CENTER-BALCONY-DAY

ANAKIN stares out at Mustafar, standing on the control room balcony.

191 EXT. CORUSCANT-LANDING PLATFORM-SUNSET

A small Naboo Skiff rests on a landing platform in the vast congestion of Coruscant. PADME gets out of her Speeder, followed by CAPTAIN TYPHO and C-3PO.

CAPTAIN TYPHO: My Lady, let me come with you.

PADME: There is no danger. The fighting is over, and . . . this is personal.

TYPHO bows.

CAPTAIN TYPHO: As you wish, My Lady . . . but I strongly disagree.

PADME: I'll be all right, Captain.

He goes to the speeder and gets in.

PADME: (continuing) This is something I must do myself. Besides, Threepio will look after me.

C-3PO: Oh, dear.

TYPHO takes off and PADME and THREEPIO board the small NABOO SKIFF. A shadow moves out from under the SKIFF. It is OBI-WAN. He quickly jumps on the retracting ramp as the SKIFF takes off.

192 INT. NABOO SKIFF

THREEPIO chatters away as PADME breaks down in tears, the painful reality sinking in.

C-3PO: Green light. Do you know that I think I'm beginning to get the hang of this flying business.

OBI-WAN stows away on Padme's ship. The ship lifts from the landing platform and heads into the traffic lanes.

193 INT. CORUSCANT-SENATE ARENA-CHANCELLOR'S HOLDING OFFICE-SUNSET

A HOLOGRAM OF ANAKIN appears before PALPATINE in his office at the bottom of the Senate Arena.

DARTH VADER: The Separatists are taken care of, My Master.

DARTH SlDIOUS: It is finished, then. You have restored peace and justice to the galaxy. You have done well, Lord Vader.

DARTH VADER: Thank you, My Master.

194 INT. MUSTAFAR-COXFERENCE ROOM-DAY

A Hologram of Sidious speaks with Anakin in the Mustafar control room.

DARTH SlDIOUS: Send a message to the ships of the Trade Federation. Tell them the Separatist leaders have been wiped out. Grievous and Dooku have been destroyed. All droid units must shut down immediately.

DARTH VADER: Very good, My Lord.

ANAKIN sees Padme's ship arriving on the screen and goes out to meet her.

195 EXT. MUSTAFAR-LANDING PLATFORM-DAY

The sleek NABOO SKIFF lands on the Mustafar landing platform near Anakin's GREEN STARFIGHTER. ANAKIN runs up to the SKIFF as the ramp lowers. PADME runs to him.

ANAKIN: Padme, I saw your ship . . .

They embrace.

PADME: Oh, Anakin!

ANAKIN: It's all right, you're safe now. What are you doing out here?

PADME: I was so worried about you. Obi-Wan told me terrible things.

ANAKIN: What things?

PADME: He said you have turned to the dark side . . . that you killed younglings.

ANAKIN: Obi-Wan is trying to turn you against me.

PADME: He cares about us.

ANAKIN: Us??!

PADME: He knows . . . He wants to help you.

ANAKIN: Is Obi-Wan going to protect you? He can't ... he can't help you. He's not strong enough.

PADME: Anakin, all I want is your love.

ANAKIN: Love won't save you, Padme. Only my new powers can do that.

PADME: At what cost? You are a good person. Don't do this.

ANAKIN: I won't lose you the way I lost my mother! I've become more powerful than any Jedi has ever dreamed of and I've done it for you. To protect you.

PADME: Come away with me. Help me raise our child. Leave everything else behind while we still can.

ANAKIN: Don't you see, we don't have to run away anymore. I have brought peace to the Republic. I am more powerful than the Chancellor. I can overthrow him, and together you and I can rule the galaxy. Make things the way we want them to be.

PADME: I don't believe what I'm hearing . . . Obi-Wan was right. You've changed.

ANAKIN: I don't want to hear any more about Obi-Wan. The Jedi turned against me. Don't you turn against me.

PADME: I don't know you anymore. Anakin, you're breaking my heart. I'll never stop loving you, but you are going down a path I
can't follow.

ANAKIN: Because of Obi-Wan?

PADME: Because of what you've done . . . what you plan to do. Stop, stop now. Come back! I love you.

ANAKIN: (seeing Obi-Wan) Liar!

PADME turns around and. sees OBI-WAN standing in the doorway of the Naboo Cruiser.

PADME: No!

ANAKIN: You're with him. You've betrayed me! You brought him here to kill me!

PADME: NO! Anakin. I swear ... I ...

ANAKIN reaches out, and PADME grabs her throat as she starts to choke.

OBI-WAN: Let her go, Anakin.

ANAKIN: What have you and she been up to?

OBI-WAN: Let her go!

ANAKIN releases his grip on the unconscious PADME and she crumples to the ground.

ANAKIN: You turned her against me.

OBI-WAN: You have done that yourself.

ANAKIN: You will not take her from me.

ANAKIN throws off his cloak.

OBI-WAN: Your anger and your lust for power have already done that.

OBI-WAN flings off his cloak.

OBI-WAN: (continuing) You have allowed this Dark Lord to twist your mind until now . . . until now you have become the very thing you swore to destroy.

They circle each other until OBI-WAN is near PADME. He places his hand on her.

ANAKIN: Don't lecture me, Obi-Wan. I see through the lies of the Jedi. I do not fear the dark side as you do. I have brought peace, justice, freedom, and security to my new Empire.

OBI-WAN: Your new Empire?

ANAKIN: Don't make me kill you.

OBI-WAN: Anakin, my allegiance is to the Republic ... to democracy.

ANAKIN: If you're not with me, you're my enemy.

OBI-WAN: Only a Sith Lord deals in absolutes. I will do what I must.

(ignites his lightsaber)

ANAKIN: You will try.

ANAKIN ignites his lightsaber.

ANAKIN lashes out at OBI-WAN, and they begin a ferocious sword fight. ANAKIN throws CONTAINERS at OBI-WAN using the Force.
They work their way off the landing platform and into the main entry hallway. ANAKIN kicks OBI-WAN, and OBI-WAN drops to a lower level.
ARTOO BEEPS his concern and rushes to the unconscious PADME's aid.

196 INT. CORRIDOR-SENATE ARENA-CHANCELLOR'S HOLDING OFFICE-NIGHT

YODA enters, using the Force to throw two RED GUARDS against the wall, knocking them unconscious. DARTH SIDIOUS turns his chair toward YODA. MAS AMEDDA stands behind SIDIOUS's desk.

YODA: I hear a new apprentice, you have. Emperor, or should I call you Darth Sidious.

DARTH SlDIOUS: Master Yoda, you survived.

YODA: Surprised?

DARTH SlDIOUS: Your arrogance blinds you, Master Yoda. Now you will experience the full power of the dark side.

The Dark Lord raises his arms, and LIGHTNING BOLTS shoot out, surrounding YODA.
YODA is picked up and thrown across the room, hitting the wall and sliding down in a crumpled heap. DARTH SIDIOUS chuckles.

197 INT. MUSTAFAR-PASSAGES TO MAIN CONTROL CENTER-DAY

ANAKIN and OBI-WAN move their fight toward the main control center. As the laser swords fly, bits of the hallway are cut up. OBI-WAN and ANAKIN jump and use every trick in the Jedi book.

198 EXT. MUSTAFAR-LANDING PLATFORM-NABOO CRUISER-DAY

R2-D2, tries to drag PADME on board the Naboo Cruiser. C-3PO pokes his head out of the ship's doorway.

C-3PO: What are you doing? You're going to hurt her. Wait!!

C-3PO starts down the ramp.

199 INT. CORRIDOR-SENATE ARENA-CHANCELLOR'S HOLDING OFFICE-NIGHT

MAS AMEDDA leaves the room. PALPATINE approaches a stunned YODA.

DARTH SlDIOUS: I have waited a long time for this moment, my little green friend. At last, the Jedi are no more.

YODA: Not if anything I have to say about it, Lord Sidious.

YODA uses the Force to throw DARTH SIDIOUS back, knocking him clear over his desk and onto the floor in a heap.

YODA: (continuing) At an end your rule is and not short enough it was, I must say.

DARTH SIDIOUS flies through the air, cape flapping, heading toward the exit. At the last second, YODA flies into the exit and stops the Dark Lord.

YODA: (continuing) If so powerful you are, why leave??

YODA ignites his lightsaber.

DARTH SlDIOUS: You will not stop me. Darth Vader will become more powerful than either of us.

DARTH SIDIOUS ignites his lightsaber.

YODA: Faith in your new apprentice, misplaced may be, as is your faith in the dark side of the Force.

Their swords CLASH. The battle is extremely fast and furious.


200 INT. MUSTAFAR-MAIN CONTROL CENTER-DAY

View screens EXPLODE around ANAKIN and OBI-WAN as they work their way into the Control Room. The fighting is intense. OBI-WAN is on the defensive as he jumps up on the table view screen in the center of the room.

ANAKIN: Don't make me destroy you, Master. You're no match for the dark side.

OBI-WAN: I've heard that before, Anakin . . . but I never thought I'd hear it from you.

ANAKIN forces OBI-WAN back into the Conference Room where the quarters are much closer. Sparks fly everywhere. ANAKIN jumps onto the conference table. OBI-WAN slides across the table, knocking ANAKIN over. OBI-WAN grabs ANAKIN�s lightsaber as he falls. OBI-WAN uses the Force to summon his dropped lightsaber. ANAKIN does the same.

201 INT. CORUSCANT-SENATE CHAMBER-MAIN ARENA-NIGHT

PALPATINE seeks refuge in the vast Senate Chamber. He gets into the Chancellor's Podium and it starts to rise up into the Arena. YODA makes a giant leap into the control pod. The sword fighting is intense in the confined space.

202 INT. MUSTAFAR-MAIN CONTROL CENTER-DAY

The battle intensifies.

OBI-WAN: (continuing) The flaw of power is arrogance.

OBI-WAN stands looking at his former apprentice for a moment.

ANAKIN: You hesitate . . . the flaw of compassion.

OBI-WAN and ANAKIN lock sabers. OBI-WAN puts out his hand to use the Force to push ANAKIN away. ANAKIN puts out his hand to block OBI-WAN.
Both combatants are blasted backwards onto the control panels.
They regain their footing and the battle continues. ANAKIN kicks OBI-WAN away.
They battle around the room, and eventually the door to the exterior is knocked open. They continue battling out onto the balcony.

203 INT. CORUSCANT-SENATE CHAMRER-MAIN ARENA-NIGHT

YODA unleashes a ferocious assault on PALPATINE, causing him to almost go over the edge. The Dark Lord drops his lightsaber but recovers with a BLAST OF ENERGY from his hands that surrounds YODA. YODA is deflecting the Sith Lord's lightning bolts.

The energy bolts begin to arc back on the Emperor. It looks as if the Dark Lord is doomed.

YODA: Destroy you I will, just as Master Kenobi, your apprentice will destroy.

YODA jumps to a lower Senate Pod. PALPATINE reaches out with one hand, and a Senate pod is released from its mooring and heads toward the Podium. PALPATINE uses the Force to hurl pod after pod at YODA, who ducks and jumps from one flying pod to another.

YODA leaps away from the pods. He uses the Force to hold one pod suspended in the air. The pod spins and YODA throws it back at PALPATINE, who leaps away at the last moment.

YODA leaps after him, but PALPATINE quickly turns and aims the full force of his energy bolts at the tiny green Jedi, catching him in mid-air and throwing him back hard against the Podium. The force causes YODA to drop his lightsaber. YODA blocks the lightning and throws PALPATINE backwards off the podium. YODA is knocked off the Podium and falls several hundred feet to the base of the Podium. PALPATINE follows in his pod, searching for YODA.

204 EXT. MUSTAFAR-MAIN CONTROL CENTER BALCONY-DAY

ANAKIN forces OBI-WAN down a narrow balcony outside the Control Room. He rips objects off the wall and throws them at OBI-WAN as he pushes him further and further along the walkway.

The balcony ends, and OBI-WAN is trapped. He looks over the balcony and into a river of lava.

ANAKIN cuts apiece of the balcony railing off, along with a control panel.
ALARMS SOUND, and a protective ray shield around the superstructure disappears. It tumbles into the molten abyss, disappearing in a puff of smoke. A small pipe connects the Control Center to the Main Collection Plant. OBI-WAN has no choice but to tightrope-walk out across the lava river while fighting ANAKIN.

205 EXT. MUSTAFAR-MAIN CONTROL CENTER BALCONY, PIPE ACROSS LAVA RIVER, MAIN COLLECTION PLANT-DAY

ANAKIN, following OBI-WAN, jumps down onto the flexing pipe, lands, and resumes fighting.

206 INT. MUSTAFAR-PIPE ACROSS LAVA RIVER-DAY

OBI-WAN and ANAKIN work their way across the small pipe, fighting ferociously as they go. OBI-WAN slips, throws his lightsaber up in the air, grabs on to the pipe, swings around, grabs on to an upper pipe, retrieves his lightsaber, and lands back on the original pipe. They continue to fight across the pipe until they reach the Main Collection Plant.

207 INT. CORUSCANT-SENATE OFFICE BUILDING-WIRING CHUTE-NIGHT

YODA squishes his way through a mass of wires in a small chute. He talks on his comlink.

YODA: Hurry. Careful timing we will need.

BAIL ORGANA: (in speeder) There aren't many troops on this side. Activate your homing beacon when you're ready.

208 INT. CORUSCANT-SENATE CHAMBER-MAIN ARENA-NIGHT

A Senate pod with COMMANDER THIRE (4477) and SEVERAL OTHER CLONE TROOPERS climb up to where MAS AMEDDA and PALPATINE are waiting. Beneath the Main Podium, TWENTY CLONE TROOPERS search for Yoda 's body.

CLONE COMMANDER THIRE: There is no sign of his body, sir.

MAS AMEDDA: Then he is not dead.

PALPATINE: Double your search.

CLONE COMMANDER THIRE: Yes sir. Right away, sir.

PALPATINE: (to Mas Amedda) Tell Captain Kagi to prepare my shuttle for immediate takeoff.

MAS AMEDDA: Yes, Master.

PALPATINE: I sense Lord Vader is in danger.

PALPATINE walks into the Arena hallway. COMMANDER THIRE descends down to the floor of the Arena, where an intense search is taking place. SEVERAL CURIOUS SENATORS rubberneck in scattered pods.

209 EXT. MUSTAFAR-COLLECTION PANELS-DAY

OBI-WAN and ANAKIN battle on the top of the multispired collection panels, jumping from one to the other. At the end of the collection cluster, a huge spray of lava covers the attachments that hold up the collectors. The frame begins to melt. It's raining lava. Both ANAKIN and OBI-WAN run for cover under the collection cluster. They continue to fight in the lava rain, darting from cover to attack, then quickly retreating to cover.
Support for the entire structure begins to fall away, and the collection cluster falls into the lava river. The Jedi continue their fight, climbing to the highest point on the tower as the rest begins to melt away as it rides the swift current down the river.

It bends toward the lava as they get out toward the end. The fighting gets fierce. OBI-WAN gets to the end and is trapped. The tower slowly starts to sink under the lava.

210 EXT. CORUSCANT-SENATE OFFICE BUILDING-NIGHT

BAIL ORGANA, in his open Cockpit Speeder, flies along next to the roof eave of the huge Senate Building. He slows and moves closer to a long row of recessed lights. Suddenly YODA falls out of one of the light recesses and lands in the Speeder. BAIL guns it and heads away from the Senate Building.

211 INT. CORUSCANT-BAIL ORGANA'S SPEEDER-NIGHT

YODA straightens himself out.

YODA: Into exile I must go. Failed, I have.

YODA and BAIL fly into the traffic of the city.

212 EXT. MUSTAFAR-COLLECTION PANELS-DAY

OBI-WAN realizes he is getting very close to the edge of the lava falls. He grabs a rope and leaps from the collection arm. ANAKIN follows.
ANAKIN and OBI-WAN continue their sword fight hanging from cables as they swing past each other.

213 EXT. MUSTAFAR-LANDING PLATFORM-NABOO SKIFF-DAY

C-3PO carefully lifts PADME into his arms. R2-D2 nervously looks on. BEEPING.

C-3PO: I am being careful. I've got a good hold on her, but . . . I'm worried about my back. I hope it's able to hold up under this weight.

C-3PO carries PADME into the Naboo Skiff.

214 EXT. MUSTAFAR-COLLECTION PANELS-DAY

From their cables, ANAKIN and OBI-WAN both spot something that causes them to stop fighting. The lava river ahead drops off in a tremendous lava fall.

SNAPPING AND METAL GROANS are heard as the main part of the collector starts to break away and move toward the lava fall. OBI-WAN looks around and sees a small floating platform making its way toward the tower.

OBI-WAN does a double hack-flip and lands squarely on the floating platform. He immediately leans to one side and moves away from the tower.

ANAKIN realizes he is doomed as the entire tower heads for the falls. In the distance he sees some CONSTRUCTION DROIDS. He swings back to the tower, climbs up and makes a running leap and miraculously lands on A WORKER DROID. The DROID is confused and chatters to his CO-WORKER. The giant collector goes over the lava flow and disappears in the mist of sparks below.

OBI-WAN heads for the bank of the lava river, but Anakin's DROID is faster. He catches up with his old Master.

OBI-WAN and ANAKIN continue the swordfight. They battle away, balancing on the tiny platform and puzzled DROID. ANAKIN, standing on the Droid, approaches OBI-WAN on the work platform.

OBI-WAN: I have failed you, Anakin. I was never able to teach you to think.

ANAKIN and OBI-WAN confront each other on the lava river.

ANAKIN: I should have known the Jedi were plotting to take over . . .

OBI-WAN: From the Sith!!! Anakin, Chancellor Palpatine is evil.

ANAKIN: From the Jedi point of view! From my point of view, the Jedi are evil.

OBI-WAN: Well, then you are lost!

ANAKIN: This is the end for you, My Master. I wish it were otherwise.

ANAKIN jumps and flips onto OBI- WAN's platform. The fighting continues again until OBI-WAN jumps toward the safety of the black sandy edge of the lava river. He yells at Anakin.

OBI-WAN: It's over, Anakin. I have the high ground.

ANAKIN: You underestimate my power!

OBI-WAN: Don't try it.

ANAKIN follows, and OBI-WAN cuts his young apprentice at the knees, then cuts off his left arm in the blink of an eye. ANAKIN tumbles down the embankment and rolls to a stop near the edge of the lava.

ANAKIN struggles to pull himself up the embankment with his mechanical hand. His thin leather glove has been burned off. He keeps sliding down in the black sand.

OBI-WAN: (continuing) . . . You were the Chosen One! It was said that you would, destroy the Sith, not join them. It was you who would bring balance to the Force, not leave it in Darkness.

OBI-WAN picks up Anakin's light saber and begins to walk away. He stops and looks back.

ANAKIN: I hate you!

OBI-WAN: You were my brother, Anakin. I loved you.

ANAKIN'S clothing blows into the lava river and ignites. Suddenly ANAKIN bursts into flames and starts SCREAMING.

215 INT. MUSTAFAR-VOLCANO EDGE-DAY

OBI-WAN looks in horror as ANAKIN becomes engulfed in flames. OBI-WAN can't watch him as he struggles to climb the embankment, covered in flames.

He runs back to Padme's ship as ANAKIN drops, smoldering, near the top of the lava pit.

216 EXT. MUSTAFAR-LANDING PLATFORM-NABOO SKIFF-DAY

OBI-WAN makes his way to the SKIFF. He looks for Padme. THREEPIO sticks his head out the door of the SKIFF.

C-3PO: Master Kenobi! We have Miss Padme on board. Please, please hurry. We should leave this dreadful place.

OBI-WAN runs on board the Naboo Skiff.

217 EXT. MUSTAFAR-LANDING PLATFORM-NABOO SKIFF-DAY

PADME lies on a cot or bed inside the ship. OBI-WAN walks over and checks on her.

PADME: Obi-Wan? Is Anakin all right?

OBI-WAN looks at her sadly and does not answer. He brushes her hair back. Padme drops back into unconsciousness. ARTOO watches over her.
OBI-WAN rides in the co-pilot's station. He sits looking pensive. THREEPIO drives.

218 EXT. MUSTAFAR-VOLCANO EDGE-DAY

ANAKIN crawls up the bank, his body smoking. A shuttle flies overhead and lands.

219 EXT. MUSTAFAR-LANDING PLATFORM-IMPERIAL SHUTTLE-DAY

An Imperial Shuttle closes its wings and settles on the highest of the Mustafar Landing Platforms. A PLATOON OF CLONE TROOPERS exits the craft, followed by DARTH SIDIOUS.

220 INT. MUSTAFAR-VOLCANO PIT-DAY

DARTH SIDIOUS walks in front of the CLONE TROOPERS on his way to get to Anakin at the edge of the lava pit.

221 EXT. MUSTAFAR-VOLCANO PIT-DAY

DARTH SIDIOUS discovers what remains of ANAKIN and checks him out. He turns to the CLONES.

DARTH SIDIOUS: Anakin! Anakin! There he is. He's still alive. Get a medical capsule, immediately.

CLONE CAPTAIN: Yes sir. Right away.

Several of the CLONES rush off as DARTH SIDlOUS puts his hand on ANAKIN's forehead.

222 INT. POLIS MASSA-OBSERVATION DOME-NIGHT

On the isolated asteroid of Polis Massa, YODA meditates.

YODA: Failed to stop the Sith Lord, I have. Still much to learn, there is ...

QUI -GON: (V.O.) Patience. You will have time. I did not. When I became one with the Force I made a great discovery. With my training, you will be able to merge with the Force at will. Your physical self will fade away, but you will still retain your consciousness. You will become more powerful than any Sith.

YODA: Eternal consciousness.

QUI-GON: (V.O.) The ability to defy oblivion can be achieved, but only for oneself. It was accomplished by a Shaman of the Whills. It is a state acquired through compassion, not greed.

YODA: . . . to become one with the Force, and influence still have . . . A power greater than all, it is.

QUI-GON: (V.O.) You will learn to let go of everything. No attachment, no thought of self. No physical self.

YODA: A great Jedi Master, you have become, Qui-Gon Jinn. Your apprentice I gratefully become.

YODA thinks about this for a minute, then BAIL ORGANA enters the room and breaks his meditation.

BAIL ORGANA: Excuse me, Master Yoda. Obi-Wan Kenobi has made contact.

223 EXT. MUSTAFAR-LANDING PLATFORM-DAY

The CLONES have placed ANAKIN in a medical capsule. They float the wounded Sith Lord into the belly of the IMPERIAL CRUISER. DARTH SIDIOUS follows the capsule into the ship. The ship takes off.

224 EXT. POLIS MASSA-LANDING PLATFORM-NIGHT

OBI-WAN lands the Naboo Cruiser on the landing platform of the isolated post of Polis Massa. YODA and BAIL ORGANA, along with a FEW GROUND CREW, are waiting as the ramp lowers and OBI-WAN emerges, carrying the unconscious PADME in his arms, followed by ARTOO and THREEPIO.

BAIL ORGANA: We'll take her to the medical center, quickly.

225 EXT. LANDING PLATFORM-CORUSCANT-IMPERIAL REHAB CENTER-DAY

The shuttle lands. DARTH SIDIOUS and CLONE TROOPERS leave the shuttle. ANAKIN's body is carried along in a floating medical capsule.

226 INT. POLIS MASSA-MEDICAL CENTER-NIGHT

POLIS MEDICS work, on PADME in an operating theater. OBI-WAN and one of the MEDICAL DROIDS enter an observation room where BAIL and YODA are waiting.

MEDICAL DROID: Medically, she is completely healthy. For reasons we can't explain, we are losing her.

OBI-WAN: She's dying?

MEDICAL DROID: We don't know why. She has lost the will to live. We need to operate quickly if we are to save the babies.

BAIL ORGANA: Babies??!!

MEDICAL DROID: She's carrying twins.

YODA: Save them, we must. They are our last hope.

The MEDICAL DROID rushes back to the operating room. ARTOO and THREEPIO watch, greatly puzzled. ARTOO BEEPS.

C-3PO: It s some kind of reproductive process, I think.

227 INT. CORUSCANT-IMPERIAL REHAB CENTER-DAY

ANAKIN, in the medical capsule, is lifted onto a table in the Rehab Center. DROIDS go to work on him. ANAKIN has new legs and a new arm.

228 INT. POLIS MASSA-MEDICAL CENTER-NIGHT

The TWINS are being delivered as BAIL ORGANA, YODA, ARTOO, and THREEPIO watch. OBI-WAN is in the operating theater with PADME. He takes her hand.

OBI-WAN: Don't give up, Padme.

PADME winces from the pain. The MEDICAL DROID is holding the BABY.

MEDICAL DROID: It's a boy.

PADME: Luke . . .

PADME can only offer up a faint smile. She struggles to touch the baby on the forehead.

MEDICAL DROID: ... and a girl.

PADME: . . . Leia.

R2-D2, THREEPIO and BAIL ORGANA watch from an adjoining space.

229 INT. CORUSCANT-IMPERIAL REHAB CENTER-DAY

VADER, dressed in his black body armor, lies on the table. Nose plugs are inserted and the mask drops from above, sealing tightly. The helmet is fitted and VADER begins breathing.

230 INT. POLIS MASSA-MEDICAL CENTER-NIGHT

OBI WAN leans over PADME and softly speaks to her.

OBI-WAN: You have twins, Padme They need you . . . hang on.

PADME: I can't . . .

PADME winces again and takes OBI-WAN's hand. She is holding Anakin's japor snippet.

OBI-WAN: Save your energy.

PADME: Obi-Wan . . . there . . . is good in him. I know there is ... still . . .

A last gasp, and she dies. Obi-Wan studies the necklace.

231 INT. CORUSCANT-IMPERIAL REHAB CENTER-DAY

DARTH SIDIOUS hovers around the periphery of a group of MEDICAL DROIDS who are working on ANAKIN. DARTH SIDIOUS paces in the foreground. A DROID approaches the Dark Lord.

MEDICAL DROID: My Lord, the construction is finished ... he lives.

DARTH SIDIOUS: Good. Good.

The DROID moves back to the table where DARTH VADER lies. The table begins to move upright. DARTH SIDIOUS moves in next to DARTH VADER.

DARTH SIDIOUS: (continuing) Lord Vader, can you hear me?

DARTH VADER, with his dark mask and helmet, moves up into the frame until he is in a CLOSEUP.

DARTH VADER: Yes, My Master.

DARTH VADER looks around the room.

DARTH VADER: (continuing) Where is Padme? Is she safe, is she all right?

DARTH SIDIOUS moves closer to the half droid/half man.

DARTH SIDIOUS: I'm afraid she died. ... it seems in your anger, you killed her.

A LOW GROAN emanates from Vader's mask. Suddenly everything in the room begins to implode, including some of the DROIDS.

DARTH VADER: I couldn't have! She was alive! I felt her! She was alive! It's impossible! No!!!

VADER SCREAMS, breaks his bonds to the table, and steps forward, waving his hands, causing objects to fly around the room. SIDIOUS deflects the objects, but some of the DROIDS aren't so lucky. VADER'S PAINFUL SCREAMS echo throughout the Center.

232 EXT. NABOO-ALDERAAN STARCRUISER

BAIL ORGANA's Starcruiser approaches the city of Theed.

233 INT. ALDERAAN CRUISER-CONFERENCE ROOM

BAIL ORGANA, YODA, and OBI-WAN sit around a conference table.

YODA: Pregnant, she must still appear. Hidden, safe, the children must be kept.

OBI-WAN: We must take them somewhere the Sith will not sense their presence.

YODA: Split up, they should be.

BAIL ORGANA: My wife and I will take the girl. We've always talked of adopting a baby girl. She will be loved with us.

OBI-WAN: And what of the boy?

YODA: To Tatooine. To his family, send him.

OBI-WAN: I will take the child and watch over him. Master Yoda, do you think Anakin's twins will be able to defeat Darth Sidious?

YODA: Strong the Force runs, in the Skywalker line. Hope, we can . . . Done, it is. Until the time is right, disappear we will.

BAIL leaves the conference room. YODA stops OBI-WAN.

YODA: (continuing) Master Kenobi, wait a moment. In your solitude on Tatooine, training I have for you.

OBI-WAN: Training??

YODA: An old friend has learned the path to immortality.

OBI-WAN: Who?

YODA: One who has returned from the netherworld of the Force to train me . . . your old Master, Qui-Gon Jinn.

OBI-WAN: Qui-Gon? But, how could he accomplish this?

YODA: The secret of the Ancient Order of the Whills, he studied. How to commune with him. I will teach you.

OBI-WAN: I will be able to talk with him?

YODA: How to join the Force, he will train you. Your consciousness you will retain, when one with the Force. Even your physical self, perhaps.

234 INT. ALDERAAN STARCRUISER-HALLWAY- SPACE

BAIL ORGANA, followed by ARTOO and THREEPIO, approaches CAPTAIN ANTILLES and TWO CREW MEMBERS.

BAIL ORGANA: Captain Antilles.

CAPTAIN ANTILLES: Yes, Your Highness.

BAIL ORGANA: I'm placing these droids in your care. Treat them well. Clean them up. Have the Protocol Droid's mind wiped.

C-3PO: Oh, no.

235 EXT. NABOO-MAIN SQUARE-DAWN

SIO BIBBLE walks with other MOURNERS.
LARGE CROWDS line the street as a flowered, covered coffin is drawn by SIX BEAUTIFUL WHITE BEASTS. SOLDIERS AND FAMILY
ATO DIGNITARIES follow the casket.
PADME's hand clutches the japor snippet.

236 EXT. DAGOBAH-DAY

A small escape pod hurls toward the swamp planet and disappears in the mist. The pod has landed, and YODA descends the ramp, surveying the unfamiliar terrain.

237 EXT. IMPERIAL STAR DESTROYER-SPACE

A Star Destroyer is surrounded by ATTACK CRUISERS. On the bridge of the Star Destroyer stands the EMPEROR and GOVERNOR
TARKIN.

DARTH VADER walks along the bridge to join the EMPEROR and GOVERNOR TARKIN. The camera PANS to reveal the huge frame
structure which is the beginning of the DEATH STAR.

238 EXT. ALDERAAN-STARCRUISER-SPACE

The ship approaches the surface of Alderaan.

239 EXT. ALDERAAN-LATE AFTERNOON

The QUEEN OF ALDERAAN sits on a balcony looking out over the awesome mountains of Alderaan. BAIL ORGANA brings a small baby to her. She takes her and rocks her.

240 EXT. TATOOINE-SUNSET

OBI-WAN rides up to the moisture farm homestead on an EOPIE. He dismounts, takes the BABY out of a papoose on his back, and walks toward AUNT BERU, who walks over to greet him. They talk for a moment, and OBI-WAN turns the baby over to the young homesteader. AUNT BERU walks to UNCLE OWEN who is standing on the ridge near the homestead. OBI-WAN leaves as OWEN, BERU, and the BABY watch the twin suns set.

IRIS OUT. END TITLES.
